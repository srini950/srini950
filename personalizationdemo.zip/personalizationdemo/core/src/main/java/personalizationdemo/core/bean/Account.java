package personalizationdemo.core.bean;

public class Account
{
    private String fieldValue;

    private String fieldType;

    private String ID;

    private String fieldName;

    public String getFieldValue ()
    {
        return fieldValue;
    }

    public void setFieldValue (String fieldValue)
    {
        this.fieldValue = fieldValue;
    }

    public String getFieldType ()
    {
        return fieldType;
    }

    public void setFieldType (String fieldType)
    {
        this.fieldType = fieldType;
    }

    public String getID ()
    {
        return ID;
    }

    public void setID (String ID)
    {
        this.ID = ID;
    }

    public String getFieldName ()
    {
        return fieldName;
    }

    public void setFieldName (String fieldName)
    {
        this.fieldName = fieldName;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [fieldValue = "+fieldValue+", fieldType = "+fieldType+", ID = "+ID+", fieldName = "+fieldName+"]";
    }
}
