package personalizationdemo.core.bean;

public class RelatedItemsComponentBean {

	private String icon;
	private String alttext;
	private String title;
	private String teaser;
	private String ctaButtonRequired;
	private String buttonType;
	private String buttonLabel;
	private String ctaUrl;
	private String fieldType;
	private String dynamicCTAUrl;
	private String openInNewWindow;
	
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getAlttext() {
		return alttext;
	}
	public void setAlttext(String alttext) {
		this.alttext = alttext;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTeaser() {
		return teaser;
	}
	public void setTeaser(String teaser) {
		this.teaser = teaser;
	}
	public String getButtonLabel() {
		return buttonLabel;
	}
	public void setButtonLabel(String buttonLabel) {
		this.buttonLabel = buttonLabel;
	}
	public String getCtaUrl() {
		return ctaUrl;
	}
	public void setCtaUrl(String ctaUrl) {
		this.ctaUrl = ctaUrl;
	}
	public String getOpenInNewWindow() {
		return openInNewWindow;
	}
	public void setOpenInNewWindow(String openInNewWindow) {
		this.openInNewWindow = openInNewWindow;
	}
	public String getButtonType() {
		return buttonType;
	}
	public void setButtonType(String buttonType) {
		this.buttonType = buttonType;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getDynamicCTAUrl() {
		return dynamicCTAUrl;
	}
	public void setDynamicCTAUrl(String dynamicCTAUrl) {
		this.dynamicCTAUrl = dynamicCTAUrl;
	}
	public String getCtaButtonRequired() {
		return ctaButtonRequired;
	}
	public void setCtaButtonRequired(String ctaButtonRequired) {
		this.ctaButtonRequired = ctaButtonRequired;
	}
}
