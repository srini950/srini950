package personalizationdemo.core.models;
import org.apache.sling.api.SlingHttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;

import personalizationdemo.core.utils.UtilityHelper;

public class GetPEDemoAccountInfo extends WCMUsePojo {
	private static final Logger logger = LoggerFactory.getLogger(GetPEDemoAccountInfo.class);
	private String pageSuffix = "";


	@Override
	public void activate()  {
		// TODO Auto-generated method stub
		try {
				logger.debug("in GetSparkAccountInfo activate");
				SlingHttpServletRequest request=getRequest();
				if(request!=null) {
						pageSuffix=UtilityHelper.getSparkId(getRequest());
						if (pageSuffix != null)
							pageSuffix = pageSuffix.replaceAll("/", "");
				}
				
				logger.debug("GetCurrentPageInfo pageName {}",pageSuffix);
		}catch(Exception e) {
			logger.debug("Exception in GetSparkAccountInfo {}",e.getMessage());
			logger.error("Exception in GetSparkAccountInfo {}",e.getMessage());
		}

	}

	public String getPageSuffix() {
		return pageSuffix;
	}

}
