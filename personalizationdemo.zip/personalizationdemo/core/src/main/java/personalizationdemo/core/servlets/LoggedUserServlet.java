package personalizationdemo.core.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import personalizationdemo.core.utils.PEDemoConstants;

import personalizationdemo.core.services.GetLoggedInUser;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=PEDemo LoggedUserServlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "loggeduserinfo" })
public class LoggedUserServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(LoggedUserServlet.class);
	

	@Reference
	GetLoggedInUser userInfo;
	
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		boolean isSalestechadmin = false;
		boolean isB2b2CMarketer = false;
		boolean isFieldSales = false;

		try {
			ResourceResolver resourceResolver = request.getResourceResolver();
			UserManager userManager = resourceResolver.adaptTo(UserManager.class);
			Session session = resourceResolver.adaptTo(Session.class);
			Authorizable auth = userManager.getAuthorizable(session.getUserID());
			response.setContentType("application/json");
			final PrintWriter out = response.getWriter();
			ObjectMapper mapper = new ObjectMapper();
			ObjectNode rootNode = mapper.createObjectNode();
			String userGroup="";
			ArrayList<String> userGroupInfo = userInfo.getUserGroup(resourceResolver);
			for (int i = 0; i < userGroupInfo.size(); i++) {
				if (userGroupInfo.get(i).equalsIgnoreCase(PEDemoConstants.ADMIN_TECH_GROUP)) {
					isSalestechadmin = true;
					userGroup = PEDemoConstants.ADMIN_TECH_GROUP;
				}else if (userGroupInfo.get(i).equalsIgnoreCase(PEDemoConstants.AUTHOR_MARKETER_GROUP)) {
					isB2b2CMarketer = true;
					userGroup = PEDemoConstants.AUTHOR_MARKETER_GROUP;
				}else if (userGroupInfo.get(i).equalsIgnoreCase(PEDemoConstants.SELLER_AUTHOR_GROUP)) {
					isFieldSales = true;
					userGroup = PEDemoConstants.SELLER_AUTHOR_GROUP;
				}
			}
			if(isFieldSales){
				((ObjectNode) rootNode).put("UserID", session.getUserID());
				((ObjectNode) rootNode).put("UserName",auth.getPrincipal().getName());
				((ObjectNode) rootNode).put("userGroup", userGroup);
			}else {
				((ObjectNode) rootNode).put("UserID", "all");
				((ObjectNode) rootNode).put("UserName",auth.getPrincipal().getName());
				((ObjectNode) rootNode).put("userGroup", userGroup);
			}
			log.debug("user group {}",auth.memberOf());
			log.debug("is pedemo admins {}",isSalestechadmin,isB2b2CMarketer);
			out.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rootNode));
			out.flush();

		} catch (Exception e) {
			log.error("exception in Servlet {}", e.getMessage());
			log.debug("Exception in Servlet {}", e.getMessage());
		}

	}
}
