package personalizationdemo.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.dam.api.Asset;
import com.day.cq.i18n.I18n;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import personalizationdemo.core.bean.PEDemoIdNameBean;
import personalizationdemo.core.bean.PEDemoSegmentBean;
import personalizationdemo.core.bean.TraitBean;
import personalizationdemo.core.utils.CommonUtils;
import personalizationdemo.core.utils.MaskHelper;
import personalizationdemo.core.utils.PEDemoConstants;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=PEDemo CreateSegmentServlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "createsegmentsfromfile" })
public class CreateSegmentsFromFile extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(CreateSegmentsFromFile.class);
	final static String AND_SEGMENT_TEMPLATE_PATH_WITH_PROPERTIES = "/apps/personalizationdemo/components/structure/dctsegmentutility/andtemplatewithproperties/andtemplate";
	final String OR_SEGMENT_TEMPLATE_PATH = "/apps/personalizationdemo/components/structure/pedemosegmentpage/ortemplate";
	private static String SEGMENT_ROOT = "/etc/segmentation/contexthub/pedemo";
	private static String SPARKACCOUNT_FILE_PATH = "/content/dam/pedemo/masterjsondata/sparkaccounts.txt";
	private static final long BOOST = 0;
	private static final String TRAIT_USER_PROFILE_ID_KEY_PROP = "property";
	private static final String TRAIT_USER_PROFILE_ID_KEY_PROP_VAL = "userprofile/id";
	private static final String TRAIT_USER_PROFILE_VALUE_PROP = "value";
	private static final String LEFT_NODE_PATH = "/jcr:content/traits/andpar/property_value/left";
	private static final String RIGHT_NODE_PATH = "/jcr:content/traits/andpar/property_value/right";

	private static int commitCounter = 0;
	private static int exceptionCounter=0;
	private static int sparkIdListSize = 0;
	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) {

		log.debug(":::::::::::::in CreateSegmentsFromFile do post:::::::::: ");
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode responseCode = mapper.createObjectNode();
		final I18n i18n = new I18n(request);
		try {
			Asset textFileNode = request.getResourceResolver().getResource(SPARKACCOUNT_FILE_PATH).adaptTo(Asset.class);
			List<PEDemoIdNameBean> sparkIdList = CommonUtils.getFileValues(textFileNode);
			log.debug("::::sparkIdList size :::"+sparkIdList.size());
			sparkIdListSize = sparkIdList.size();
			for (int i = 0; i < sparkIdList.size(); i++) {
				PEDemoSegmentBean segmentBean = populateSegmentBean(sparkIdList.get(i));
				try {
					createSegmentFromBean(request, segmentBean);
				} catch (WCMException e) {
					exceptionCounter++;					
					log.debug("Exception Count "+exceptionCounter+ " WCMException in creatSegmentFromBean method for segment "
							+ segmentBean.getSegmentName() + " " + e.getMessage());
				}

			}
			if(exceptionCounter==0)
			responseCode.put("response", i18n.get("New segments are created successfully."));
			else
			responseCode.put("response", i18n.get("There is an exception occured during one or more spark account processing. Please ch."));	
			response.getWriter().append(responseCode.toString());
		} catch (PersistenceException persistenceException) {

			log.debug("Persistence Exception in doPost " + persistenceException.getMessage());
			try {
				responseCode.put("response", i18n.get("Persistence Exception in doPost."));
				response.getWriter().append(responseCode.toString());
				response.setStatus(403);
				return;
			} catch (IOException e) {				
				log.debug("::::::::::Exception in block PersistenceException ::::::::::");
			}

		} catch (IOException ioException) {
			log.debug("IOException in doPost " + ioException.getMessage());
			try {
				responseCode.put("response", i18n.get("IOException in doPost."));
				response.getWriter().append(responseCode.toString());
				response.setStatus(403);
				return;
			} catch (IOException e) {				
				log.debug("::::::::::Exception in block IOException ::::::::::");
			}

		} catch (RepositoryException repoException) {
			log.debug("RepositoryException in doPost " + repoException.getMessage());
			try {
				responseCode.put("response", i18n.get("IOException in doPost."));
				response.getWriter().append(responseCode.toString());
				response.setStatus(403);
				return;
			} catch (Exception e) {				
				log.debug("::::::::::Exception in block RepositoryException ::::::::::");
			}
			
		}

	}

	static PEDemoSegmentBean populateSegmentBean(PEDemoIdNameBean sparkIdNameBean) {
		PEDemoSegmentBean sparkSegBean = new PEDemoSegmentBean();
		String segmentTitle = sparkIdNameBean.getSparkAccountName();
		
		String sparkId = MaskHelper.encrypt(sparkIdNameBean.getSparkId(), PEDemoConstants.PEDEMO_MASK_KEY);
		if (segmentTitle != null && segmentTitle.length() > 0) {
			segmentTitle = segmentTitle.replaceAll("&([a-z]+|#[0-9]+);", " ").replaceAll("^\\s*|\\s*$|\\\\", "")
					.replaceAll("\\s+", " ");
			// remove illegal characters from the name
			String segmentName = segmentTitle.replaceAll("[^a-zA-Z0-9 ]", "").replaceAll("^\\s*", "")
					.replaceAll("\\s*$", "").replaceAll("\\s+", "-").toLowerCase();
			String uuid = String.valueOf(segmentTitle.hashCode());
			if (segmentName.length() == 0) {
				segmentName = "segment-" + uuid;
			} else if (segmentName.length() != segmentTitle.length()) {
				// some characters were removed from the name, so we need to add  pseudo-randomuuid in exchange, otherwise "Test $" will be considered same as "Test"
				segmentName += "-" + uuid;
			}
			String segmentNameOriginal=segmentName;
			segmentName =MaskHelper.convertStringToHex(segmentName); 
			log.debug(sparkIdNameBean.getSparkId()+" -- " + sparkId +" -- segnameoriginal--"+segmentNameOriginal+" -- segnamehexcode -- "+segmentName);
					
			sparkSegBean.setSegmentName(segmentName);
			sparkSegBean.setSegmentTitle(segmentTitle);
		}
		sparkSegBean.setBoostFactor(BOOST);
		TraitBean traitBean = new TraitBean();
		traitBean.setPropKey(TRAIT_USER_PROFILE_ID_KEY_PROP_VAL);
		traitBean.setPropValue(sparkId);
		ArrayList<TraitBean> traitList = new ArrayList<TraitBean>();
		traitList.add(traitBean);
		sparkSegBean.setTraitList(traitList);
		return sparkSegBean;
	}

	static void createSegmentFromBean(SlingHttpServletRequest request, PEDemoSegmentBean segmentBean)
			throws WCMException, PersistenceException {
	
		log.debug("::::: Creating Segment :::::: "+segmentBean.getSegmentTitle());
		ResourceResolver resourceResolver = request.getResourceResolver();
		PageManager pageManager = (PageManager) resourceResolver.adaptTo(PageManager.class);
		Resource segmentTemplate = resourceResolver.getResource(AND_SEGMENT_TEMPLATE_PATH_WITH_PROPERTIES);
		String segmentPath = SEGMENT_ROOT + "/" + segmentBean.getSegmentName();
		Resource newSegment = pageManager.copy(segmentTemplate, segmentPath, null, false, true);

		/* set new segment details */
		ModifiableValueMap segmentProperties = newSegment.getChild(JcrConstants.JCR_CONTENT)
				.adaptTo(ModifiableValueMap.class);
		segmentProperties.put("segmentName", segmentBean.getSegmentName());
		segmentProperties.put("segmentBoost", segmentBean.getBoostFactor());
		segmentProperties.put("jcr:title", segmentBean.getSegmentTitle());

		Resource leftNodeResource = resourceResolver.getResource(newSegment.getPath() + LEFT_NODE_PATH);
		ModifiableValueMap leftSegmentProperties = leftNodeResource.adaptTo(ModifiableValueMap.class);
		leftSegmentProperties.put(TRAIT_USER_PROFILE_ID_KEY_PROP, TRAIT_USER_PROFILE_ID_KEY_PROP_VAL);

		Resource righttNodeResource = resourceResolver.getResource(newSegment.getPath() + RIGHT_NODE_PATH);
		ModifiableValueMap rightSegmentProperties = righttNodeResource.adaptTo(ModifiableValueMap.class);
		rightSegmentProperties.put(TRAIT_USER_PROFILE_VALUE_PROP, segmentBean.getTraitList().get(0).getPropValue());

		commitCounter++;

		if (commitCounter == 100 || sparkIdListSize == commitCounter) {
			resourceResolver.commit();
			log.debug("counter reset for resolver commit ");
			commitCounter = 0;
		} 

	}

}
