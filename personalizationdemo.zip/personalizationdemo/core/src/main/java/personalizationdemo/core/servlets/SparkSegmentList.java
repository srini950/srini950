package personalizationdemo.core.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.utils.MaskHelper;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Segment List",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "segmentList" })
public class SparkSegmentList extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(SparkSegmentList.class);
	private static String segmentPath = "";

	@Reference
	private QueryBuilder queryBuilder;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		log.debug("in SparkSegmentList do get ");

		try {

			String path;
			String sparkId = "";
			String accountName;
			final PrintWriter out = response.getWriter();
			ResourceResolver resourceResolver = request.getResourceResolver();

			segmentPath = request.getParameter("segmentPath");

			Session session = resourceResolver.adaptTo(Session.class);
			Node accountJsonnode = session.getNode(PEDemoConstants.ACCOUNT_JSON_PATH);
			Asset asset = resourceResolver.getResource(accountJsonnode.getPath()).adaptTo(Asset.class);
			JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
			JsonObject jsonObj = obj.getAsJsonObject();
			JsonArray jsonArray = jsonObj.getAsJsonArray("accountmap");
			Map<String, String> segmentListMap = new HashMap<String, String>();
			final Map<String, String> map = new HashMap<String, String>();

			map.put("path", segmentPath);
			map.put("nodename", "right");
			map.put("orderby", "@jcr:content/jcr:lastModified");
			map.put("p.limit", "-1");

			Query query = queryBuilder.createQuery(PredicateGroup.create(map), resourceResolver.adaptTo(Session.class));
			SearchResult result = query.getResult();

			for (final Hit hit : result.getHits()) {
				path = hit.getPath();
				Node node = resourceResolver.getResource(path).adaptTo(Node.class);
				if (node.hasProperty("value")) {
					sparkId = MaskHelper.decrypt(node.getProperty("value").getString(),PEDemoConstants.PEDEMO_MASK_KEY);
				}
				for (int i = 0; i < jsonArray.size(); i++) {
					JsonObject rec = jsonArray.get(i).getAsJsonObject();
					String key = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("id").toString());
					if (key.equalsIgnoreCase(sparkId)) {
						accountName = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("accountname").toString());
						segmentListMap.put(accountName,key);
						break;
					}
				}
				
				
			}
			
			Map<String, String> treeMap = new TreeMap<>(segmentListMap);
			ObjectMapper mapper = new ObjectMapper();
			out.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(treeMap));
			out.flush();

		} catch (Exception e) {
			log.error("exception in SegmentListServlet {}", e.getMessage());
			log.debug("Exception in SegmentListServlet {}", e.getMessage());
		}

	}

}
