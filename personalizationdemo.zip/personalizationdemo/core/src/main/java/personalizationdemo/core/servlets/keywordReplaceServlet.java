package personalizationdemo.core.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.services.GetLoggedInUser;
import personalizationdemo.core.utils.MaskHelper;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Keyword Replace Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "keywordReplaceServlet" })
public class keywordReplaceServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(keywordReplaceServlet.class);
	@Reference
	GetLoggedInUser userInfo;

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		ResourceResolver resourceResolver=null;
		Session session = null;
		
		try {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, PEDemoConstants.PEDEMO_SUB_SERVICE);
			 resourceResolver = resolverFactory.getServiceResourceResolver(param);
			 session = resourceResolver.adaptTo(Session.class);
			Node keywordJsonnode = session.getNode(PEDemoConstants.KEYWORD_REPLACE_PATH);
			Asset asset = resourceResolver.getResource(keywordJsonnode.getPath()).adaptTo(Asset.class);
			JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
			JsonObject jsonObj = obj.getAsJsonObject();
			Map<String, String> keywordListMap = new HashMap<String, String>();
			String id = MaskHelper.decrypt(request.getParameter("pedemoid"), PEDemoConstants.PEDEMO_MASK_KEY);
				String values = jsonObj.get(id.toUpperCase()).toString();
				if (values != null) {
					keywordListMap.put(id, values);
				} else {
					keywordListMap.put(id, "");
				}

			response.setContentType("application/json");
			final PrintWriter out = response.getWriter();
			ObjectMapper mapper = new ObjectMapper();
			out.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(keywordListMap));
			out.flush();

		} catch (Exception e) {
			log.error("exception in Servlet {}", e.getMessage());
			log.debug("Exception in Servlet {}", e.getMessage());
		}
		finally {
			 session.logout();
			 resourceResolver.close();
		}

	}
}
