package personalizationdemo.core.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.jcr.Node;
import javax.jcr.Session;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import personalizationdemo.core.bean.CarouselComponentBean;
import personalizationdemo.core.bean.CarouselComponentCardBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class CarouselComponent extends WCMUsePojo{

	String prop = "";
	CarouselComponentBean carouselComponentBean = null;
	private static final Logger logger = LoggerFactory.getLogger(CarouselComponent.class);
	String ctaBtnLink = "";


	@Override
	public void activate() {
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		try {
			carouselComponentBean = new  CarouselComponentBean(); 
			prop = get("prop", String.class);
			resourceResolver = resolverInterface.getResolver();
			session = resourceResolver.adaptTo(Session.class);
			String pedemoID = UtilityHelper.getSparkId(getRequest());

			String fieldType = getProperties().get("fieldType", "");
			String fieldValue = getProperties().get("fieldValue", "");
			String carHeader = getProperties().get("carHeader", "");
			String carTeaser = getProperties().get("carTeaser","");
			String staticURL = getProperties().get("urlCTA","");
			if(pedemoID!=null && staticURL !=null && staticURL !="" && staticURL.contains(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
					if(staticURL.contains(".html"))
						staticURL = staticURL + "/" + pedemoID;
					else
						staticURL = staticURL + ".html/" + pedemoID;							
			}	
			if(null != staticURL && !"".equals(staticURL) && !staticURL.startsWith("/content")){
				if(!(staticURL.startsWith("http") || staticURL.startsWith("https")))
					staticURL = "https://" + staticURL;
			}
			String ctaBtnTxt = getProperties().get("textCTA","");
			String seconds = getProperties().get("seconds","");
			

			if(prop!=null)
				carouselComponentBean.setCardList(getCardLists(prop));
			
			carouselComponentBean.setCardTitle(carHeader);
			carouselComponentBean.setCarTeaser(carTeaser);
			carouselComponentBean.setStaticURL(staticURL);
			carouselComponentBean.setCtaBtnTxt(ctaBtnTxt);
			if (seconds.equals("")) {
				carouselComponentBean.setSeconds("3");
			}else {
				carouselComponentBean.setSeconds(seconds);
			}

			Asset asset = null;

			Node masterjsonnode = session.getNode(PEDemoConstants.masterDynamicPath);
			asset = resourceResolver.getResource(masterjsonnode.getPath()).adaptTo(Asset.class);
			logger.debug("asset path {}",asset.getPath());
			ctaBtnLink = UtilityHelper.getFieldValueCTALink(asset, pedemoID, fieldType, fieldValue);
			carouselComponentBean.setCtadyanmicLink(ctaBtnLink);
			String uniqueID = UUID.randomUUID().toString();
			carouselComponentBean.setUniqueID(uniqueID);

		} catch (Exception e) {
			logger.debug("Exception logged in manual flow: {}",e.getMessage());
			logger.error("Exception logged in manual flow: {}",e.getMessage());
		}
		finally {
			session.logout();
			resourceResolver.close();
		}

	}

	public CarouselComponentBean getCarouselComponentBean() {
		return this.carouselComponentBean;
	}

	public List<CarouselComponentCardBean> getCardLists(String prop) throws Exception{

		List<CarouselComponentCardBean> beanList = new ArrayList<CarouselComponentCardBean>();

		try{

			String[] itemsProps = getProperties().get(prop, String[].class);
			if(itemsProps != null){
				for(int i =0; i < itemsProps.length; i++){
					ObjectMapper mapper = new ObjectMapper();
					Map<String, String> propertyMap = new HashMap<>();
					propertyMap = mapper.readValue(itemsProps[i], new TypeReference<Map<String, String>>(){});
					CarouselComponentCardBean bean = new CarouselComponentCardBean();
					bean.setCardTitle(null!=propertyMap.get("manualCardTitle") ? propertyMap.get("manualCardTitle") : "");
					bean.setCardIcon(null!=propertyMap.get("manualCardIcon") ? propertyMap.get("manualCardIcon") : "");
					bean.setCardTeaser(null!=propertyMap.get("manualCardTeaser") ? propertyMap.get("manualCardTeaser") : "");
					String ctaUrl = null!=propertyMap.get("manualCTALink") ? propertyMap.get("manualCTALink") : "";
					String pedemoID = UtilityHelper.getPageSuffix(getRequest());
					if(pedemoID !=null) {					
					}
					else if(getRequest().getCookie("pedemoIDCookie")!=null) {
						if(getRequest().getCookie("pedemoIDCookie").getValue()!=null && getRequest().getCookie("pedemoIDCookie").getValue()!=""){
							pedemoID=getRequest().getCookie("pedemoIDCookie").getValue();
						}	
					}
					if(pedemoID!=null && ctaUrl!=null && ctaUrl!=""  && ctaUrl.contains(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
						if(ctaUrl.contains(".html"))
							ctaUrl = ctaUrl + "/" + pedemoID;
						else
							ctaUrl = ctaUrl + ".html/" + pedemoID;
					}
					if(null != ctaUrl && !"".equals(ctaUrl) && !ctaUrl.startsWith("/content")){
						if(!(ctaUrl.startsWith("http") || ctaUrl.startsWith("https")))
							 ctaUrl = "https://" + ctaUrl;
					}
					bean.setCardUrl(ctaUrl);
					bean.setCardNewWindow(null!=propertyMap.get("openNewTab") ? propertyMap.get("openNewTab") : "");
					beanList.add(bean);
				}
			}
		}catch(Exception e){
			logger.debug("Exception logged in retrieving multifield values: {}",e.getMessage());
			logger.error("Exception logged in retrieving multifield values: {}",e.getMessage());
			throw e;
		}
		return beanList;
	}

}
