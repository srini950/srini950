package personalizationdemo.core.models;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import personalizationdemo.core.utils.UtilityHelper;

public class TextImageComponentModel extends WCMUsePojo {

	private static final Logger log = LoggerFactory.getLogger(TextImageComponentModel.class);
	public String text;
	public String sparkImage;
	public String imageAlignment;

	@Override
	public void activate() {
		
		
		try {
			log.debug("::::::::TextImageComponentModel activate::::::::::");

						String pedemoID = UtilityHelper.getSparkId(getRequest());
					
						if (pedemoID != null && pedemoID != "") {
							text = UtilityHelper.parseAnchorElementForAX(getProperties().get("text", ""), pedemoID);
						}else {
							text = UtilityHelper.parseAnchorElementForAX(getProperties().get("text", ""), "");
						}
						log.debug("text val new ::: {}" , text);
						sparkImage = getProperties().get("sparkImage", "");
						imageAlignment = getProperties().get("imageAlign", "");
		}catch(Exception e) {
			log.debug("Exception in TextImageComponentModel {}",e.getMessage());
		}
	}

	public String getText() {
		return text;
	}

	public String getSparkImage() {
		return sparkImage;
	}

	public String getImageAlignment() {
		return imageAlignment;
	}

}
