package personalizationdemo.core.models;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;

public class GetCurrentPageInfo extends WCMUsePojo {
	private static final Logger logger = LoggerFactory.getLogger(GetCurrentPageInfo.class);
	private String pageName = "";
	private String pageType = "pageTemplateName";
	private String pageVersion = "master";
	private String contentLevel1 = "";
	private String contentLevel2 = "";
	private String contentLevel3 = "";


	@Override
	public void activate()  {
						// TODO Auto-generated method stub
		try {
						logger.debug("in GetCurrentPageInfo activate");
						Page currentPage = getCurrentPage();
						
						
						if(currentPage!=null)
						{
							pageName = currentPage.getName();
							int depth = currentPage.getDepth();
							String templatePath=getPageProperties().get("cq:template","");
							
							if(templatePath!=null) {
								logger.debug("current template path {}",templatePath);
								pageType=templatePath.substring(templatePath.lastIndexOf("/")+1);
							}
							
							logger.debug("Get Page Type {}",pageType);
							logger.debug("GetCurrentPageInfo depth {}",depth);
							
							if (depth == 4) {
								contentLevel1 = pageName;
								contentLevel2 = pageName;
								contentLevel3 = pageName;
								
							}
							if (depth == 5) {
								contentLevel1 = currentPage.getParent().getName();
								contentLevel2 = contentLevel1 + ":" + pageName;
								contentLevel3 = contentLevel2;
								
							}
							if (depth == 6) {
								contentLevel1 = currentPage.getParent().getParent().getName();
								contentLevel2 = contentLevel1 + ":" + currentPage.getParent().getName();
								contentLevel3 = contentLevel2 + ":" + pageName;
							}
							
						}
						
						
						
						logger.debug("GetCurrentPageInfo pageName {}",pageName);
						logger.debug("GetCurrentPageInfo pageType {}",pageType);
						logger.debug("contentLevel1 {}",contentLevel1);
						logger.debug("contentLevel2 {}",contentLevel2);
						logger.debug("contentLevel3 {}",contentLevel3);
		}catch(Exception e) {
			logger.debug("Exception in GetCurrentPageInfo {}",e.getMessage());
			logger.error("Exception in GetCurrentPageInfo {}",e.getMessage());
		}

	}

	public String getPageName() {
		return pageName;
	}

	public String getPageType() {
		return pageType;
	}

	public String getPageVersion() {
		return pageVersion;
	}

	public String getContentLevel1() {
		return contentLevel1;
	}

	public String getContentLevel2() {
		return contentLevel2;
	}

	public String getContentLevel3() {
		return contentLevel3;
	}


}
