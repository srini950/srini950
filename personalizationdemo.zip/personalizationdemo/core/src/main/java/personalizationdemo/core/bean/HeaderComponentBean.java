package personalizationdemo.core.bean;

import java.util.List;
import personalizationdemo.core.bean.HeaderComponentCategoryBean;

public class HeaderComponentBean {
	
	private String bookingLink;
	private String homePageLink;
	private String bookingLinkValue;
	private String logoImgPath;
	private String siteName;
	private String headerComPath;
	private String currentPagePath;
	private String errorPage;
	private String genericErrorPage;
	private String corpTravelerPage;
	
	private List<HeaderComponentCategoryBean> categoryList = null;

	public String getBookingLink() {
		return bookingLink;
	}

	public void setBookingLink(String bookingLink) {
		this.bookingLink = bookingLink;
	}

	public String getHomePageLink() {
		return homePageLink;
	}

	public void setHomePageLink(String homePageLink) {
		this.homePageLink = homePageLink;
	}

	public String getBookingLinkValue() {
		return bookingLinkValue;
	}

	public void setBookingLinkValue(String bookingLinkValue) {
		this.bookingLinkValue = bookingLinkValue;
	}

	public String getLogoImgPath() {
		return logoImgPath;
	}

	public void setLogoImgPath(String logoImgPath) {
		this.logoImgPath = logoImgPath;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getHeaderComPath() {
		return headerComPath;
	}

	public void setHeaderComPath(String headerComPath) {
		this.headerComPath = headerComPath;
	}

	public List<HeaderComponentCategoryBean> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<HeaderComponentCategoryBean> categoryList) {
		this.categoryList = categoryList;
	}

	public String getCurrentPagePath() {
		return currentPagePath;
	}

	public void setCurrentPagePath(String currentPagePath) {
		this.currentPagePath = currentPagePath;
	}

	public String getErrorPage() {
		return errorPage;
	}

	public void setErrorPage(String errorPage) {
		this.errorPage = errorPage;
	}

	public String getGenericErrorPage() {
		return genericErrorPage;
	}

	public void setGenericErrorPage(String genericErrorPage) {
		this.genericErrorPage = genericErrorPage;
	}

	public String getCorpTravelerPage() {
		return corpTravelerPage;
	}

	public void setCorpTravelerPage(String corpTravelerPage) {
		this.corpTravelerPage = corpTravelerPage;
	}



}
