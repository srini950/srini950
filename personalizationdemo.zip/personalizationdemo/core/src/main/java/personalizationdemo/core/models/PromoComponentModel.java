package personalizationdemo.core.models;
import javax.jcr.Node;
import javax.jcr.Session;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import personalizationdemo.core.bean.PromoComponentBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class PromoComponentModel extends WCMUsePojo {
	PromoComponentBean promoComponentBean = null;

	/** Default log. */
	private static final Logger logger = LoggerFactory.getLogger(PromoComponentModel.class);
	String ctaBtnLink = "";
	String promoCode = "";
	String pedemoID="";

	@Override
	public void activate()  {
		promoComponentBean = new PromoComponentBean();
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		try {
		logger.debug("PromoComponentModel activate ");
		resourceResolver = resolverInterface.getResolver();
		session = resourceResolver.adaptTo(Session.class);
		logger.debug("session {}",session.getUserID());
		pedemoID = UtilityHelper.getSparkId(getRequest());

		String fieldType = getProperties().get("fieldType", "");
		String fieldValue = getProperties().get("fieldValue", "");
		String promoText = getProperties().get("promoText", "");
		String buttonCTA = getProperties().get("buttonCTA", "");
		String alignment = getProperties().get("alignment", "");
		String btnType = getProperties().get("btnType","");
		String ctaStaticLink = getProperties().get("ctaStaticLink","");
		
		if(pedemoID!=null && ctaStaticLink !=null && ctaStaticLink !="" && ctaStaticLink.contains("/content/pedemo/")){
			if(ctaStaticLink.contains(".html"))
				ctaStaticLink = ctaStaticLink + "/" + pedemoID;
			else
				ctaStaticLink = ctaStaticLink + ".html/" + pedemoID;
					
		}
		logger.debug("btnType {}",btnType);
		logger.debug("fieldName:: " + fieldValue + " fieldType:: " + fieldType + " promoText:: " + promoText
				+ " buttonCTA:: " + buttonCTA + " alignment:: " + alignment);
		
		if(null != ctaStaticLink && !"".equals(ctaStaticLink) && !ctaStaticLink.startsWith("/content")){
			if(!(ctaStaticLink.startsWith("http") || ctaStaticLink.startsWith("https")))
				 ctaStaticLink = "https://" + ctaStaticLink;
		}		
		promoComponentBean.setFieldValue(fieldValue);
		promoComponentBean.setPromoText(promoText);
		promoComponentBean.setButtonCTA(buttonCTA);
		promoComponentBean.setAlignment(alignment);
		promoComponentBean.setBtnType(btnType);
		promoComponentBean.setCtaStaticLink(ctaStaticLink);

		Node masterjsonnode = session.getNode(PEDemoConstants.masterDynamicPath);
		Asset asset = resourceResolver.getResource(masterjsonnode.getPath()).adaptTo(Asset.class);
		ctaBtnLink = UtilityHelper.getFieldValueCTALink(asset, pedemoID, fieldType, fieldValue);
		logger.debug("ctaBtnLink {}",ctaBtnLink);
		promoComponentBean.setDynamicUrlCTA(ctaBtnLink);
		}catch(Exception e) {
			logger.debug("exception is {}", e.getMessage());
		}
		finally {
			session.logout();
			resourceResolver.close();
		}
		
	}

	public PromoComponentBean getPromoComponentBean() {
		return this.promoComponentBean;

	}
	

}
