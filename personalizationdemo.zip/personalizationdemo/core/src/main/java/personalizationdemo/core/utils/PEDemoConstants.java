package personalizationdemo.core.utils;

public class PEDemoConstants {
	public static final String masterDynamicPath="/content/dam/pedemo/masterjsondata/masterdynamic.json";
	public static final String PEDEMO_ACCOUNTDATA_JSON_PATH="/content/dam/pedemo/masterjsondata/accountdata.json";
	public static final String ACCOUNT_JSON_PATH="/content/dam/pedemo/masterjsondata/accountidname.json";
	public static final String FIELDTYPE_DROPDOWN_PATH ="/content/dam/pedemo/masterjsondata/dynamicdropdown.json";
	public static final String excludePagePath = "/content/pedemo/exclude-pages-from-redirection/jcr:content/parsys/excludepagestarget";
	public static final String GENERAL_FIELDTYPE_DROPDOWN_PATH ="/content/dam/pedemo/masterjsondata/benefits-offers.json";
	public static final String BENEFITES_OFFER_MASTER_PATH= "/content/dam/pedemo/masterjsondata/benefits-offers-master.json";
	public static final String KEYWORD_REPLACE_PATH= "/content/dam/pedemo/masterjsondata/keywordReplace.json";
	public static final String ACCOUNT_MAP_ATTR = "accountmap";
	public static final String HTML_EXTENSION=".html";
	public static final String DCT_DETAILPAGE_TEMPLATE="/apps/personalizationdemo/templates/detailpage";
	public static final String PARTNERSHIPS_NAME="/content/dam/pedemo/masterjsondata/partnershipsName.json";
	public static final String PARTNERSHIPS_ACCOUNT = "/content/dam/pedemo/masterjsondata/partnerAccount.json";
	public static String PEDEMO_GROUPSEG_JSON_PATH = "/content/dam/pedemo/masterjsondata/groupsegments.json";
	public static final String PEDEMO_MASK_KEY="YTBTRBSQWFDLSOEXWGDBSRJDH";
	public static final String PEDEMO_SEG_PATH="/etc/segmentation/contexthub/pedemo";
	public static final String PEDEMO_SUB_SERVICE = "pedemoSegmentService";
	public static final String ADMIN_TECH_GROUP="administrators";
	public static final String AUTHOR_MARKETER_GROUP="content-authors";
	public static final String SELLER_AUTHOR_GROUP="aempedemofieldsales";
	public static final String PEDEMO_CONTENT_PREFIX = "/content/pedemo/";
	public static final String PEDEMO_CONTENT_HOME_PAGEPATH = "/content/pedemo/en/home.html";
}
