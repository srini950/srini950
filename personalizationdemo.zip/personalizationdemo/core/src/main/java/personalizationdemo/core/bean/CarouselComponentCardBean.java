package personalizationdemo.core.bean;

public class CarouselComponentCardBean {

	public String cardTitle;
	public String cardIcon;
	public String cardTeaser;
	public String cardUrl;
	public String cardNewWindow;
	public String getCardTitle() {
		return cardTitle;
	}
	public void setCardTitle(String cardTitle) {
		this.cardTitle = cardTitle;
	}
	public String getCardIcon() {
		return cardIcon;
	}
	public void setCardIcon(String cardIcon) {
		this.cardIcon = cardIcon;
	}
	public String getCardTeaser() {
		return cardTeaser;
	}
	public void setCardTeaser(String cardTeaser) {
		this.cardTeaser = cardTeaser;
	}
	public String getCardUrl() {
		return cardUrl;
	}
	public void setCardUrl(String cardUrl) {
		this.cardUrl = cardUrl;
	}
	public String getCardNewWindow() {
		return cardNewWindow;
	}
	public void setCardNewWindow(String cardNewWindow) {
		this.cardNewWindow = cardNewWindow;
	}
		
}
