package personalizationdemo.core.services;

public interface CreateORSegmentService {
	
	public void createORSegment(String jsonPath, String segmentRootPath, String orTemplatePath) throws Exception;

}
