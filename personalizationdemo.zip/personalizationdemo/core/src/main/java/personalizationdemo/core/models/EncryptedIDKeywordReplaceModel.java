package personalizationdemo.core.models;

import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.MaskHelper;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class EncryptedIDKeywordReplaceModel extends WCMUsePojo {
	private static final Logger logger = LoggerFactory.getLogger(EncryptedIDKeywordReplaceModel.class);
	ResourceResolver resourceResolver = null;
	Session session = null;
	String keywordList = "";
	String  encryptedKey="";

	@Override
	public void activate() {
		// TODO Auto-generated method stub
		try {
			GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
			resourceResolver =resolverInterface.getResolver();
			session = resourceResolver.adaptTo(Session.class);
			String sparkId = UtilityHelper.getPageSuffix(getRequest());
			if(sparkId!=null)
			{
				encryptedKey = MaskHelper.encrypt(sparkId.toUpperCase(),PEDemoConstants.PEDEMO_MASK_KEY);
				Node keywordJsonnode = session.getNode(PEDemoConstants.KEYWORD_REPLACE_PATH);
				Asset asset = resourceResolver.getResource(keywordJsonnode.getPath()).adaptTo(Asset.class);
				JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
				JsonObject jsonObj = obj.getAsJsonObject();

				Map<String, String> keywordListMap = new HashMap<String, String>();
				String values = null;
				if(jsonObj.has(sparkId.toUpperCase())) {
						 values = jsonObj.get(sparkId.toUpperCase()).toString();
				}
				if (values != null) {
					keywordListMap.put(encryptedKey, values);
				} else {
					keywordListMap.put(encryptedKey, "");
				}
				ObjectMapper mapper = new ObjectMapper();
				keywordList = mapper.writeValueAsString(keywordListMap);
			}
		} catch (Exception e) {
			logger.debug("::::::Exception in KeywordReplaceModel activate::::: {}", e.getMessage());
			logger.error("::::::Exception in KeywordReplaceModel activate::::: {}", e.getMessage());
		}
		finally {
			session.logout();
			resourceResolver.close();
		}	
	}

	public String getKeywordList() {
		return keywordList;
	}

	public String getEncryptedKey() {
		return encryptedKey;
	}

}
