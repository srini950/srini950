package personalizationdemo.core.services.impl;
import java.util.ArrayList;
import java.util.Iterator;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

import personalizationdemo.core.bean.GetPPRCompanyDetailsPOJO;
import personalizationdemo.core.bean.PEDemoSegmentBean;
import personalizationdemo.core.bean.TraitBean;
import personalizationdemo.core.services.SegmentDetails;
import personalizationdemo.core.utils.UtilityHelper;

@Component(service = SegmentDetails.class)
public class SegmentDetailsImpl implements SegmentDetails {

	private static final Logger LOG = LoggerFactory.getLogger(SegmentDetailsImpl.class);

	private static String TRAITS_NODE = "jcr:content/traits";
	private static String ANDPAR = "andpar";
	private static String ORPAR = "orpar";
	private static String SLASH = "/";
	private static String PROPERTY_KEY = "property";
	private static String PROP_VALUE = "value";
	private static String LEFT = "left";
	private static String RIGHT = "right";
	private static String SLING_RESOURCE_TYPE="sling:resourceType";
	private static String SEGMENT_NAME = "segmentName";
	private static String SEGMENT_BOOST = "segmentBoost";
	private static String CAMP_NODE = "/content/campaigns/";
	private static String MASTER_NODE="/master/jcr:content";
	private static String COM_SEG_PROPERTY = "showCombinedSegments";

	@Override
	public ArrayList<PEDemoSegmentBean> getSegmentDetails(ResourceResolver resourceResolver, String rootSegmentPath,
			ArrayList<GetPPRCompanyDetailsPOJO> pprCmplist) throws Exception{
		ArrayList<PEDemoSegmentBean> sparkSegmentBeanList = new ArrayList<PEDemoSegmentBean>();
		try {
		LOG.debug("in getSegmentDetails ================== {}",pprCmplist.size());
		String logUsrSegValue[] = new String [pprCmplist.size()];
		for(int i=0; i< pprCmplist.size(); i++) {
			GetPPRCompanyDetailsPOJO pprCmpDetails=pprCmplist.get(i);
			logUsrSegValue[i]=pprCmpDetails.getCompanyId();
		}

		boolean showCommonSeg = getshowCommonSeg(rootSegmentPath,resourceResolver);

		
		PageManager pageManager = (PageManager) resourceResolver.adaptTo(PageManager.class);
		Resource segmentRootResource = resourceResolver.getResource(rootSegmentPath);
		Iterable<Resource> childSegmentPages = segmentRootResource.getChildren();
		Iterator<Resource> childSegmentPagesIter = childSegmentPages.iterator();

		while (childSegmentPagesIter.hasNext()) {
			Resource res = childSegmentPagesIter.next();
			if (res.getName().equalsIgnoreCase(JcrConstants.JCR_CONTENT))
				continue;
			Page currentSegmentPage = pageManager.getPage(res.getPath());
			PEDemoSegmentBean sparkSegmentBean = new PEDemoSegmentBean();
			sparkSegmentBean=getSegmentProperties(currentSegmentPage, resourceResolver, logUsrSegValue, showCommonSeg);
			if(sparkSegmentBean.getSegmentName()!=null && sparkSegmentBean.getSegmentName()!="") {
				sparkSegmentBeanList.add(sparkSegmentBean);
			}
		}
	}catch (Exception e) {
		LOG.error("exception in getSegmentDetails {}", e.getMessage());
		LOG.debug("Exception in getSegmentDetails {}", e.getMessage());
		throw e;
	}

		// TODO Auto-generated method stub
		return sparkSegmentBeanList;
	}

	private boolean getshowCommonSeg(String rootSegmentPath, ResourceResolver resourceResolver)throws Exception {
		String[] campPath=rootSegmentPath.split("/");
		String campName=campPath[(campPath.length)-1];
		LOG.debug("campName  "+campName);
		Node masterNode = resourceResolver.getResource(CAMP_NODE + campName + MASTER_NODE).adaptTo(Node.class);
		try {
			if(masterNode.hasProperty(COM_SEG_PROPERTY)) {
				String comSegPropValue=masterNode.getProperty(COM_SEG_PROPERTY).getString().toString();
				if(comSegPropValue.equalsIgnoreCase("true")) {
					return true;
				}else {
					return false;
				}
			}
		} catch (Exception e) {
			LOG.error("exception in getshowCommonSeg {}", e.getMessage());
			LOG.debug("Exception in getshowCommonSeg {}", e.getMessage());
			throw e;
		}

		return false;
	}

	PEDemoSegmentBean getSegmentProperties(Page currentPage, ResourceResolver resourceResolver, String[] logUsrSegValue, boolean showCommonSeg )
			throws Exception{
		PEDemoSegmentBean sparkSegmentBean = new PEDemoSegmentBean();
		ValueMap currPageProperties = currentPage.getProperties();
		Node traitNode = resourceResolver.getResource(currentPage.getPath() + SLASH + TRAITS_NODE).adaptTo(Node.class);
		sparkSegmentBean.setTraitType(UtilityHelper.getPropertyValue(traitNode,SLING_RESOURCE_TYPE));
		int count=0;
		ArrayList<TraitBean> traitList=new ArrayList<TraitBean>();
		try {
			if (traitNode.hasNode(ANDPAR)){
				Node andParNode = resourceResolver.getResource(currentPage.getPath() + SLASH + TRAITS_NODE + SLASH + ANDPAR).adaptTo(Node.class);
				NodeIterator nodeIter = andParNode.getNodes();
				LOG.debug("ANDPAR node size "+nodeIter.getSize());
				if((nodeIter.getSize() > 1 && showCommonSeg) || (nodeIter.getSize() == 1) ) {
					while (nodeIter.hasNext()) {
						Node currentNode = (Node) nodeIter.next();
						LOG.debug("current node path "+currentNode.getPath());
						Node leftNode = resourceResolver.getResource(currentNode.getPath() + SLASH + LEFT).adaptTo(Node.class);
						Node rightNode = resourceResolver.getResource(currentNode.getPath() + SLASH + RIGHT).adaptTo(Node.class);
						TraitBean traitBean=populateTraitBean(leftNode,rightNode);
						if (traitBean != null) {
							LOG.debug("traitBean.getPropValue() ",traitBean.getPropValue());
							for(int i=0; i< logUsrSegValue.length; i++) {
								if(logUsrSegValue[i].equalsIgnoreCase(traitBean.getPropValue())) {
									count++;
									break;
								}								
							}	
						}
					}
				}
			} 
			else {
				Node orParNode = resourceResolver.getResource(currentPage.getPath() + SLASH + TRAITS_NODE + SLASH + ORPAR).adaptTo(Node.class);
				NodeIterator nodeIter = orParNode.getNodes();
				LOG.debug("node size ",nodeIter.getSize());
				if((nodeIter.getSize() > 1 && showCommonSeg) || (nodeIter.getSize() == 1) ) {
					while (nodeIter.hasNext()) {
						Node currentNode = (Node) nodeIter.next();
						LOG.debug("current node path ",currentNode.getPath());
						Node leftNode = resourceResolver.getResource(currentNode.getPath() + SLASH + LEFT).adaptTo(Node.class);
						Node rightNode = resourceResolver.getResource(currentNode.getPath() + SLASH + RIGHT).adaptTo(Node.class);
						TraitBean traitBean=populateTraitBean(leftNode,rightNode);
						if (traitBean != null) {
							LOG.debug("traitBean.getPropValue() ",traitBean.getPropValue());
							for(int i=0; i< logUsrSegValue.length; i++) {
								if(logUsrSegValue[i].equalsIgnoreCase(traitBean.getPropValue())) {
									count++;
									break;
								}								
							}	
						}
					}
				}
			}
		} catch (RepositoryException e) {
			LOG.error("exception in getSegmentProperties {}", e.getMessage());
			LOG.debug("Exception in getSegmentProperties {} ", e.getMessage());
			throw e;
		}
		LOG.debug("count ",count);
		if(count>0) {
			sparkSegmentBean.setSegmentTitle((String) currPageProperties.get(JcrConstants.JCR_TITLE));
			sparkSegmentBean.setSegmentName((String) currPageProperties.get(SEGMENT_NAME));
			sparkSegmentBean.setBoostFactor((Long) currPageProperties.get(SEGMENT_BOOST));
			sparkSegmentBean.setSegmentPath(currentPage.getPath());
			sparkSegmentBean.setSegmentResourceType((String) currPageProperties.get(SLING_RESOURCE_TYPE));
			sparkSegmentBean.setTraitList(traitList);
		}

		return sparkSegmentBean;
	}



	static TraitBean populateTraitBean(Node leftNode, Node rightNode)throws Exception
			 {
		TraitBean traitBean=null;

		if (leftNode != null && rightNode != null) {
			try {
				if (leftNode.hasProperty(PROPERTY_KEY) && rightNode.hasProperty(PROP_VALUE)) {
					traitBean=new TraitBean();
					traitBean.setPropKey(UtilityHelper.getPropertyValue(leftNode, PROPERTY_KEY));
					traitBean.setPropValue(UtilityHelper.getPropertyValue(rightNode, PROP_VALUE));

				}
			} catch (RepositoryException e) {
				LOG.error("exception in populateTraitBean {}", e.getMessage());
				LOG.debug("Exception in populateTraitBean {}", e.getMessage());
				throw e;
			}

		}

		return traitBean;

	}

}
