package personalizationdemo.core.services;

import java.util.ArrayList;

import org.apache.sling.api.resource.ResourceResolver;

public interface GetLoggedInUser {

	public String getUserId(ResourceResolver resolver);
	public String getUserName(ResourceResolver resolver) throws Exception;
	public ArrayList<String> getUserGroup(ResourceResolver resolver) throws Exception;
}
