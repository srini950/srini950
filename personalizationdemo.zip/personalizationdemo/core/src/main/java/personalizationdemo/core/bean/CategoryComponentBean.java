package personalizationdemo.core.bean;

public class CategoryComponentBean {
	
	private String shortname;
	private String preheader;
	private String title;
	private String teaser;
	private String sparkImage1;
	private String sparkImage2;
	private String iconImage;
	private String ctaButtonRequired;
	private String buttonType;
	private String buttonLabel;
	private String ctaUrl;
	private String fieldType;
	private String dynamicCTAUrl;
	private String imagePosition;
	private String openInNewWindow;
	
	public String getShortname() {
		return shortname;
	}
	public void setShortname(String shortname) {
		this.shortname = shortname;
	}
	public String getPreheader() {
		return preheader;
	}
	public void setPreheader(String preheader) {
		this.preheader = preheader;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTeaser() {
		return teaser;
	}
	public void setTeaser(String teaser) {
		this.teaser = teaser;
	}
	public String getSparkImage1() {
		return sparkImage1;
	}
	public void setSparkImage1(String sparkImage1) {
		this.sparkImage1 = sparkImage1;
	}
	public String getSparkImage2() {
		return sparkImage2;
	}
	public void setSparkImage2(String sparkImage2) {
		this.sparkImage2 = sparkImage2;
	}
	public String getIconImage() {
		return iconImage;
	}
	public void setIconImage(String iconImage) {
		this.iconImage = iconImage;
	}
	public String getButtonLabel() {
		return buttonLabel;
	}
	public void setButtonLabel(String buttonLabel) {
		this.buttonLabel = buttonLabel;
	}
	public String getCtaUrl() {
		return ctaUrl;
	}
	public void setCtaUrl(String ctaUrl) {
		this.ctaUrl = ctaUrl;
	}
	public String getImagePosition() {
		return imagePosition;
	}
	public void setImagePosition(String imagePosition) {
		this.imagePosition = imagePosition;
	}
	public String getButtonType() {
		return buttonType;
	}
	public void setButtonType(String buttonType) {
		this.buttonType = buttonType;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getDynamicCTAUrl() {
		return dynamicCTAUrl;
	}
	public void setDynamicCTAUrl(String dynamicCTAUrl) {
		this.dynamicCTAUrl = dynamicCTAUrl;
	}
	public String getCtaButtonRequired() {
		return ctaButtonRequired;
	}
	public void setCtaButtonRequired(String ctaButtonRequired) {
		this.ctaButtonRequired = ctaButtonRequired;
	}
	public String getOpenInNewWindow() {
		return openInNewWindow;
	}
	public void setOpenInNewWindow(String openInNewWindow) {
		this.openInNewWindow = openInNewWindow;
	}	
}
