package personalizationdemo.core.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import personalizationdemo.core.bean.CategoryComponentBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class CategoryDetailModel extends WCMUsePojo{

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	List<CategoryComponentBean> categoryItems = null;
	String categoryPath = "";
	
	@Override
	public void activate(){
		log.debug("Inside Activate method----CategoryDetailModel");
		categoryPath = getProperties().get("categoryPath","");
		categoryItems = retrieveAllDetailPages();
	}
	
	public List<CategoryComponentBean> retrieveAllDetailPages(){
		
		String pedemoID = UtilityHelper.getSparkId(getRequest());
		List<CategoryComponentBean> beanList = new ArrayList<CategoryComponentBean>();
		List<String> orderedPageList = new ArrayList<String>();
		List<String> childPagesList = new ArrayList<String>();
		List<String> nonOrderedPageList = new ArrayList<String>();
		List<String> filteredListofPagesforTargetedUser = new ArrayList<String>();
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		Map<String,String> queryMap = new HashMap<String,String>();
		String categoryID = "";
		
		try{
			resourceResolver=resolverInterface.getResolver();
			session = resourceResolver.adaptTo(Session.class);
			QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
			Node masterjsonnode = session.getNode(PEDemoConstants.masterDynamicPath);
			Asset asset = null;
			asset = resourceResolver.getResource(masterjsonnode.getPath()).adaptTo(Asset.class);
			log.debug("Asset path for Category Component"+asset.getPath());
			log.debug("REQUEST PATH::>>"+getRequest().getPathInfo());
			
			Property property = null;
			Value[] order = null;
			String rootPagePath = categoryPath;
			
			Resource pageResource = resourceResolver.getResource(rootPagePath+"/jcr:content");
			Node pageNode = pageResource.adaptTo(Node.class);
			categoryID = pageNode.hasProperty("catCategoryId") ? pageNode.getProperty("catCategoryId").getString() : "";
			categoryID = categoryID.replace(".html", "");
			
			if (pageNode.hasProperty("items")) {
	            property = pageNode.getProperty("items");
	        }
			if (property != null) {
	            if (property.isMultiple()) {
	            	for(int i=0 ; i < property.getValues().length ; i++)
	            		order = property.getValues();
	            } else {
	            	order = new Value[1];
	            	order[0] = property.getValue();
	            }
			}
			if(null != order){
				for(Value value : order){
					
					ObjectMapper mapper = new ObjectMapper();
					Map<String,String> propertyMap = new HashMap<String,String>();
					propertyMap = mapper.readValue(value.getString(), new TypeReference<Map<String,String>>() {});
					if(null!=propertyMap.get("categoryOrder")) {
						String detailPagePath = UtilityHelper.validatePage(propertyMap.get("categoryOrder"),resourceResolver);
						if(detailPagePath!=null) {
							orderedPageList.add(detailPagePath);
						}						
					}	
				}
			}
			queryMap.put("path",categoryID);
			queryMap.put("type", "cq:Page");
			queryMap.put("orderby", "@jcr:content/jcr:created");
			queryMap.put("orderby.sort", "desc");
			queryMap.put("p.limit", "-1");
			Query query = queryBuilder.createQuery(PredicateGroup.create(queryMap), session);
			SearchResult searchResult = query.getResult();
			if(null != searchResult){
				for(Hit hit : searchResult.getHits()){
					childPagesList.add(hit.getPath());
				}
			}
			log.debug("Child Page List for Category Component: {}",childPagesList);
			for(String item : childPagesList){
				if(!orderedPageList.contains(item))
					nonOrderedPageList.add(item);
			}
			log.debug("Non ordered Page List for Category Component: {}",nonOrderedPageList);
			for(int index = 0; index < nonOrderedPageList.size(); index++)
				orderedPageList.add(index, nonOrderedPageList.get(index));
			log.debug("Ordered page list for Category Component: {}",orderedPageList);
			for(String page : orderedPageList){
				if(UtilityHelper.checkpermissiontoshowInAuthor(pedemoID,page+"/jcr:content",resourceResolver,session,getRequest()) == false)
					filteredListofPagesforTargetedUser.add(page);
			}
			log.debug("Final Page List for Category Component: {}",filteredListofPagesforTargetedUser);
			
			for(String path : filteredListofPagesforTargetedUser){
				Resource res = resourceResolver.getResource(path+"/jcr:content");
				Node node = res.adaptTo(Node.class);
				String checkPageToAppearInAutomaticCategory = node.hasProperty("detailspageShowCategorypage") ? node.getProperty("detailspageShowCategorypage").getString() : "";
				String minimumAuthoring = node.hasProperty("dpPreHeaderCat") ? node.getProperty("dpPreHeaderCat").getString() : "";
				if(path.contains(categoryID) && ("true".equalsIgnoreCase(checkPageToAppearInAutomaticCategory)) && !"".equals(minimumAuthoring) && node.hasProperty("catCategoryId")){
					CategoryComponentBean categoryComponentBean = new CategoryComponentBean();
					categoryComponentBean.setPreheader(node.hasProperty("dpPreHeaderCat") ? node.getProperty("dpPreHeaderCat").getString() : "");
					categoryComponentBean.setTitle(node.hasProperty("dpTitleCat") ? node.getProperty("dpTitleCat").getString() : "");
					categoryComponentBean.setTeaser(node.hasProperty("dpBlurbCat") ? node.getProperty("dpBlurbCat").getString() : "");
					categoryComponentBean.setSparkImage1(node.hasProperty("dpImageFirstCat") ? node.getProperty("dpImageFirstCat").getString() : "");
					categoryComponentBean.setSparkImage2(node.hasProperty("dpImageSecondCat") ? node.getProperty("dpImageSecondCat").getString() : "");
					categoryComponentBean.setIconImage(node.hasProperty("dpiconlogodc") ? node.getProperty("dpiconlogodc").getString() : "");
					categoryComponentBean.setCtaButtonRequired(node.hasProperty("dpCTAButtonRequiredCat") ? node.getProperty("dpCTAButtonRequiredCat").getString() : "");
					if(node.getProperty("dpCTAButtonRequiredCat").getString().equalsIgnoreCase("true")) {
						categoryComponentBean.setButtonType(node.hasProperty("dpButtonCTACat") ? node.getProperty("dpButtonCTACat").getString() : "");
						categoryComponentBean.setButtonLabel(node.hasProperty("dpCTANameCat") ? node.getProperty("dpCTANameCat").getString() : "");
						String ctaURL = node.hasProperty("dpUrlCTACat") ? node.getProperty("dpUrlCTACat").getString() : "";
						if(null != pedemoID && !"".equals(ctaURL) && ctaURL.startsWith(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
							if(ctaURL.contains(".html"))
								ctaURL = ctaURL + "/" + pedemoID;
							else
								ctaURL = ctaURL + ".html/" + pedemoID;
						}
						if(!"".equals(ctaURL) && !ctaURL.startsWith(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
							if(!(ctaURL.startsWith("http") || ctaURL.startsWith("https")))
								 ctaURL = "https://" + ctaURL;
						}
						categoryComponentBean.setCtaUrl(ctaURL);
						String fieldType = node.hasProperty("dpFieldTypeCat") ? node.getProperty("dpFieldTypeCat").getString() : "";
						String fieldValue = node.hasProperty("dpFieldValueCat") ? node.getProperty("dpFieldValueCat").getString() : "";
						String dynamicButtonLink = UtilityHelper.getFieldValueCTALink(asset, pedemoID, fieldType, fieldValue);
						categoryComponentBean.setFieldType(fieldType);
						categoryComponentBean.setDynamicCTAUrl(null != dynamicButtonLink ? dynamicButtonLink : "");
						categoryComponentBean.setOpenInNewWindow(node.hasProperty("dpNewWindowCat") ? node.getProperty("dpNewWindowCat").getString() : "");
					}
					categoryComponentBean.setShortname(node.hasProperty("dpShortNameCat") ? node.getProperty("dpShortNameCat").getString() : "");
					beanList.add(categoryComponentBean);
				}
			}
			
		}catch(Exception e){
			log.debug("Exception logged : "+e);
		}finally {
			session.logout();
			resourceResolver.close();
		}	
		return beanList;
	}
	
	public List<CategoryComponentBean> getCategoryItems() {
		return categoryItems;
	}
	public String getCategoryPath() {
		return categoryPath;
	}
	
}
