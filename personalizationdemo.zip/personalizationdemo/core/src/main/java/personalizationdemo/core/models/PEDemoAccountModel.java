package personalizationdemo.core.models;

import java.util.List;



import personalizationdemo.core.bean.PEDemoAccounts;

public class PEDemoAccountModel {
	
	
	private List<PEDemoAccounts> peDemoAccounts;

	public List<PEDemoAccounts> getSparkAccounts() {
		return peDemoAccounts;
	}

	public void setSparkAccounts(List<PEDemoAccounts> peDemoAccounts) {
		this.peDemoAccounts = peDemoAccounts;
	}
	
    

}
