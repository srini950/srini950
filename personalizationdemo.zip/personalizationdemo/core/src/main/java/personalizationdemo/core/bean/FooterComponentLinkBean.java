package personalizationdemo.core.bean;

public class FooterComponentLinkBean {
	
	public String linkLabel;
	public String linkPath;
	public String openInNewWindow;
	public String getLinkLabel() {
		return linkLabel;
	}
	public void setLinkLabel(String linkLabel) {
		this.linkLabel = linkLabel;
	}
	public String getLinkPath() {
		return linkPath;
	}
	public void setLinkPath(String linkPath) {
		this.linkPath = linkPath;
	}
	public String getOpenInNewWindow() {
		return openInNewWindow;
	}
	public void setOpenInNewWindow(String openInNewWindow) {
		this.openInNewWindow = openInNewWindow;
	}
	
}
