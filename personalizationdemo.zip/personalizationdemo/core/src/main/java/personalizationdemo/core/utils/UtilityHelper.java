package personalizationdemo.core.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMMode;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.bean.Account;
import personalizationdemo.core.bean.PEDemoAccounts;
import personalizationdemo.core.models.PEDemoAccountModel;

public class UtilityHelper {

	private static final Logger log = LoggerFactory.getLogger(UtilityHelper.class);

	public static String getHomePagePath(String nodePath) {
		return nodePath.replace("/_jcr_content/header", "").concat("/home.html");
	}

	/**
	 * This method returns the value of the single valued property.
	 * 
	 * @param node
	 *            The current node.
	 * @param propertyName
	 *            The property name in the current node.
	 * @return String The value of the property.
	 * @throws RepositoryException
	 */
	public static String getPropertyValue(Node node, String propertyName) throws RepositoryException {
		String returnvalue = "";
		try {
			returnvalue = node.hasProperty(propertyName) ? node.getProperty(propertyName).getString() : "";
		} catch (PathNotFoundException e) {
			log.debug("exception getPropertyValue :::: {}", e.getMessage());
			log.error("exception in getPropertyValue::  {}", e.getMessage());
			throw e;
		} catch (RepositoryException e) {
			log.debug("exception getPropertyValue :::: {}", e.getMessage());
			log.error("exception in getPropertyValue::  {}", e.getMessage());
			throw e;
		}
		return returnvalue;
	}

	/**
	 * This method returns the values of the multi valued property.
	 * 
	 * @param node
	 *            The current node.
	 * @param propertyName
	 *            The property name in the current node.
	 * @return ArrayList. The values of the multi-valued property.
	 */
	public static ArrayList<String> getPropertyValues(Node node, String propertyName) throws Exception {
		ArrayList<String> returnvalues = new ArrayList<String>();
		try {

			if (node.hasProperty(propertyName)) {
				Property property = node.getProperty(propertyName);
				Value[] values = property.getValues();
				for (Value v : values) {
					returnvalues.add(v.getString());
				}
			}
		} catch (Exception e) {
			log.debug("exception getPropertyValues :::: {}", e.getMessage());
			log.error("exception in getPropertyValues::  {}", e.getMessage());
			throw e;
		}
		return returnvalues;
	}

	public static String removeQuotes(String originalString) {
		int stnlength = originalString.length();
		String retunString = originalString.substring(1, stnlength - 1);
		return retunString;

	}

	public static String getPageSuffix(SlingHttpServletRequest request) {
		String pageSuffix = null;
		if (request != null) {
			pageSuffix = request.getRequestPathInfo().getSuffix();
			if (pageSuffix != null) {
				pageSuffix = pageSuffix.replaceAll("/", "");
				pageSuffix = pageSuffix.replaceAll(".html", "");
			}
		}

		return pageSuffix;

	}

	public static String getJsonStringFromAsset(Asset asset) throws IOException {
		StringBuilder responseStrBuilder = new StringBuilder();
		if (asset != null) {
			InputStream is = asset.getOriginal().getStream();
			BufferedReader streamReader;
			try {
				streamReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				String inputStr;
				while ((inputStr = streamReader.readLine()) != null)
					responseStrBuilder.append(inputStr);
				streamReader.close();
			} catch (IOException e) {
				log.debug("exception getJsonStringFromAsset :::: {}", e.getMessage());
				log.error("exception in getJsonStringFromAsset::  {}", e.getMessage());
				throw e;
			}
		}
		return responseStrBuilder.toString();

	}

	public static String getFieldValueCTALink(Asset asset, String sparkID, String fieldType, String fieldName)
			throws IOException {
		String ctaBtnLink = "";
		if (asset != null) {
			InputStream is = asset.getOriginal().getStream();
			try {
				BufferedReader streamReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				StringBuilder responseStrBuilder = new StringBuilder();
				String inputStr;
				while ((inputStr = streamReader.readLine()) != null) {

					responseStrBuilder.append(inputStr);
				}
				

				Gson gson = new Gson();
				PEDemoAccountModel sparkAccountsModel = gson.fromJson(responseStrBuilder.toString(),
						PEDemoAccountModel.class);
				
				List<PEDemoAccounts> sparkAccounts = sparkAccountsModel.getSparkAccounts();
				
				
				for (int i = 0; i < sparkAccounts.size(); i++) {
					
					PEDemoAccounts account = sparkAccounts.get(i);
					Account accountObj = account.getAccount();

					if (accountObj.getID().equalsIgnoreCase(sparkID)
							&& accountObj.getFieldType().equalsIgnoreCase(fieldType)
							&& accountObj.getFieldName().equalsIgnoreCase(fieldName)) {
						ctaBtnLink = accountObj.getFieldValue();
						break;

					}
				}

			} catch (IOException e) {
				log.debug("exception getFieldValueCTALink :::: {}", e.getMessage());
				log.error("exception in getFieldValueCTALink::  {}", e.getMessage());
				System.out.println("exception "+e.getLocalizedMessage());
				throw e;
			}
		}
		return ctaBtnLink;
	}

	public static String parseAnchorElementForAX(String rteText, String contextHubID) throws Exception {
		Pattern p = Pattern.compile("(<a.*?</a>)");
		Matcher m = p.matcher(rteText);
		StringBuffer parsedAnchorElementVal = new StringBuffer();
		try {
			while (m.find()) {
				if (m.group().contains(" target=\"_blank\"")) {
					if (m.group().contains("/content/pedemo/")) {
						int hrefindex = m.group().indexOf("href=");
						int first = m.group().indexOf("\"", hrefindex);
						int second = m.group().indexOf("\"", first + 1);
						String orignalString = m.group().substring(first + 1, second);
						if (orignalString.endsWith(".html")) {
							m.appendReplacement(parsedAnchorElementVal,
									m.group().replaceAll(orignalString, (orignalString + "/" + contextHubID)));
						} else if (orignalString.endsWith(".html/")) {
							m.appendReplacement(parsedAnchorElementVal,
									m.group().replaceAll(orignalString, (orignalString + contextHubID)));
						}

					}
				} else {
					if (m.group().contains("/content/pedemo/")) {
						int hrefindex = m.group().indexOf("href=");
						int first = m.group().indexOf("\"", hrefindex);
						int second = m.group().indexOf("\"", first + 1);
						String orignalString = m.group().substring(first + 1, second);
						if (orignalString.endsWith(".html")) {
							m.appendReplacement(parsedAnchorElementVal,
									m.group().replaceAll(orignalString, (orignalString + "/" + contextHubID)));
						} else if (orignalString.endsWith(".html/")) {
							m.appendReplacement(parsedAnchorElementVal,
									m.group().replaceAll(orignalString, (orignalString + contextHubID)));
						}

					}
				}
			}
		} catch (Exception e) {
			log.debug("exception parseAnchorElementForAX :::: {}", e.getMessage());
			log.error("exception in parseAnchorElementForAX::  {}", e.getMessage());
			throw e;
		}
		m.appendTail(parsedAnchorElementVal);
		return parsedAnchorElementVal.toString();
	}

	public static String getSparkUrlString(String inputUrlStr, SlingHttpServletRequest request) {

		String pageSuffix = UtilityHelper.getSparkId(request);

		if (pageSuffix != null) {
			if (inputUrlStr != null && inputUrlStr.contains("/content/pedemo/"))
				inputUrlStr = inputUrlStr + "/" + pageSuffix;
		}

		return inputUrlStr;

	}

	public static String getSparkId(SlingHttpServletRequest request) {

		String pageSuffix = UtilityHelper.getPageSuffix(request);

		if (pageSuffix != null) {
			return pageSuffix;

		} else {

			if (request.getCookie("pedemoIDCookie") != null) {
				if (request.getCookie("pedemoIDCookie").getValue() != null
						&& request.getCookie("pedemoIDCookie").getValue() != "") {
					pageSuffix = request.getCookie("pedemoIDCookie").getValue();
				}
			}
		}

		return pageSuffix;

	}

	public static String getSparkRteString(String inputRteString, SlingHttpServletRequest request) throws Exception {
		String pageSuffix = UtilityHelper.getPageSuffix(request);
		if (pageSuffix != null)
			try {
				inputRteString = parseAnchorElementForAX(inputRteString, pageSuffix);
			} catch (Exception e) {
				log.debug("exception getSparkRteString :::: {}", e.getMessage());
				log.error("exception in getSparkRteString::  {}", e.getMessage());
				throw e;
			}
		return inputRteString;

	}

	public static boolean checkpermissiontoshow(String userId, String currentPagePath,
			ResourceResolver resourceResolver, Session session) throws Exception {

		Node currentPageNode = resourceResolver.getResource(currentPagePath).adaptTo(Node.class);
		String templateName = currentPageNode.hasProperty("cq:template")
				? currentPageNode.getProperty("cq:template").getString()
				: "";
		boolean pageRedirect = false;
		try {
			if (currentPageNode.hasProperty("catCategoryId")) {

				if (templateName.equalsIgnoreCase(PEDemoConstants.DCT_DETAILPAGE_TEMPLATE)) {
					if (currentPageNode.hasProperty("pagefieldType") && currentPageNode.hasProperty("pagefieldValue")) {
						int count = 0;
						int idcount = 0;
						String pagefieldType = currentPageNode.getProperty("pagefieldType").getString();
						String pagefieldValue = currentPageNode.getProperty("pagefieldValue").getString();
						String catCategoryId = currentPageNode.getProperty("catCategoryId").getString();
						log.debug("pagefieldType :: pagefieldValue::  {}", pagefieldType, pagefieldValue);
						log.debug("catCategoryId:: {}", catCategoryId);
						String[] splitCategoryId = catCategoryId.split("/");
						int lengthsplitCategoryId = splitCategoryId.length;
						String catgoryString = splitCategoryId[lengthsplitCategoryId - 1];
						int dotIndex = catgoryString.indexOf(".");
						if (dotIndex != -1) {
							catgoryString = catgoryString.substring(0, dotIndex);
						}
						Node benefiteOfferNode = session.getNode(PEDemoConstants.BENEFITES_OFFER_MASTER_PATH);
						Asset asset = resourceResolver.getResource(benefiteOfferNode.getPath()).adaptTo(Asset.class);
						JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
						JsonObject jsonObj = obj.getAsJsonObject();
						JsonArray jsonArray = jsonObj.getAsJsonArray("sparkAccounts");
						for (int i = 0; i < jsonArray.size(); i++) {
							JsonObject rec = jsonArray.get(i).getAsJsonObject();
							String id = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("ID").toString());
							if (id.equalsIgnoreCase(userId)) {
								idcount = 1;
								if (pagefieldType.equalsIgnoreCase(catgoryString)) {
									if (rec.getAsJsonArray(pagefieldType).isJsonArray()) {
										JsonArray catArray = rec.getAsJsonArray(pagefieldType);
										for (int j = 0; j < catArray.size(); j++) {
											String catValue = catArray.get(j).getAsString();
											if (catValue.equalsIgnoreCase(pagefieldValue)) {
												count = 1;
												break;
											}
										}
									}
								}
							}
							if (idcount == 1) {
								break;
							}
						}
						if (count == 0) {
							pageRedirect = true;
						}
					} else {
						pageRedirect = true;
					}
				}
			}
		} catch (Exception e) {
			log.debug("exception checkpermissiontoshow :::: {}", e.getMessage());
			log.error("exception in checkpermissiontoshow::  {}", e.getMessage());
			throw e;
		}
		return pageRedirect;
	}

	public static boolean checkpermissiontoshowInAuthor(String userId, String currentPagePath,
			ResourceResolver resourceResolver, Session session, SlingHttpServletRequest request) throws Exception {
		boolean pageRedirect = false;
		if (!(WCMMode.fromRequest(request) == WCMMode.DISABLED)) {
			return pageRedirect;
		}
		Node currentPageNode = resourceResolver.getResource(currentPagePath).adaptTo(Node.class);
		String templateName = currentPageNode.hasProperty("cq:template")
				? currentPageNode.getProperty("cq:template").getString()
				: "";

		try {
			if (currentPageNode.hasProperty("catCategoryId")) {
				if (templateName.equalsIgnoreCase(PEDemoConstants.DCT_DETAILPAGE_TEMPLATE)) {
					if (currentPageNode.hasProperty("pagefieldType") && currentPageNode.hasProperty("pagefieldValue")) {
						int count = 0;
						int idcount = 0;
						String pagefieldType = currentPageNode.getProperty("pagefieldType").getString();
						String pagefieldValue = currentPageNode.getProperty("pagefieldValue").getString();
						String catCategoryId = currentPageNode.getProperty("catCategoryId").getString();
						log.debug("pagefieldType :: " + pagefieldType + "  pagefieldValue:: " + pagefieldValue
								+ "  catCategoryId :: " + catCategoryId);
						String[] splitCategoryId = catCategoryId.split("/");
						int lengthsplitCategoryId = splitCategoryId.length;
						String catgoryString = splitCategoryId[lengthsplitCategoryId - 1];
						int dotIndex = catgoryString.indexOf(".");
						if (dotIndex != -1) {
							catgoryString = catgoryString.substring(0, dotIndex);
						}
						Node benefiteOfferNode = session.getNode(PEDemoConstants.BENEFITES_OFFER_MASTER_PATH);
						Asset asset = resourceResolver.getResource(benefiteOfferNode.getPath()).adaptTo(Asset.class);
						JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
						JsonObject jsonObj = obj.getAsJsonObject();
						JsonArray jsonArray = jsonObj.getAsJsonArray("sparkAccounts");
						for (int i = 0; i < jsonArray.size(); i++) {
							JsonObject rec = jsonArray.get(i).getAsJsonObject();
							String id = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("ID").toString());
							if (id.equalsIgnoreCase(userId)) {
								idcount = 1;
								if (pagefieldType.equalsIgnoreCase(catgoryString)) {
									if (rec.getAsJsonArray(pagefieldType).isJsonArray()) {
										JsonArray catArray = rec.getAsJsonArray(pagefieldType);
										for (int j = 0; j < catArray.size(); j++) {
											String catValue = catArray.get(j).getAsString();
											if (catValue.equalsIgnoreCase(pagefieldValue)) {
												count = 1;
												break;
											}
										}
									}
								}
							}
							if (idcount == 1) {
								break;
							}
						}
						if (count == 0) {
							pageRedirect = true;
						}
					} else {
						pageRedirect = true;
					}
				}
			}
		} catch (Exception e) {
			log.debug("exception checkpermissiontoshowInAuthor :::: {}", e.getMessage());
			log.error("exception in checkpermissiontoshowInAuthor:: {} ", e.getMessage());
			throw e;
		}
		return pageRedirect;
	}

	public static boolean isAuthorMode(SlingHttpServletRequest request) {
		boolean isAuthorMode = false;
		if (!(WCMMode.fromRequest(request) == WCMMode.DISABLED))
			isAuthorMode = true;

		return isAuthorMode;

	}

	public static boolean isValidSparkId(ResourceResolver resourceResolver, String userId) throws Exception {
		boolean validSparkId = false;
		if (userId != null) {
			if (userId.trim().length() == 0)
				return validSparkId;
			Session session = resourceResolver.adaptTo(Session.class);
			Node accountIDNameNode;
			try {
				accountIDNameNode = session.getNode(PEDemoConstants.ACCOUNT_JSON_PATH);
				Asset asset = resourceResolver.getResource(accountIDNameNode.getPath()).adaptTo(Asset.class);
				JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
				JsonObject jsonObj = obj.getAsJsonObject();
				JsonArray jsonArray = jsonObj.getAsJsonArray(PEDemoConstants.ACCOUNT_MAP_ATTR);
				for (int i = 0; i < jsonArray.size(); i++) {
					JsonObject rec = jsonArray.get(i).getAsJsonObject();
					String key = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("id").toString());
					if (key.equalsIgnoreCase(userId)) {
						validSparkId = true;
						break;
					}
				}
			} catch (Exception e) {
				log.debug("exception isValidSparkId :::: {}", e.getMessage());
				log.error("exception in isValidSparkId::  {}", e.getMessage());
				throw e;
			}

		}
		return validSparkId;

	}

	public static boolean checkSparkID(String pageSuffix) {
		boolean isID = false;
		if (pageSuffix.length() == 6 || pageSuffix.length() == 0) {
			isID = true;
		}
		return isID;
	}

	public static boolean dynamicFeatureComponentConditionCheck(String sparkId, String pagefieldType,
			String pagefieldValue, ResourceResolver resourceResolver, Session session, SlingHttpServletRequest request)
			throws Exception {

		boolean conditionMet = false;
		if (!(WCMMode.fromRequest(request) == WCMMode.DISABLED)) {
			conditionMet = true;
			return conditionMet;
		}

		try {

			int count = 0;
			int idcount = 0;

			log.debug("pagefieldType :: " + pagefieldType + "  pagefieldValue:: " + pagefieldValue);

			Node benefiteOfferNode = session.getNode(PEDemoConstants.BENEFITES_OFFER_MASTER_PATH);
			Asset asset = resourceResolver.getResource(benefiteOfferNode.getPath()).adaptTo(Asset.class);
			JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
			JsonObject jsonObj = obj.getAsJsonObject();
			JsonArray jsonArray = jsonObj.getAsJsonArray("sparkAccounts");
			for (int i = 0; i < jsonArray.size(); i++) {
				JsonObject rec = jsonArray.get(i).getAsJsonObject();
				String id = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("ID").toString());
				if (id.equalsIgnoreCase(sparkId)) {
					idcount = 1;
					if (rec.getAsJsonArray(pagefieldType).isJsonArray()) {
						JsonArray catArray = rec.getAsJsonArray(pagefieldType);
						for (int j = 0; j < catArray.size(); j++) {
							String catValue = catArray.get(j).getAsString();
							if (catValue.equalsIgnoreCase(pagefieldValue)) {
								count = 1;
								break;
							}
						}
					}
				}
				if (idcount == 1) {
					break;
				}
			}
			if (count == 1) {
				conditionMet = true;
			}
		} catch (Exception e) {
			log.debug("exception checkpermissiontoshowInAuthor :::: {}", e.getMessage());
			log.error("exception in checkpermissiontoshowInAuthor:: {} ", e.getMessage());
			throw e;
		}
		return conditionMet;
	}

	public static String getSegmentName(String segmentTitle) {

		String segmentName = "";
		if (segmentTitle != null && segmentTitle.length() > 0) {
			segmentTitle = segmentTitle.replaceAll("&([a-z]+|#[0-9]+);", " ").replaceAll("^\\s*|\\s*$|\\\\", "")
					.replaceAll("\\s+", " ");
			segmentName = segmentTitle.replaceAll("[^a-zA-Z0-9 ]", "").replaceAll("^\\s*", "").replaceAll("\\s*$", "")
					.replaceAll("\\s+", "-").toLowerCase();

		}
		return segmentName;
	}

	public static String validatePage(String pagePath, ResourceResolver resourceResolver) {

		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		Page detailPage = pageManager.getContainingPage(pagePath);
		if (detailPage != null) {
			return detailPage.getPath();
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T> T getConfig(String pid, String key) {
		log.debug("getConfiguration('{}.xml','{}')", pid);
		Object propValues = null;
		try {
			BundleContext bundleContext = FrameworkUtil.getBundle(UtilityHelper.class).getBundleContext();

			ServiceReference configurationAdminReference = bundleContext
					.getServiceReference(ConfigurationAdmin.class.getName());
			if (null != configurationAdminReference) {
				ConfigurationAdmin confAdmin = (ConfigurationAdmin) bundleContext
						.getService(configurationAdminReference);
				Configuration configuration = confAdmin.getConfiguration(pid);
				if (null != configuration.getProperties()) {
					propValues = configuration.getProperties().get(key);
				}
				return (T) propValues;
			}
		} catch (Exception e) {
			log.error("Error occured in getConfigProps of UtilityHelper {}", e);
		}
		return null;
	}

	public static String[] getSegmentPaths(String sparkId, Session session, ResourceResolver resourceResolver)
			throws Exception {
		String maskedSparkId = null;
		Set<String> uniqueSegmentList = null;
		String[] segmentPaths = null;
		List<String> segmentList = new ArrayList<String>();
		LinkedHashMap<String, Integer> reverseSortedMap = new LinkedHashMap<>();
		String jcrContentStr = "/jcr:content/";
		QueryManager queryManager = session.getWorkspace().getQueryManager();
		NodeIterator nodeIter = null;
		try {
			if (sparkId != null) {
				maskedSparkId = MaskHelper.encrypt(sparkId.toUpperCase(), PEDemoConstants.PEDEMO_MASK_KEY);
			}
			String queryStr = "SELECT * FROM [nt:unstructured] AS s WHERE  ISDESCENDANTNODE([{SEGPATH}]) AND CONTAINS(s.value, '{#}')";
			if (maskedSparkId != null) {
				queryStr = queryStr.replace("{#}", maskedSparkId);
				queryStr = queryStr.replace("{SEGPATH}", PEDemoConstants.PEDEMO_SEG_PATH);
				log.debug("queryStr is " + queryStr);
				Query querySegment = queryManager.createQuery(queryStr, Query.JCR_SQL2);
				QueryResult result = querySegment.execute();
				nodeIter = result.getNodes();
				String path = "";
				while (nodeIter.hasNext()) {
					path = nodeIter.nextNode().getPath();
					segmentList.add(path.substring(0, path.indexOf(jcrContentStr)));
				}
				uniqueSegmentList = new HashSet<String>(segmentList);
			}
			if (uniqueSegmentList != null) {
				Map<String, Integer> segmentMap = new HashMap<>();
				for (String segPath : uniqueSegmentList) {
					segmentMap.put(segPath, getBoost(segPath, resourceResolver));
				}
				segmentMap.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
						.forEachOrdered(x -> reverseSortedMap.put(x.getKey(), x.getValue()));
			}
			segmentPaths = new String[reverseSortedMap.size()];
			int i = 0;
			for (Map.Entry<String, Integer> entry : reverseSortedMap.entrySet()) {
				segmentPaths[i] = entry.getKey();
				i++;
			}
		} catch (Exception e) {
			log.error("Error in getSegmentPaths {}", e.getMessage());
			log.debug("Error in getSegmentPaths {}", e.getMessage());
			throw e;
		}
		return segmentPaths;
	}

	public static int getBoost(String nodePath, ResourceResolver resourceResolver) throws Exception {
		int boost = 0;
		try {
			Node currentNode = resourceResolver.getResource(nodePath).adaptTo(Node.class);
			if (currentNode.hasNode(JcrConstants.JCR_CONTENT)) {
				Node currentJCRNode = currentNode.getNode(JcrConstants.JCR_CONTENT);
				boost = Integer.parseInt(currentJCRNode.getProperty("segmentBoost").getString());
			}
		} catch (Exception e) {
			log.error("Error in getBoost {}", e.getMessage());
			log.debug("Error in getBoost {}", e.getMessage());
			throw e;
		}
		return boost;

	}

}
