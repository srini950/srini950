package personalizationdemo.core.services;
import org.apache.sling.api.resource.ResourceResolver;

public interface GetResolver {
	
	public ResourceResolver getResolver() throws Exception;
}
