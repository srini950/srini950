package personalizationdemo.core.models;

import com.adobe.cq.wcm.core.components.models.NavigationItem;
import com.day.cq.wcm.api.Page;
public class NavigationItemImpl implements NavigationItem
 {
   private Page page;
   private boolean active;
   private String pagePath;
   private String shortName;

   public NavigationItemImpl(Page page, boolean active, String pagePath, String shortName)
   {
     this.page = page;
     this.active = active;
     this.pagePath = pagePath;
     this.shortName = shortName;
     
   }

   public Page getPage()
  {
     return this.page;
   }

  public boolean isActive()
  {
     return this.active;
   }
   public String getPagePath() {
	return this.pagePath;
}

public void setPagePath(String pagePath) {
	this.pagePath = pagePath;
}

public String getShortName() {
	return this.shortName;
}

public void setShortName(String shortName) {
	this.shortName = shortName;
}


 }

