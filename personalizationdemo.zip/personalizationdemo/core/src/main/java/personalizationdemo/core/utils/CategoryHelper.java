package personalizationdemo.core.utils;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Value;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class CategoryHelper {
	public static final String CATEGORY_PROPERTY = "items";
	private static final Logger log = LoggerFactory.getLogger(CategoryHelper.class);
	public static Map<String, String> getCategoryTextId(Node component,	String propName) {		
		log.debug("getCategoryTextId start of method");
		Map<String, String> multifieldMap = new LinkedHashMap<String, String>();
		try {			
			Value[] leftValues = getValues(component, propName);
			String category="[ ";
			if(leftValues !=null) {
				for (int i = 0; i < leftValues.length; i++) {
					log.debug("leftValues {}" , leftValues[i].getString());
					category = category.concat(leftValues[i].getString());
					if (i < leftValues.length - 1) {
						category = category.concat(",");
					}
				}
			}
			multifieldMap.put("","Select a value");
			category=category.concat("]");
			JsonElement obj = new JsonParser().parse(category);
			JsonArray jsonArray= obj.getAsJsonArray();
			for(int i=0; i<jsonArray.size(); i++)            {
				JsonObject rec = jsonArray.get(i).getAsJsonObject();
				String categoryID = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("categoryPath").toString());
				String categoryName = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("categoryName").toString());
				log.debug("categoryID {}",categoryID);
				log.debug("categoryName {}",categoryName);
				multifieldMap.put(categoryID,categoryName);			
            }
			
		} catch (Exception e) {
			log.debug("Exception occured in getCategoryTextId method {}", e.getMessage());
			log.error("Exception occured in getCategoryTextId method {}", e.getMessage());
		}
		log.debug("getCategoryTextId end of method");
		return multifieldMap;

	}
	private static Value[] getValues(Node headerRes, String propertyName) throws RepositoryException{
		Value[] property = null;
		try {
			if (headerRes.hasProperty(propertyName)) {
				if (headerRes.getProperty(propertyName).isMultiple()) {
					property = headerRes.getProperty(propertyName).getValues();
				} else {
					property = new Value[] { headerRes.getProperty(propertyName).getValue() };
				}
			}
		} catch (RepositoryException e) {
			log.debug("Exception occured in getValues method {}", e.getMessage());
			log.error("Exception occured in getValues method {}", e.getMessage());
			throw e;
		}
		return property;
	}

}

