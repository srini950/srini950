package personalizationdemo.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import personalizationdemo.core.bean.GetPPRCompanyDetailsPOJO;
import personalizationdemo.core.bean.PEDemoSegmentBean;
import personalizationdemo.core.services.GetLoggedInUser;
import personalizationdemo.core.services.GetPPRCompanyDetails;
import personalizationdemo.core.services.SegmentDetails;
import personalizationdemo.core.utils.PEDemoConstants;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Audiences Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET,
		"sling.servlet.resourceTypes=" + "personalizationdemo/components/structure/ambitpage", "sling.servlet.extensions=" + "json",
		"sling.servlet.selectors=" + "audiences" })
public class PEDemoAudiencesServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(PEDemoAudiencesServlet.class);
	private static final String CONTEXTHUB_SEGMENT_PATH = "cq:contextHubSegmentsPath";


	ObjectMapper mapper = new ObjectMapper();

	private static enum SegmentSources {
		TNT("Adobe Target"), CLOUD("Marketing Cloud"), AEM("AEM");

		private String solution;

		private SegmentSources(String solutionName) {
			this.solution = solutionName;
		}

		public String getSolutionName() {
			return this.solution;
		}
	}

	@Reference
	GetLoggedInUser userInfo;

	@Reference
	GetPPRCompanyDetails pprCmpDtl;

	@Reference
	SegmentDetails sparkSegmentDetails;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("application/json");
		String engineType = request.getParameter("engine");
		String search = request.getParameter("search");
		String allAudiencesEnabled = request.getParameter("allAudiences");
		String sparkSegmentRootPath = "/etc/segmentation/contexthub/pedemo-experiences";
		boolean isSalestechadmin = false;
		boolean isB2b2CMarketer = false;
		boolean isFieldSales = false;
		log.debug("current resource " + request.getResource().getPath());
		Node currentNode = (Node) request.getResource().adaptTo(Node.class);

		try {
			log.debug("current node is {}", currentNode.getPath());
			if (currentNode.hasProperty(CONTEXTHUB_SEGMENT_PATH))
				sparkSegmentRootPath = currentNode.getProperty(CONTEXTHUB_SEGMENT_PATH).getString();

			if (currentNode.hasProperty("showCombinedSegments"))
				log.debug("::::::::::::::::::::combined segment :::::::::::::: {}",
						currentNode.getProperty("showCombinedSegments").getString());

		} catch (RepositoryException repositoryException) {
			log.error("exception in Page Number get of SparkAudiencesServlet {}", repositoryException);
		}
		int pageNo = 1;
		try {
			pageNo = Integer.parseInt(request.getParameter("page"));
		} catch (Exception localException) {
			log.error("exception in Page Number get of SparkAudiencesServlet {}", localException);
		}
		int pageSize = 100;
		try {
			pageSize = Integer.parseInt(request.getParameter("pageSize"));
		} catch (Exception localException1) {
			log.error("exception in Page Size get of SparkAudiencesServlet {}", localException1);
		}

		boolean showAllAudiences = Boolean.parseBoolean(allAudiencesEnabled);
		log.debug("show all audiences {}" , showAllAudiences);

		String searchAudienceResourceType = "cq/contexthub/components/segment-page";

		ResourceResolver resourceResolver = request.getResourceResolver();
		String userId = userInfo.getUserId(resourceResolver);
		ArrayList<String> userGroupInfo;		
		try {
			userGroupInfo = userInfo.getUserGroup(resourceResolver);
			for (int i = 0; i < userGroupInfo.size(); i++) {
				if (userGroupInfo.get(i).equalsIgnoreCase(PEDemoConstants.ADMIN_TECH_GROUP)) {
					isSalestechadmin = true;
				} else if (userGroupInfo.get(i).equalsIgnoreCase(PEDemoConstants.AUTHOR_MARKETER_GROUP)) {
					isB2b2CMarketer = true;
				} else if (userGroupInfo.get(i).equalsIgnoreCase(PEDemoConstants.SELLER_AUTHOR_GROUP)) {
					isFieldSales = true;
				}
			}
		} catch (Exception e2) {
			log.debug("::::::Exception in userGroupInfo SparkAudiencesServlet::::: {}", e2.getMessage());
			log.error("::::::Exception in userGroupInfo SparkAudiencesServlet::::: {}", e2.getMessage());
		}
		
		ArrayList<PEDemoSegmentBean> arrayList = new ArrayList<PEDemoSegmentBean>();
		if (isFieldSales) {
			ArrayList<GetPPRCompanyDetailsPOJO> pprCmplist;
			try {
				pprCmplist = pprCmpDtl.getPPRCompanyDetail(resourceResolver, userId);
				  arrayList = sparkSegmentDetails.getSegmentDetails(resourceResolver, sparkSegmentRootPath, pprCmplist);
			} catch (Exception e1) {
				log.debug("::::::Exception in arrayList SparkAudiencesServlet::::: {}", e1.getMessage());
				log.error("::::::Exception in arrayList SparkAudiencesServlet::::: {}", e1.getMessage());
			}
		}

		PageManager pageManager = (PageManager) resourceResolver.adaptTo(PageManager.class);
		Resource audiencesRootResource = null;
		@SuppressWarnings("unchecked")
		TreeSet<Resource> audienceList = new TreeSet(new Comparator() {
			public int compare(Object o1, Object o2) {
				Resource r1 = (Resource) o1;
				Resource r2 = (Resource) o2;
				Page p1 = (Page) r1.adaptTo(Page.class);
				Page p2 = (Page) r2.adaptTo(Page.class);
				ValueMap r1Props = p1.getProperties();
				ValueMap r2Props = p2.getProperties();
				String n1 = (String) r1Props.get("jcr:title", "") + p1.getPath();
				String n2 = (String) r2Props.get("jcr:title", "") + p2.getPath();
				return n1.compareToIgnoreCase(n2); 

			}
		});

		int skipCnt = (pageNo - 1) * pageSize;
		boolean hasMore = false;

		List<Resource> sourceAudienceRoots = new ArrayList<Resource>();

		if (!"tnt".equalsIgnoreCase(engineType)) {
			audiencesRootResource = resourceResolver.getResource(sparkSegmentRootPath);
			sourceAudienceRoots.add(audiencesRootResource);
		}

		for (Resource sourceRoot : sourceAudienceRoots) {
			if (sourceRoot != null) {
				for (Resource audienceRes : resourceResolver.getChildren(sourceRoot)) {
					if (audienceRes.getName().equalsIgnoreCase("jcr:content"))
						continue;

					Resource audienceContentRes = audienceRes.getChild("jcr:content");

					if ((!StringUtils.isNotEmpty(searchAudienceResourceType)) || (audienceContentRes == null)) {
						continue;
					}
					boolean matchesResourceType = audienceContentRes.isResourceType(searchAudienceResourceType);
					ValueMap audienceProps = audienceContentRes != null
							? (ValueMap) audienceContentRes.adaptTo(ValueMap.class)
							: null;

					boolean isVisible = audienceProps != null ? "reusable".equals(audienceProps.get("type", "reusable"))
							: false;

					if ((audienceRes.isResourceType("cq:Page")) && (matchesResourceType) && (isVisible)) {
						if (skipCnt > 0) {
							skipCnt--;
						} else {

							Page audiencePage = pageManager.getPage(audienceRes.getPath());
							String title = audiencePage.getTitle();

							if ((!StringUtils.isNotEmpty(search))
									|| (title.toLowerCase().contains(search.toLowerCase()))) {
								if (audienceList.size() < pageSize) {
									if (isFieldSales) {
										for (int i = 0; i < arrayList.size(); i++) {
											PEDemoSegmentBean sparkSegmentBean = arrayList.get(i);
											if (sparkSegmentBean.getSegmentTitle().equalsIgnoreCase(title)) {
												audienceList.add(audienceRes);
												break;
											}
										}
									} else if (isB2b2CMarketer || isSalestechadmin) {
										audienceList.add(audienceRes);
									}
								} else {

									hasMore = true;
									break;
								}
							}

						}
					}
				}
			}
		}

		ObjectNode jsonResponse = mapper.createObjectNode();

		ArrayNode jsonAudiences = mapper.createArrayNode();
		if (showAllAudiences) {
			addAudience(jsonAudiences, "all", "All Visitors", "");
		}
		for (Resource currentAudience : audienceList) {
			Page audiencePage = pageManager.getPage(currentAudience.getPath());
			ValueMap audienceProperties = audiencePage.getProperties();
			String source = (String) audienceProperties.get("source", "");
			String sourceProductName = (String) audienceProperties.get("sourceProductName", "");
			String sourceName;

			if (StringUtils.isNotEmpty(sourceProductName)) {
				sourceName = sourceProductName;
			} else {

				if (StringUtils.isEmpty(source)) {
					sourceName = SegmentSources.AEM.getSolutionName();
				} else {
					sourceName = SegmentSources.valueOf(source.toUpperCase()).getSolutionName();
				}
			}
			String suffix = "";
			String audienceName = (String) audienceProperties.get("jcr:title", "");
			audienceName = audienceName.replaceAll("(?is)-[0-9]{13}", "");
			if (SegmentSources.AEM.getSolutionName().equals(sourceName)) {
				suffix = audiencePage.getPath().contains("contexthub") ? " (CH)" : "";
			}
			addAudience(jsonAudiences, audiencePage.getPath(), audienceName + suffix, sourceName);
		}
		try {
			jsonResponse.put("page", pageNo);
			jsonResponse.put("pageSize", pageSize);
			jsonResponse.put("hasMore", hasMore);
			jsonResponse.putPOJO("items", jsonAudiences);
		} catch (Exception e) {
			this.log.warn("Can't serialize json response!", e);
		}
		log.debug("response {}" , jsonResponse);
		response.getWriter().print(jsonResponse.toString());

	}

	private void addAudience(ArrayNode jsonAudiences, String audienceId, String audienceName, String sourceName) {
		try {
			ObjectNode jsonAudience = mapper.createObjectNode();
			jsonAudience.put("id", audienceId);
			jsonAudience.put("name", audienceName);
			jsonAudience.put("origin", sourceName);

			jsonAudiences.add(jsonAudience);

		} catch (Exception e) {
			this.log.warn("Can't serialize audience to json, path="+ audienceId, e);
			log.debug("::::::Exception in serialize SparkAudiencesServlet::::: {}", e.getMessage());
			log.error("::::::Exception in serialize SparkAudiencesServlet::::: {}", e.getMessage());
		}
	}

}
