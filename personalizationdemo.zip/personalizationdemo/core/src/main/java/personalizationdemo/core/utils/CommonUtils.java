package personalizationdemo.core.utils;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.dam.api.Asset;
import personalizationdemo.core.bean.PEDemoIdNameBean;


public class CommonUtils {

	private static final Logger log = LoggerFactory.getLogger(CommonUtils.class);
	
	public static List<PEDemoIdNameBean> getFileValues(Asset asset)
			throws ValueFormatException, PathNotFoundException, RepositoryException, IOException {
		log.debug("::::in getfilevalues method :::");
		List<PEDemoIdNameBean> sparkIdList=new ArrayList<PEDemoIdNameBean>();
		if (asset != null) {
			  
			InputStream in = asset.getOriginal().getStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
			String line;
			while ((line = reader.readLine()) != null) {
				PEDemoIdNameBean sparkIdNameBean=new PEDemoIdNameBean();
				String[] fileValues=line.split("-");
		    	sparkIdNameBean.setSparkId(fileValues[0]);
		    	sparkIdNameBean.setSparkAccountName(fileValues[1]);
		    	sparkIdList.add(sparkIdNameBean);
			}
			reader.close();
			
		}

		return sparkIdList;

	}

}
