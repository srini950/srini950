package personalizationdemo.core.models;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import javax.jcr.Node;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.wcm.api.Page;

import personalizationdemo.core.services.GetResolver;

public class TwoColumnOrderModel extends WCMUsePojo{
	private static final Logger logger = LoggerFactory.getLogger(TwoColumnOrderModel.class);
	ResourceResolver resolver = null;
	@Override
	public void activate() {
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		
		try {
			logger.debug("::::::::in TwoColumnOrderModel activate::::::::::::::");
		
						resolver = resolverInterface.getResolver();
						//Creating the Map instance to insert the bookingURLs
						SlingHttpServletRequest request = getRequest();
						String categoryPath = request.getParameter("item");
						logger.debug("request getparam item: {}", categoryPath);
						final Map<String, String> bookingLinksDB = new LinkedHashMap<String, String>();
						Page categoryPage = resolver.resolve(categoryPath).adaptTo(Page.class);
						Iterator<Page> iteratorPage = categoryPage.listChildren();
						Iterable<Page> iterable = () -> iteratorPage;
						Stream<Page> categoryStream = StreamSupport.stream(iterable.spliterator(), false);
						categoryStream.forEach(
								detailPage->{
									String pageTitle = detailPage.getTitle();
									String pagePath = detailPage.getPath();
									bookingLinksDB.put(pagePath,pageTitle);
									});
						
						final Map<String, String> detailsPageMap= fetchDetailsPage(resolver ,bookingLinksDB);
						@SuppressWarnings("unchecked")
						  
						//Creating the Datasource Object for populating the drop-down control.
						 DataSource ds = new SimpleDataSource(new TransformIterator(detailsPageMap.keySet().iterator(), new Transformer() {
							 @Override
							  
							//Transforms the input object into output object
							 public Object transform(Object o) {
							 String bookingLink = (String) o;
								//Allocating memory to Map
								 ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
								//Populate the Map
								 vm.put("value", bookingLink);
								 vm.put("text", bookingLinksDB.get(bookingLink));
								 return new ValueMapResource(resolver, new ResourceMetadata(), "nt:unstructured", vm);
							 }
						 }));
						this.getRequest().setAttribute(DataSource.class.getName(), ds);
		}catch(Exception e) {
			logger.debug("exception in TwoColumnOrderModel {}",e.getMessage());
			logger.error("exception in TwoColumnOrderModel {}",e.getMessage());
			
		}
		  
	}
	private Map<String, String> fetchDetailsPage(ResourceResolver resolver, Map<String, String> bookingLinksDB) throws Exception {
		logger.debug(":::::fetchDetailsPage method ::::::");
		
		Map <String , String> detailsPageMiddleMap=new LinkedHashMap<String, String>();
		Iterator<Map.Entry<String, String>> itr = bookingLinksDB.entrySet().iterator();
		while(itr.hasNext()){
			Map.Entry<String, String> entry = itr.next();
			Node detailsPageNode = resolver.getResource(entry.getKey()).adaptTo(Node.class);
				
			 if(detailsPageNode!=null)
			 {
				if(detailsPageNode.hasNode("jcr:content")){
					Node detailsJCRContent=detailsPageNode.getNode("jcr:content");
					if(detailsJCRContent.hasProperty("catCategoryId")) {
						detailsPageMiddleMap.put(entry.getKey(), entry.getValue());
					}				
				}
			 }
			
		}         
		
		return detailsPageMiddleMap;
	}

}
