package personalizationdemo.core.models;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class AccountNameModel extends WCMUsePojo {
	private static final Logger logger = LoggerFactory.getLogger(AccountNameModel.class);
	private static final String ACCOUNT_MAP_ATTR = "accountmap";
	private static boolean isPEDemoID;
	private String accountName;
	public String userId;
	private String redirectionValue;
	private String accountNameException="";
	

	@Override
	public void activate() {
		// TODO Auto-generated method stub
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		try {
			accountName = "";
			userId = "";
			isPEDemoID = false;
			redirectionValue = "invalidAccess";
			String pageSuffix = UtilityHelper.getPageSuffix(getRequest());
			isPEDemoID=UtilityHelper.checkSparkID(pageSuffix);
			String currentPagePath = getRequest().getRequestPathInfo().getResourcePath();			
			resourceResolver = resolverInterface.getResolver();
			session = resourceResolver.adaptTo(Session.class);
			getuserIDName(pageSuffix, resourceResolver, session);
			logger.debug("AccountNameModel activate and isSparkID  {}", isPEDemoID);
			if (isPEDemoID) {
				if (!userId.equals("INVALID404")) {
					boolean redirectPage = UtilityHelper.checkpermissiontoshow(userId, currentPagePath,
							resourceResolver, session);
					if (!redirectPage) {
						redirectionValue = "validAccess";
					} else {
						redirectionValue = "invalidAccess";
					}
				} else {
					redirectionValue = "invalidPageSuffix";
				}
			} else {
				redirectionValue = "junkPEDemoID";
			}
		} catch (Exception e) {
			redirectionValue = "invalidPageSuffix";
			logger.debug("::::::Exception in AccountNameModel activate::::: {}", e.getMessage());
			logger.error("::::::Exception in AccountNameModel activate::::: {}", e.getMessage());
		}finally {
			session.logout();
			resourceResolver.close();
		}	
	}

	
	private void getuserIDName(String pageSuffix, ResourceResolver resourceResolver, Session session) throws Exception {
		if (pageSuffix != null) {
			pageSuffix = pageSuffix.replaceAll("/", "");
			logger.debug("page suffix is " + pageSuffix);
			Node accountJsonnode;
			try {
				accountJsonnode = session.getNode(PEDemoConstants.ACCOUNT_JSON_PATH);
				Asset asset = resourceResolver.getResource(accountJsonnode.getPath()).adaptTo(Asset.class);
				JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
				JsonObject jsonObj = obj.getAsJsonObject();
				JsonArray jsonArray = jsonObj.getAsJsonArray(ACCOUNT_MAP_ATTR);
				int count = 0;
				for (int i = 0; i < jsonArray.size(); i++) {
					JsonObject rec = jsonArray.get(i).getAsJsonObject();
					String key = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("id").toString());
					if (key.equalsIgnoreCase(pageSuffix)) {
						userId = key;
						accountName = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("accountname").toString());
						if(rec.has("accountCustName")) {
							accountNameException=UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("accountCustName").toString());							
						}
						count = 1;
					}
				}
				if (count == 0) {
					userId = "INVALID404";
					accountName = "Your Company";
				} 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.debug("exception in getuserIDName {}", e.getMessage());
				logger.error("exception in getuserIDName function::  {}", e.getMessage());
				throw e;
			}

		} else {
			userId = "INVALID404";
			accountName = "Your Company";
		}

	}

	public String getAccountName() {
		return accountName;
	}

	public String getUserId() {
		return userId;
	}

	public String getRedirectionValue() {
		return redirectionValue;
	}

	public String getAccountNameException() {
		return accountNameException;
	}

}
