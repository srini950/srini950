package personalizationdemo.core.services;
import java.util.ArrayList;

import org.apache.sling.api.resource.ResourceResolver;

import personalizationdemo.core.bean.GetPPRCompanyDetailsPOJO;
import personalizationdemo.core.bean.PEDemoSegmentBean;

public interface SegmentDetails {
	public ArrayList<PEDemoSegmentBean> getSegmentDetails(ResourceResolver resolver, String rootSegmentPath, ArrayList<GetPPRCompanyDetailsPOJO> pprCmplist) throws Exception;

}
