package personalizationdemo.core.services.impl;

import java.io.IOException;
import java.util.ArrayList;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import personalizationdemo.core.bean.GetPPRCompanyDetailsPOJO;
import personalizationdemo.core.services.GetPPRCompanyDetails;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

@Component(service = GetPPRCompanyDetails.class)
public class GetPPRCompanyDetailsImpl implements GetPPRCompanyDetails {

	private final Logger LOG = LoggerFactory.getLogger(GetPPRCompanyDetailsImpl.class);

	@Override
	public ArrayList<GetPPRCompanyDetailsPOJO> getPPRCompanyDetail(ResourceResolver resolver, String userId)
			throws Exception {
		LOG.debug("::::: getPPRCompanyDetail method::::");

		Session session = resolver.adaptTo(Session.class);
		ArrayList<GetPPRCompanyDetailsPOJO> pprCmplist = new ArrayList<GetPPRCompanyDetailsPOJO>();
		try {
			Node node = session.getNode(PEDemoConstants.PEDEMO_ACCOUNTDATA_JSON_PATH);
			Asset asset = resolver.getResource(node.getPath()).adaptTo(Asset.class);
			String jsonStr = UtilityHelper.getJsonStringFromAsset(asset);
			JsonElement obj = new JsonParser().parse(jsonStr);
			JsonObject jsonObj = obj.getAsJsonObject();
			JsonArray jsonArray = jsonObj.getAsJsonArray(userId);
			for (int i = 0; i < jsonArray.size(); i++) {
				GetPPRCompanyDetailsPOJO pojoObj = new GetPPRCompanyDetailsPOJO();
				JsonObject rec = jsonArray.get(i).getAsJsonObject();
				pojoObj.setCompanyId(UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("id").toString()));
				pojoObj.setCompanyName(UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("accountname").toString()));
				pprCmplist.add(pojoObj);
			}

		} catch (RepositoryException e) {
			LOG.debug("::::: RepositoryException in GetPPRCompanyDetailsImpl-getPPRCompanyDetail :::: {}", e.getMessage());
			LOG.error("::::: RepositoryException in GetPPRCompanyDetailsImpl-getPPRCompanyDetail :::: {}", e.getMessage());
			throw e;
		} catch (IOException e) {
			LOG.debug("::::: IOException in GetPPRCompanyDetailsImpl-getPPRCompanyDetail :::: {}", e.getMessage());
			LOG.error("::::: IOException in GetPPRCompanyDetailsImpl-getPPRCompanyDetail :::: {}", e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.debug("::::: Exception in GetPPRCompanyDetailsImpl-getPPRCompanyDetail :::: {}", e.getMessage());
			LOG.error("::::: Exception in GetPPRCompanyDetailsImpl-getPPRCompanyDetail :::: {}", e.getMessage());
			throw e;
		}
		return pprCmplist;
	}

}
