package personalizationdemo.core.models;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import personalizationdemo.core.utils.UtilityHelper;

public class TextComponentModel extends WCMUsePojo{

	private static final Logger log = LoggerFactory.getLogger(TextComponentModel.class);
	public String text;

	@Override
	public void activate()  {	
		try {
			log.debug(":::::::in TextComponentModel :::::::");
					 String pedemoID=UtilityHelper.getSparkId(getRequest());
					
					if(pedemoID !=null && pedemoID!="") {
					   text=UtilityHelper.parseAnchorElementForAX(getProperties().get("text", ""), pedemoID);
					}else {
						text=UtilityHelper.parseAnchorElementForAX(getProperties().get("text", ""), "");
					}
		}catch(Exception e) {
			log.debug("Exception in TextComponentModel {}",e.getMessage());
			log.error("Exception in TextComponentModel {}",e.getMessage() );
			
		}
	}
	
	public String getText() {
		return text;
	}

}
