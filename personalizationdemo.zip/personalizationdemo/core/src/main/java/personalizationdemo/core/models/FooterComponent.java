package personalizationdemo.core.models;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;

import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.day.text.Text;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import personalizationdemo.core.bean.FooterComponentBean;
import personalizationdemo.core.bean.FooterComponentLinkBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.UtilityHelper;

public class FooterComponent extends WCMUsePojo{
	FooterComponentBean footerComponentBean = null;
	private static final Logger LOGGER = LoggerFactory.getLogger(FooterComponent.class);
	private int currentYear;
	public String text;
	public String cookieErrorPath;
	
	@Override
	public void activate()  {
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		
		try {	
			LOGGER.debug("FooterComponent activate");
				
				resourceResolver = resolverInterface.getResolver();
				footerComponentBean = new FooterComponentBean();
				String prop = get("prop", String.class);
				if (prop != null)
				footerComponentBean.setLinkList(getLinkLists(prop));
				Page currentPage = getResourcePage();
				String sitename = Text.getAbsoluteParent(currentPage.getPath(), 2);
				if (sitename != null)
				footerComponentBean.setFooterComponentPath(sitename+"/jcr:content/footer");
				currentYear = Calendar.getInstance().get(Calendar.YEAR);
				footerComponentBean.setCurrentYear(currentYear);
				
				Node footer = resourceResolver.getResource(sitename+"/jcr:content/footer").adaptTo(Node.class);
				if(footer.hasProperty("cookieErrorPath")) {
					cookieErrorPath = footer.getProperty("cookieErrorPath").getString();
				}
				  
				String sparkID = UtilityHelper.getSparkId(getRequest());
				if (sparkID != null && sparkID != "") {
					text = UtilityHelper.parseAnchorElementForAX(getProperties().get("text", ""), sparkID);
				} else {
					text = UtilityHelper.parseAnchorElementForAX(getProperties().get("text", ""), "");
				}
		}catch(Exception e) {
			LOGGER.debug("Exception in FooterComponent "+e.getMessage());
			LOGGER.error("Exception in FooterComponent "+e.getMessage());
		}finally {
			resourceResolver.close();
		}
	}
	
	public List<FooterComponentLinkBean> getLinkLists(String prop) throws Exception {
		
		List<FooterComponentLinkBean> beanList = new ArrayList<FooterComponentLinkBean>();
		try{
			
			String[] itemsProps = getProperties().get(prop, String[].class);
			if(itemsProps !=null){
				for(int i = 0; i < itemsProps.length; i++){
					ObjectMapper mapper = new ObjectMapper();
					Map<String, String> propertyMap = new HashMap<>();
					propertyMap = mapper.readValue(itemsProps[i], new TypeReference<Map<String, String>>(){});
					FooterComponentLinkBean bean = new FooterComponentLinkBean();
					bean.setLinkLabel(null!=propertyMap.get("categoryID") ? propertyMap.get("categoryID") : "");
					bean.setLinkPath(null!=propertyMap.get("categoryPath") ? UtilityHelper.getSparkUrlString(propertyMap.get("categoryPath"),getRequest()) : "");
					bean.setOpenInNewWindow(null!=propertyMap.get("openNewTab") ? propertyMap.get("openNewTab") : "");
					beanList.add(bean);
				}
			}
		}catch(Exception e){
			LOGGER.debug("Exception logged: "+e);
			LOGGER.error("Exception logged: "+e);
			throw e;
		}
		return beanList;
	}
	
	public FooterComponentBean getFooterComponentBean() {
		return this.footerComponentBean;
		
	}
	
	public String getText() {
		return text;
	}
	
	public String getCookieErrorPath() {
		return cookieErrorPath;
	}
}
