package personalizationdemo.core.models;
import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;

import personalizationdemo.core.bean.HeroComponentBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class HeroComponent extends WCMUsePojo {
	HeroComponentBean herocomponentBean = null;

	/** Default log. */
	private static final Logger logger = LoggerFactory.getLogger(HeroComponent.class);
	String ctaBtnLink = "";
	String sparkID="";

	@Override
	public void activate()  {
		herocomponentBean = new HeroComponentBean();
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		try {
				resourceResolver =resolverInterface.getResolver();
				session = resourceResolver.adaptTo(Session.class);
				sparkID = UtilityHelper.getSparkId(getRequest());

				String fieldType = getProperties().get("fieldType", "");
				String fieldValue = getProperties().get("fieldValue", "");
				String heroTitle = getProperties().get("heroTitle", "");
				String buttonCTA = getProperties().get("buttonCTA", "");
				String heroTeaser = getProperties().get("heroTeaser", "");
				String staticUrlCTA = getProperties().get("urlCTA", "");
				String startLevel = getProperties().get("startLevel", "");
				
				if(startLevel ==null || startLevel == ""){
					logger.debug("startLevel null");
				}
				if(sparkID!=null && staticUrlCTA !=null && staticUrlCTA !="" && staticUrlCTA.contains(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
					if(staticUrlCTA.contains(".html"))
						staticUrlCTA = staticUrlCTA + "/" + sparkID;
					else
						staticUrlCTA = staticUrlCTA + ".html/" + sparkID;							
				}		
				String newWindow = getProperties().get("newWindow", "");
				String staticbtnCtaLabel=getProperties().get("textCTA", "");
				String isCtaRequired=getProperties().get("ctaButtonRequired", "");
				logger.debug("fieldName:: " + fieldValue + " fieldType:: " + fieldType + " heroTitle:: " + heroTitle
						+ " buttonCTA:: " + buttonCTA + " heroTeaser:: " + heroTeaser + " urlCTA:: " + staticUrlCTA + " newWindow:: "
						+ newWindow +" is CTA Required "+isCtaRequired);				
				if(null != staticUrlCTA && !"".equals(staticUrlCTA) && !staticUrlCTA.startsWith("/content")){
					if(!(staticUrlCTA.startsWith("http") || staticUrlCTA.startsWith("https")))
						 staticUrlCTA = "https://" + staticUrlCTA;
				}				
				herocomponentBean.setHeroTitle(heroTitle);
				herocomponentBean.setButtonCTA(buttonCTA);
				herocomponentBean.setHeroTeaser(heroTeaser);
				herocomponentBean.setFieldValue(fieldValue);
				herocomponentBean.setStaticUrlCTA(staticUrlCTA);
				herocomponentBean.setNewWindow(newWindow);		
				herocomponentBean.setStaticbtnCtaLabel(staticbtnCtaLabel);
				herocomponentBean.setIsCtaRequired(isCtaRequired);
				herocomponentBean.setFieldType(fieldType);
		
				Node masterjsonnode = session.getNode(PEDemoConstants.masterDynamicPath);
				Asset asset = null;
				asset = resourceResolver.getResource(masterjsonnode.getPath()).adaptTo(Asset.class);
				logger.debug("asset path {}",asset.getPath());
				ctaBtnLink = UtilityHelper.getFieldValueCTALink(asset, sparkID, fieldType, fieldValue);
				herocomponentBean.setDynamicUrlCTA(ctaBtnLink);
				ctaBtnLink = herocomponentBean.getDynamicUrlCTA();
				logger.debug("crabtnlink val {}",ctaBtnLink);
				
		}catch(Exception e) {
			logger.debug("exception is {}",e.getMessage());
			logger.error("exception is {}",e.getMessage());
		}finally {
			session.logout();
			resourceResolver.close();
		}		
	}

	public HeroComponentBean getHerocomponentBean() {
		return this.herocomponentBean;

	}
	

}
