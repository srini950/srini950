package personalizationdemo.core.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

public class ComponentHelper extends WCMUsePojo{
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	boolean identifier = false;
	
	@Override
	public void activate(){
		
		String path = get("path", String.class);
		identifier = showRelatedItemsComponent(path);
	}
	
	public boolean isIdentifier() {
		return identifier;
	}

	public boolean showRelatedItemsComponent(String path){
		
		List<String> childPagesList = new ArrayList<String>();
		Session session = getResourceResolver().adaptTo(Session.class);
		QueryBuilder queryBuilder = getResourceResolver().adaptTo(QueryBuilder.class);
		Map<String,String> queryMap = new HashMap<String,String>();
		
		try{
			String parentPath = path.replace(".html", "");
			
			queryMap.put("path",parentPath);
			queryMap.put("type", "cq:Page");
			queryMap.put("property", "@jcr:content/catCategoryId");
			queryMap.put("property.operation", "exists");
			queryMap.put("orderby", "@jcr:content/jcr:created");
			queryMap.put("orderby.sort", "desc");
			queryMap.put("p.limit", "-1");
			Query query = queryBuilder.createQuery(PredicateGroup.create(queryMap), session);
			SearchResult searchResult = query.getResult();
			if(null != searchResult){
				for(Hit hit : searchResult.getHits()){
					childPagesList.add(hit.getPath());
				}
			}
			if(childPagesList.size() > 3)
				return true;
			else
				return false;
		}catch(Exception e){
			log.debug("Exception logged in showRelatedItemsComponent: {}",e.getMessage());
			log.error("Exception logged in showRelatedItemsComponent: {}", e.getMessage());
		}
		return false;
	}
}