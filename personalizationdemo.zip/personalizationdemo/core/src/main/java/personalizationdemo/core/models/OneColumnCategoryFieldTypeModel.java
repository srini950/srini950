package personalizationdemo.core.models;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.dam.api.Asset;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class OneColumnCategoryFieldTypeModel extends WCMUsePojo {
	private static final Logger logger = LoggerFactory.getLogger(OneColumnCategoryFieldTypeModel.class);
	ResourceResolver resolver = null;

	@Override
	public void activate() {
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class);
		try {
			logger.debug("in OneColumnCategoryFieldTypeModel");
					resolver = resolverInterface.getResolver();
					Session session = resolver.adaptTo(Session.class);
					
					Node node = session.getNode(PEDemoConstants.FIELDTYPE_DROPDOWN_PATH);
					Asset asset=resolver.getResource(node.getPath()).adaptTo(Asset.class);
			
					JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
					JsonArray jsonArray= obj.getAsJsonArray();
					Map<String, String> fieldTypeList = new LinkedHashMap<String, String>();
					fieldTypeList.put("", "Select a Category");
					for(int i=0; i<jsonArray.size(); i++)            {
						JsonObject rec = jsonArray.get(i).getAsJsonObject();
						String fieldType = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("fieldType").toString());
						fieldTypeList.put(fieldType, fieldType);
						@SuppressWarnings("unchecked")
						DataSource ds = new SimpleDataSource(new TransformIterator(fieldTypeList.keySet().iterator(), new Transformer() {
							 @Override
							 public Object transform(Object o) {
							 String categoryField = (String) o;
								 ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
								//Populate the Map
								 vm.put("value", categoryField);
								 vm.put("text", fieldTypeList.get(categoryField));
								 return new ValueMapResource(resolver, new ResourceMetadata(), "nt:unstructured", vm);
							 }
						 }));
						this.getRequest().setAttribute(DataSource.class.getName(), ds);
			        }
		}catch(Exception e) {
			logger.debug("Exception in OneColumnCategoryFieldTypeModel {}",e.getMessage());
			logger.error("Exception in OneColumnCategoryFieldTypeModel {}",e.getMessage());
			
		}finally {
			resolver.close();
		}
	}

}
