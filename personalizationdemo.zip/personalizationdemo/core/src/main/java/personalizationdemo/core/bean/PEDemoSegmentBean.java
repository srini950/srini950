package personalizationdemo.core.bean;
import java.util.ArrayList;

public class PEDemoSegmentBean {
	private String segmentName;
	private String segmentTitle;
	private long boostFactor;
	private String segmentPath;
	private String segmentResourceType;
	private String traitType;
	private ArrayList<TraitBean> traitList;
	
	
	
	public String getSegmentName() {
		return segmentName;
	}
	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}
	public String getSegmentTitle() {
		return segmentTitle;
	}
	public void setSegmentTitle(String segmentTitle) {
		this.segmentTitle = segmentTitle;
	}
	public long getBoostFactor() {
		return boostFactor;
	}
	public void setBoostFactor(long boostFactor) {
		this.boostFactor = boostFactor;
	}
	public String getSegmentPath() {
		return segmentPath;
	}
	public void setSegmentPath(String segmentPath) {
		this.segmentPath = segmentPath;
	}
	public String getSegmentResourceType() {
		return segmentResourceType;
	}
	public void setSegmentResourceType(String segmentResourceType) {
		this.segmentResourceType = segmentResourceType;
	}
	public String getTraitType() {
		return traitType;
	}
	public void setTraitType(String traitType) {
		this.traitType = traitType;
	}
	public ArrayList<TraitBean> getTraitList() {
		return traitList;
	}
	public void setTraitList(ArrayList<TraitBean> traitList) {
		this.traitList = traitList;
	}
	

}
