package personalizationdemo.core.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import personalizationdemo.core.bean.RelatedItemsComponentBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class RelatedItemsComponent extends WCMUsePojo{
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	List<RelatedItemsComponentBean> listCardItems = null;
	String componentHeader = "";
	boolean hideComponent = false;
	int manualBeanListSize=0;
	
	@Override
	public void activate(){
		
		try {
			log.debug("in RelatedItemsComponent activate");
				String prop = get("prop", String.class);
				String sourceType = get("source", String.class);
				if("manual".equalsIgnoreCase(sourceType))
					listCardItems = populateCardItems(prop);
				if("automatic".equalsIgnoreCase(sourceType))
					listCardItems = automaticCardItems();
		}catch(Exception e) {
			log.debug("Exception in RelatedItemsComponent {}",e.getMessage());
			log.error("Exception in RelatedItemsComponent {}",e.getMessage());
		}
	}

	public List<RelatedItemsComponentBean> populateCardItems(String prop) throws Exception{
		log.debug("in populateCardItems");
		List<RelatedItemsComponentBean> beanList = new ArrayList<RelatedItemsComponentBean>();
		try{
			String[] itemsProps = getProperties().get(prop, String[].class);
			if(itemsProps != null){
				log.debug("itemsProps Length {}",itemsProps.length);
				for(int i=0; i<itemsProps.length; i++){
					ObjectMapper mapper = new ObjectMapper();
					Map<String, String> propertyMap = new HashMap<>();
					propertyMap = mapper.readValue(itemsProps[i], new TypeReference<Map<String, String>>(){});
					RelatedItemsComponentBean relatedItemsComponentBean = new RelatedItemsComponentBean();
					relatedItemsComponentBean.setIcon(null!=propertyMap.get("icon") ? propertyMap.get("icon") : "");
					relatedItemsComponentBean.setAlttext(null!=propertyMap.get("alttext") ? propertyMap.get("alttext") : "");
					relatedItemsComponentBean.setTitle(null!=propertyMap.get("title") ? propertyMap.get("title") : "");
					relatedItemsComponentBean.setTeaser(null!=propertyMap.get("teaser") ? propertyMap.get("teaser") : "");
					relatedItemsComponentBean.setButtonLabel(null!=propertyMap.get("buttonLabel") ? propertyMap.get("buttonLabel") : "");
					String ctaUrl = (null!=propertyMap.get("ctaUrl") ? propertyMap.get("ctaUrl") :"");
					String sparkID = UtilityHelper.getSparkId(getRequest());

					if(sparkID!=null && ctaUrl!=null && ctaUrl!=""  && ctaUrl.contains(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
						if(ctaUrl.contains(".html"))
							ctaUrl = ctaUrl + "/" + sparkID;
						else
							ctaUrl = ctaUrl + ".html/" + sparkID;
							
					}
					
					if(null != ctaUrl && !"".equals(ctaUrl) && !ctaUrl.startsWith("/content")){
						if(!(ctaUrl.startsWith("http") || ctaUrl.startsWith("https")))
							ctaUrl = "https://" + ctaUrl;
					}
					relatedItemsComponentBean.setCtaUrl(ctaUrl);
					relatedItemsComponentBean.setOpenInNewWindow(null!=propertyMap.get("openInNewWindow") ? propertyMap.get("openInNewWindow") : "");
					beanList.add(relatedItemsComponentBean);
				}
				manualBeanListSize=beanList.size();
				log.debug("beanList size "+beanList.size());
			}
		}catch(Exception e){
			log.debug("Exception logged in manual flow: {}",e.getMessage());
			log.error("Exception logged in manual flow: {}",e.getMessage());
			throw e;
		}
		return beanList;
	}
	
	public List<RelatedItemsComponentBean> automaticCardItems() throws Exception{
		log.debug("in automaticCardItems method");

		List<RelatedItemsComponentBean> beanList = new ArrayList<RelatedItemsComponentBean>();
		List<String> orderedPageList = new ArrayList<String>();
		List<String> childPagesList = new ArrayList<String>();
		List<String> nonOrderedPageList = new ArrayList<String>();
		List<String> filteredListofPagesforTargetedUser = new ArrayList<String>();
		List<String> filteredListofPagesBasedonPagePropertyCheckBox = new ArrayList<String>();
		List<Integer> positionList = new ArrayList<Integer>();
		List<String> finalList = new ArrayList<String>();
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		Map<String,String> queryMap = new HashMap<String,String>();
		String categoryID = "";
		try{
			resourceResolver=resolverInterface.getResolver();
			session = resourceResolver.adaptTo(Session.class);
			QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
			Node masterjsonnode = session.getNode(PEDemoConstants.masterDynamicPath);
			Asset asset = null;
			asset = resourceResolver.getResource(masterjsonnode.getPath()).adaptTo(Asset.class);
			log.debug("Asset path for RelatedItems Component: {}",asset.getPath());
			log.debug("REQUEST PATH::>>"+getRequest().getPathInfo());
			
			String sparkID = UtilityHelper.getSparkId(getRequest());
			Property property = null;
			Value[] order = null;
			String rootPagePath = "";
			
			if(getRequest().getPathInfo().startsWith("/content/campaigns")){				
				rootPagePath = getRequest().getCookie("pagePath").getValue();
				log.debug("TARGETED COMPONENT:>>PAGEPATH"+rootPagePath);
			}
			else{
				rootPagePath = getCurrentPage().getPath();
				log.debug("NON-TARGETED COMPONENT:>>PAGEPATH"+rootPagePath);
			}	
			Resource res = resourceResolver.getResource(rootPagePath+"/jcr:content");
			Node node = res.adaptTo(Node.class);
			categoryID = node.hasProperty("catCategoryId") ? node.getProperty("catCategoryId").getString() : "";
			categoryID = categoryID.replace(".html", "");
			Resource parentCategoryRes = resourceResolver.getResource(categoryID+"/jcr:content");
			Node parentCategoryNode = parentCategoryRes.adaptTo(Node.class);
			
			componentHeader = parentCategoryNode.hasProperty("relatedItemHeader") ? parentCategoryNode.getProperty("relatedItemHeader").getString() : "";
			
			if (parentCategoryNode.hasProperty("items")) {
	            property = parentCategoryNode.getProperty("items");
	        }
			if (property != null) {
	            if (property.isMultiple()) {
	            	for(int i=0 ; i < property.getValues().length ; i++)
	            		order = property.getValues();
	            } else {
	            	order = new Value[1];
	            	order[0] = property.getValue();
	            }
			}
			if(null != order){
				for(Value value : order){
					ObjectMapper mapper = new ObjectMapper();
					Map<String,String> propertyMap = new HashMap<String,String>();
					propertyMap = mapper.readValue(value.getString(), new TypeReference<Map<String,String>>() {});
					if(null!=propertyMap.get("categoryOrder")) {
						String detailPagePath = validatePage(propertyMap.get("categoryOrder"),resourceResolver);
						if(detailPagePath!=null) {
							orderedPageList.add(detailPagePath);
						}						
					}
				}
			}
			queryMap.put("path",categoryID);
			queryMap.put("type", "cq:Page");
			queryMap.put("property", "@jcr:content/catCategoryId");
			queryMap.put("property.operation", "exists");
			queryMap.put("orderby", "@jcr:content/jcr:created");
			queryMap.put("orderby.sort", "desc");
			queryMap.put("p.limit", "-1");
			Query query = queryBuilder.createQuery(PredicateGroup.create(queryMap), session);
			SearchResult searchResult = query.getResult();
			if(null != searchResult){
				for(Hit hit : searchResult.getHits()){
					childPagesList.add(hit.getPath());
				}
			}
			log.debug("child pages for RelatedItems Component : {}",childPagesList);
			for(String item : childPagesList){
				if(!orderedPageList.contains(item))
					nonOrderedPageList.add(item);
			}
			log.debug("Non-Ordered List of pages for RelatedItems Component : {}",nonOrderedPageList);
			for(int index = 0; index < nonOrderedPageList.size(); index++)
				orderedPageList.add(index, nonOrderedPageList.get(index));
			log.debug("Ordered page list for RelatedItems Component: {}",orderedPageList);
			for(String page : orderedPageList){
				if(UtilityHelper.checkpermissiontoshowInAuthor(sparkID,page+"/jcr:content",resourceResolver,session,getRequest()) == false)
					filteredListofPagesforTargetedUser.add(page);
			}
			log.debug("List of pages after calling --checkpermissiontoshow()--for RelatedItems Component : {}",filteredListofPagesforTargetedUser);
			/*Checking whether the detail page is allowed to appear in automatic flow by verifying page property checkbox->showonautomaticcarousel*/
			for(String pagePath : filteredListofPagesforTargetedUser){
				Resource pageResource = resourceResolver.getResource(pagePath+"/jcr:content");
				Node pageNode = pageResource.adaptTo(Node.class);
				String checkPageToAppearInAutomaticRelatedItems = pageNode.hasProperty("dpShowcarouselDC") ? pageNode.getProperty("dpShowcarouselDC").getString() : "";
				String minimumAuthoring = pageNode.hasProperty("dpCarouselTitleDC") ? pageNode.getProperty("dpCarouselTitleDC").getString() : "";
				if("true".equalsIgnoreCase(checkPageToAppearInAutomaticRelatedItems) && !"".equals(minimumAuthoring))
					filteredListofPagesBasedonPagePropertyCheckBox.add(pagePath);
			}
			/*---End--*/
			log.debug("List of pages after page property checkbox verification for RelatedItems Component : {}",filteredListofPagesBasedonPagePropertyCheckBox);
			if(filteredListofPagesBasedonPagePropertyCheckBox.size() < 4){
				hideComponent = true;
				return beanList;
			}
			String[] pageListArr = new String[filteredListofPagesBasedonPagePropertyCheckBox.size()];
			pageListArr = filteredListofPagesBasedonPagePropertyCheckBox.toArray(pageListArr);
			
			int pivotPos = 0;
			for(int index = 0; index < pageListArr.length; index++){
				if(getCurrentPage().getPath().equalsIgnoreCase(pageListArr[index])){
					pivotPos = index;
					break;
				}
			}
			for(int posIndex = pivotPos + 1; posIndex < pageListArr.length; posIndex++)
				positionList.add(posIndex);
			int count = 0;
			if(positionList.size()<3 && positionList.size()>0){
				count = 3 - positionList.size();
				for(int j = 0; j < positionList.size(); j++)
					finalList.add(pageListArr[positionList.get(j)]);
				for(int j = 0; j < count; j++)
					finalList.add(pageListArr[j]);
			}
			if(positionList.size() == 0){
				for(int j = 0; j < 3; j++)
					finalList.add(pageListArr[j]);
			}
			if(positionList.size() >= 3){
				for(int j = pivotPos + 1; j < pageListArr.length; j++){
					finalList.add(pageListArr[j]);
					if(finalList.size() == 3)
						break;
				}
			}
			log.debug("Final List for RelatedItems Component: {}",finalList);

			for(String path : finalList){
				Resource resource = resourceResolver.getResource(path+"/jcr:content");
				Node jcrNode = resource.adaptTo(Node.class);
				RelatedItemsComponentBean relatedItemsComponentBean = new RelatedItemsComponentBean();
				relatedItemsComponentBean.setTitle(jcrNode.hasProperty("dpCarouselTitleDC") ? jcrNode.getProperty("dpCarouselTitleDC").getString() : "");
				relatedItemsComponentBean.setIcon(jcrNode.hasProperty("dpiconlogodc") ? jcrNode.getProperty("dpiconlogodc").getString() : "");
				relatedItemsComponentBean.setTeaser(jcrNode.hasProperty("dpBlurbDC") ? jcrNode.getProperty("dpBlurbDC").getString() : "");
				relatedItemsComponentBean.setCtaButtonRequired(jcrNode.hasProperty("dpCTAButtonRequiredDC") ? jcrNode.getProperty("dpCTAButtonRequiredDC").getString() : "");
				if(jcrNode.getProperty("dpCTAButtonRequiredDC").getString().equalsIgnoreCase("true")) {
					relatedItemsComponentBean.setButtonType(jcrNode.hasProperty("dpButtonCTADC") ? jcrNode.getProperty("dpButtonCTADC").getString() : "");
					relatedItemsComponentBean.setButtonLabel(jcrNode.hasProperty("dpCTANameDC") ? jcrNode.getProperty("dpCTANameDC").getString() : "");
					String ctaUrl = jcrNode.hasProperty("dpUrlCTADC") ? jcrNode.getProperty("dpUrlCTADC").getString() : "";		
					
					if(sparkID!=null && ctaUrl!=null && ctaUrl!=""  && ctaUrl.contains(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
						if(ctaUrl.contains(".html"))
							ctaUrl = ctaUrl + "/" + sparkID;
						else
							ctaUrl = ctaUrl + ".html/" + sparkID;														
					}
					if(null != ctaUrl && !"".equals(ctaUrl) && !ctaUrl.startsWith("/content")){
						if(!(ctaUrl.startsWith("http") || ctaUrl.startsWith("https")))
							 ctaUrl = "https://" + ctaUrl;
					}
					relatedItemsComponentBean.setCtaUrl(ctaUrl);
					String fieldType = jcrNode.hasProperty("dpFieldTypeDC") ? jcrNode.getProperty("dpFieldTypeDC").getString() : "";
					String fieldValue = jcrNode.hasProperty("dpFieldValueDC") ? jcrNode.getProperty("dpFieldValueDC").getString() : "";
					String dynamicButtonLink = UtilityHelper.getFieldValueCTALink(asset, sparkID, fieldType, fieldValue);
					relatedItemsComponentBean.setFieldType(fieldType);
					relatedItemsComponentBean.setDynamicCTAUrl(null != dynamicButtonLink ? dynamicButtonLink : "");
					relatedItemsComponentBean.setOpenInNewWindow(jcrNode.hasProperty("dpNewWindowDC") ? jcrNode.getProperty("dpNewWindowDC").getString() : "");
				}
				beanList.add(relatedItemsComponentBean);
			}
		}catch(Exception e){
			log.debug("Exception logged in automatic flow: {}"+e.getMessage());
			log.error("Exception logged in automatic flow: {}"+e.getMessage());
			throw e;
		}finally {
			session.logout();
			resourceResolver.close();
		}	
		return beanList;
	}
	
	public List<RelatedItemsComponentBean> getListCardItems() {
		return listCardItems;
	}
	
	public int getManualBeanListSize() {
		return manualBeanListSize;
	}
	
	public boolean isHideComponent() {
		return hideComponent;
	}

	public String getComponentHeader() {
		return componentHeader;
	}
	private String validatePage(String pagePath, ResourceResolver resourceResolver) {
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		Page detailPage = pageManager.getContainingPage(pagePath);
		if(detailPage!=null) {
			return detailPage.getPath();
		}
		
		return null;
		
	}
}