package personalizationdemo.core.bean;

public class PromoComponentBean {

	private String promoText;
	private String fieldValue;
	private String dynamicUrlCTA;
	private String alignment;
	private String buttonCTA;
	private String btnType;
	private String ctaStaticLink;





	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getPromoText() {
		return promoText;
	}

	public void setPromoText(String promoText) {
		this.promoText = promoText;
	}

	public String getButtonCTA() {
		return buttonCTA;
	}

	public void setButtonCTA(String buttonCTA) {
		this.buttonCTA = buttonCTA;
	}

	public String getAlignment() {
		return alignment;
	}

	public void setAlignment(String alignment) {
		this.alignment = alignment;
	}
	public String getDynamicUrlCTA() {
		return dynamicUrlCTA;
	}

	public void setDynamicUrlCTA(String dynamicUrlCTA) {
		this.dynamicUrlCTA = dynamicUrlCTA;
	}
	
	public String getCtaStaticLink() {
		return ctaStaticLink;
	}

	public void setCtaStaticLink(String ctaStaticLink) {
		this.ctaStaticLink = ctaStaticLink;
	}

	@Override
	public String toString() {
		return "PromoComponentBean [buttonCTA=" + buttonCTA + ",fieldValue=" + fieldValue + ", alignment=\" + alignment + \", dynamicUrlCTA="
				+ dynamicUrlCTA + ", ctaStaticLink=" + ctaStaticLink + ", staticbtnCtaLabel=\" + staticbtnCtaLabel + \"]";
	}

	public String getBtnType() {
		return btnType;
	}

	public void setBtnType(String btnType) {
		this.btnType = btnType;
	}

}
