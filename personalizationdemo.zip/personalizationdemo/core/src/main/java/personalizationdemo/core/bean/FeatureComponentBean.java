package personalizationdemo.core.bean;


public class FeatureComponentBean {
	private String preHeader;
	private String header;
	private String teaser;
	private String ctaUrl;
	private String fieldType;
	private String fieldValue;
	private String buttonLabel;
	private String sparkImage;
	private String dynamicUrlCTA;
	private String newWindow;
	private String imagePlacement;
	private String ctaBtnType;
	private String isCtaRequired;
	private String sparkMobImage;
	private String hideContent;
	
	public String getIsCtaRequired() {
		return isCtaRequired;
	}

	public void setIsCtaRequired(String isCtaRequired) {
		this.isCtaRequired = isCtaRequired;
	}
	
	public String getPreHeader() {
		return preHeader;
	}
	public void setPreHeader(String preHeader) {
		this.preHeader = preHeader;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getTeaser() {
		return teaser;
	}
	public void setTeaser(String teaser) {
		this.teaser = teaser;
	}
	public String getCtaUrl() {
		return ctaUrl;
	}
	public void setCtaUrl(String ctaUrl) {
		this.ctaUrl = ctaUrl;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public String getButtonLabel() {
		return buttonLabel;
	}
	public void setButtonLabel(String buttonLabel) {
		this.buttonLabel = buttonLabel;
	}
	public String getSparkImage() {
		return sparkImage;
	}
	public void setSparkImage(String sparkImage) {
		this.sparkImage = sparkImage;
	}
	public String getDynamicUrlCTA() {
		return dynamicUrlCTA;
	}
	public void setDynamicUrlCTA(String dynamicUrlCTA) {
		this.dynamicUrlCTA = dynamicUrlCTA;
	}
	public String getNewWindow() {
		return newWindow;
	}

	public void setNewWindow(String newWindow) {
		this.newWindow = newWindow;
	}

	public String getImagePlacement() {
		return imagePlacement;
	}
	public void setImagePlacement(String imagePlacement) {
		this.imagePlacement = imagePlacement;
	}
	public String getCtaBtnType() {
		return ctaBtnType;
	}
	public void setCtaBtnType(String ctaBtnType) {
		this.ctaBtnType = ctaBtnType;
	}

	public String getSparkMobImage() {
		return sparkMobImage;
	}

	public void setSparkMobImage(String sparkMobImage) {
		this.sparkMobImage = sparkMobImage;
	}

	public String getHideContent() {
		return hideContent;
	}

	public void setHideContent(String hideContent) {
		this.hideContent = hideContent;
	}

}
