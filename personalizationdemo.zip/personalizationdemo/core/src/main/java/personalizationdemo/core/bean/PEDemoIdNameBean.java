package personalizationdemo.core.bean;

public class PEDemoIdNameBean {
	private String sparkId;
	private String sparkAccountName;
	
	public String getSparkId() {
		return sparkId;
	}
	public void setSparkId(String sparkId) {
		this.sparkId = sparkId;
	}
	public String getSparkAccountName() {
		return sparkAccountName;
	}
	public void setSparkAccountName(String sparkAccountName) {
		this.sparkAccountName = sparkAccountName;
	}


}
