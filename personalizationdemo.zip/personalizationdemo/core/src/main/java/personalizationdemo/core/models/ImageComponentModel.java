package personalizationdemo.core.models;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class ImageComponentModel extends WCMUsePojo{

	private static final Logger log = LoggerFactory.getLogger(ImageComponentModel.class);
	public String title;
	public String sparkImage;
	public String alttext;
	public String imagePlacement;
	public String imageAlign;
	
	@Override
	public void activate(){
		
		try{
			log.debug("in  ImageComponentModel activate");
			title = getProperties().get("title","");
			sparkImage = getProperties().get("sparkImage","");
			alttext = getProperties().get("alttext","");
			imagePlacement = getProperties().get("imagePlacement","");
			imageAlign = getProperties().get("imageAlign","");
			
		}catch(Exception e){
			log.debug("Exception logged: {}",e.getMessage());
			log.error("Exception logged: {}",e.getMessage());
		}
	}

	public String getTitle() {
		return title;
	}

	public String getSparkImage() {
		return sparkImage;
	}

	public String getAlttext() {
		return alttext;
	}

	public String getImagePlacement() {
		return imagePlacement;
	}

	public String getImageAlign() {
		return imageAlign;
	}
	
}
