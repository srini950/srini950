package personalizationdemo.core.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import personalizationdemo.core.services.GetLoggedInUser;
import personalizationdemo.core.utils.MaskHelper;
import personalizationdemo.core.utils.PEDemoConstants;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=get encrtypted pedemo id",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "encyrptedIdServlet" })
public class checkIdServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(checkIdServlet.class);
	
	@Reference
	GetLoggedInUser userInfo;
	
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		try {
			Map<String, String> encyrptedKey = new HashMap<String, String>();
			String id = request.getParameter("pedemoid");
			String encryptedId = "";
			if(null != id) {
				encryptedId = MaskHelper.encrypt(id,PEDemoConstants.PEDEMO_MASK_KEY);
			}
			encyrptedKey.put("encryptedkey", encryptedId);
			response.setContentType("application/json");
			final PrintWriter out = response.getWriter();
			ObjectMapper mapper = new ObjectMapper();
			out.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(encyrptedKey));
			out.flush();

		} catch (Exception e) {
			log.error("exception in Servlet {}", e.getMessage());
			log.debug("Exception in Servlet {}", e.getMessage());
		}

	}
}
