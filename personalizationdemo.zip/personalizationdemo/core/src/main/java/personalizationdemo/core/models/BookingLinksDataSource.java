package personalizationdemo.core.models;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.wcm.api.Page;

public class BookingLinksDataSource extends WCMUsePojo{
	private static final Logger logger = LoggerFactory.getLogger(BookingLinksDataSource.class);
	@Override
	public void activate()  {
		logger.debug(":::BookingLinksDataSource model class:::");
		
		try {
		
						final ResourceResolver resolver = getResource().getResourceResolver();	
						//Creating the Map instance to insert the bookingURLs
						SlingHttpServletRequest request = getRequest();
						String categoryPath = request.getParameter("item");
						logger.debug("request getparam item: {}", categoryPath);
						System.out.println("request getparam item: {}"+categoryPath);
						final Map<String, String> bookingLinksDB = new LinkedHashMap<String, String>();
						Page categoryPage = resolver.resolve(categoryPath).adaptTo(Page.class);
						Iterator<Page> iteratorPage = categoryPage.listChildren();
						Iterable<Page> iterable = () -> iteratorPage;
						Stream<Page> categoryStream = StreamSupport.stream(iterable.spliterator(), false);
						categoryStream.forEach(
								detailPage->{
									String pageTitle = detailPage.getTitle();
									String pagePath = detailPage.getPath();
									bookingLinksDB.put(pagePath,pageTitle);
									});
						
						
						@SuppressWarnings("unchecked")
						  
						//Creating the Datasource Object for populating the drop-down control.
						 DataSource ds = new SimpleDataSource(new TransformIterator(bookingLinksDB.keySet().iterator(), new Transformer() {
							 @Override
							  
							//Transforms the input object into output object
							 public Object transform(Object o) {
							 String bookingLink = (String) o;
								//Allocating memory to Map
								 ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
								//Populate the Map
								 vm.put("value", bookingLink);
								 vm.put("text", bookingLinksDB.get(bookingLink));
								 return new ValueMapResource(resolver, new ResourceMetadata(), "nt:unstructured", vm);
							 }
						 }));
						this.getRequest().setAttribute(DataSource.class.getName(), ds);
		}catch(Exception e) {
			logger.debug("Exception in BookingLinksDataSource {}" ,e.getMessage());
			logger.error("Exception in BookingLinksDataSource {}" ,e.getMessage());
			
		}
		 
		  
	}

}
