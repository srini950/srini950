package personalizationdemo.core.servlets;

import java.io.IOException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.i18n.I18n;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=CreateSegmentServlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "pedemonewsegment" })
public class SparkCreateSegmentServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(SparkCreateSegmentServlet.class);

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		log.debug("in SparkCreateSegmentServlet do post ");
		final I18n i18n = new I18n(request);
		final String AND_SEGMENT_TEMPLATE_PATH = "/apps/personalizationdemo/components/structure/pedemosegmentpage/andtemplate";
		final String OR_SEGMENT_TEMPLATE_PATH = "/apps/personalizationdemo/components/structure/pedemosegmentpage/ortemplate";
		String SEGMENT_ROOT = "/etc/segmentation/contexthub/pedemo-experiences";
		String containerType = null;
		String SEGMENT_TEMPLATE_PATH = AND_SEGMENT_TEMPLATE_PATH;
		ResourceResolver resourceResolver = request.getResourceResolver();
		PageManager pageManager = (PageManager) resourceResolver.adaptTo(PageManager.class);

		String segmentTitle = request.getParameter("segmentTitle");
		log.debug("segment title:::::{} " + segmentTitle);
		int boost = Integer.parseInt(request.getParameter("boost"));
		log.debug("segment boost:::: {}", boost);

		SEGMENT_ROOT = request.getParameter("customContextHubPath");

		log.debug("custom context hub path:::: {}", request.getParameter("customContextHubPath"));

		containerType = request.getParameter("containerType");

		log.debug("container type:::::: {}", containerType);

		if (containerType != null) {
			if (containerType.equalsIgnoreCase("AND"))
				SEGMENT_TEMPLATE_PATH = AND_SEGMENT_TEMPLATE_PATH;
			else
				SEGMENT_TEMPLATE_PATH = OR_SEGMENT_TEMPLATE_PATH;
		}

		if (segmentTitle != null && segmentTitle.length() > 0) {
			segmentTitle = segmentTitle.replaceAll("&([a-z]+|#[0-9]+);", " ").replaceAll("^\\s*|\\s*$|\\\\", "")
					.replaceAll("\\s+", " ");

			/* remove illegal characters from the name */
			String segmentName = segmentTitle.replaceAll("[^a-zA-Z0-9 ]", "").replaceAll("^\\s*", "")
					.replaceAll("\\s*$", "").replaceAll("\\s+", "-").toLowerCase();

			/*
			 * generate segment name if all user provided characters were considered as
			 * illegal
			 */
			String uuid = String.valueOf(segmentTitle.hashCode());

			if (segmentName.length() == 0) {
				segmentName = "segment-" + uuid;
			} else if (segmentName.length() != segmentTitle.length()) {
				/*
				 * some characters were removed from the name, so we need to add pseudo-random
				 * uuid in exchange, otherwise "Test $" will be considered same as "Test"
				 */
				segmentName += "-" + uuid;
			}

			String segmentPath = SEGMENT_ROOT + "/" + segmentName;
			log.debug("segment path :::: {}", segmentPath);
			Resource res = resourceResolver.getResource(segmentPath);
			ObjectMapper mapper = new ObjectMapper();
			ObjectNode responseCode = mapper.createObjectNode();

			/* segment exists */
			if (res != null) {
				try {
					responseCode.put("response", i18n.get("Given segment already exists."));
				} catch (Exception e) {
					log.error("Error in setting json response code {}", e.getMessage());
					log.debug("Error in setting json response code {}", e.getMessage());
				}

				response.getWriter().append(responseCode.toString());
				response.setStatus(403);
				return;
			}

			/* create a new segment using a template */
			try {
				Resource segmentTemplate = resourceResolver.getResource(SEGMENT_TEMPLATE_PATH);
				Resource newSegment = pageManager.copy(segmentTemplate, segmentPath, null, false, true);

				/* set new segment details */
				ModifiableValueMap segmentProperties = newSegment.getChild(JcrConstants.JCR_CONTENT)
						.adaptTo(ModifiableValueMap.class);				
				segmentProperties.put("segmentName", segmentName);
				segmentProperties.put("segmentBoost", boost);
				segmentProperties.put("jcr:title", segmentTitle);
				resourceResolver.commit();

				try {
					responseCode.put("response", i18n.get("New segment created successfully."));
				} catch (Exception e2) {
					log.error("Error in setting json response code {}", e2.getMessage());
					log.debug("Error in setting json response code {}", e2.getMessage());
				}
				response.getWriter().append(responseCode.toString());
				log.debug("response COde {}" , responseCode.toString());
			} catch (WCMException e) {
				try {
					responseCode.put("response", i18n.get("Unable to create new segment."));
				} catch (Exception e2) {
					log.error("Error in setting json response code {}", e2.getMessage());
					log.debug("Error in setting json response code {}", e2.getMessage());

				}

				response.getWriter().append(responseCode.toString());
				response.setStatus(403);
				return;
			}
		}

	}
}
