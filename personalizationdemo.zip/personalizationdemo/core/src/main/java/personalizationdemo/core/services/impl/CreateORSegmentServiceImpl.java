package personalizationdemo.core.services.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import personalizationdemo.core.services.CreateORSegmentService;
import personalizationdemo.core.utils.MaskHelper;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

@Component(service = CreateORSegmentService.class)
public class CreateORSegmentServiceImpl implements CreateORSegmentService {

	private final Logger log = LoggerFactory.getLogger(CreateORSegmentServiceImpl.class);

	private static String OR_SEGMENT_TEMPLATE_PATH = "/apps/personalizationdemo/components/structure/pedemosegmentpage/ortemplate";
	private static String SEGMENT_ROOT = PEDemoConstants.PEDEMO_SEG_PATH;
	private static final String TRAIT_USER_PROFILE_ID_KEY_PROP = "property";
	private static final String TRAIT_USER_PROFILE_ID_KEY_PROP_VAL = "userprofile/id";
	private static final String TRAIT_USER_PROFILE_VALUE_PROP = "value";
	private static final String OR_NODE_PATH = "/jcr:content/traits/orpar";
	private static final String PROPERTY_VALUE = "property_value_";
	private static final String RIGHT_VALUE = "right";
	private static final String LEFT_VALUE = "left";
	private static String PEDEMOGROUPSEG_JSON_PATH=PEDemoConstants.PEDEMO_GROUPSEG_JSON_PATH;

	private static int commitCounter = 0;

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private Replicator replicator;

	@Override
	public void createORSegment(String jsonPath, String segmentRootPath, String orTemplatePath) throws Exception {

		Map<String, Object> param = new HashMap<String, Object>();
		param.put(ResourceResolverFactory.SUBSERVICE, PEDemoConstants.PEDEMO_SUB_SERVICE);
		ResourceResolver resourceResolver = null;
		Session session = null;
		Node node;

		if (jsonPath.trim().length() != 0 && jsonPath != null) {
			PEDEMOGROUPSEG_JSON_PATH = jsonPath;
		}
		System.out.println("Segment json path"+ PEDEMOGROUPSEG_JSON_PATH);
		if (segmentRootPath.trim().length() != 0 && segmentRootPath != null) {
			SEGMENT_ROOT = segmentRootPath;
		}
		System.out.println("segment root path"+SEGMENT_ROOT);
		if (orTemplatePath.trim().length() != 0 && orTemplatePath != null) {
			OR_SEGMENT_TEMPLATE_PATH = orTemplatePath;
		}
		System.out.println("OR template path"+ OR_SEGMENT_TEMPLATE_PATH);
		try {
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
			session = resourceResolver.adaptTo(Session.class);
			node = session.getNode(PEDEMOGROUPSEG_JSON_PATH);
			Asset asset = resourceResolver.getResource(node.getPath()).adaptTo(Asset.class);
			JsonElement segElement = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
			List<String> jsonSegmentList = new ArrayList<>();
			JsonObject masterJsonObj = segElement.getAsJsonObject();
			JsonArray masterJsonArray = masterJsonObj.getAsJsonArray("segments");
			for (int i = 0; i < masterJsonArray.size(); i++) {
				JsonObject masterJsonObjValues = masterJsonArray.get(i).getAsJsonObject();
				String segmentTitle = UtilityHelper
						.removeQuotes(masterJsonObjValues.getAsJsonPrimitive("segmentName").toString());
				String segmentBoost = UtilityHelper
						.removeQuotes(masterJsonObjValues.getAsJsonPrimitive("priority").toString());
				System.out.println("Segments Titles... {}"+ segmentTitle);
				System.out.println("Segments Boost... {}"+ segmentBoost);
				String segmentName = UtilityHelper.getSegmentName(segmentTitle);
				jsonSegmentList.add(segmentName);
				System.out.println("1");
				int boost = Integer.parseInt(segmentBoost);
				System.out.println("2");
				copyORParNode(resourceResolver, session, segmentTitle, masterJsonObjValues, boost,segmentName);
				System.out.println("after node copied ");
			}
			activateSegment(resourceResolver, session, jsonSegmentList);
			System.out.println("after activateSegment ");
			updateAndActivateSegmentBoostNotInJson(resourceResolver, session, jsonSegmentList);
			System.out.println("after update boost and activateSegment ");
		} catch (PathNotFoundException e) {
			log.error("PathNotFoundException in CreateORSegmentsFromJson {}" + e.getMessage());
			throw e;
		} catch (RepositoryException e) {
			log.error("RepositoryException in CreateORSegmentsFromJson {}" + e.getMessage());
			throw e;
		} catch (JsonSyntaxException e) {
			log.error("JsonSyntaxException in CreateORSegmentsFromJson {}" + e.getMessage());
			throw e;
		} catch (IOException e) {
			log.error("IOException in CreateORSegmentsFromJson {}" + e.getMessage());
			throw e;
		} catch (Exception e) {
			log.error("Exception in CreateORSegmentsFromJson {}" + e.getMessage());
			throw e;
		} finally {
			session.logout();
			resourceResolver.close();
		}

	}

	// Activating the newly created group segments
	private void activateSegment(ResourceResolver resourceResolver, Session session, List<String> jsonSegmentList)
			throws RepositoryException, ReplicationException {
		try {
			for (String activateSegment : jsonSegmentList) {
				Node rootSegmentNode = session.getNode(SEGMENT_ROOT);
				if (rootSegmentNode.hasNode(activateSegment)) {
					Node orSegmentNode = rootSegmentNode.getNode(activateSegment);
					String segmentPath = orSegmentNode.getPath();
					replicator.replicate(session, ReplicationActionType.ACTIVATE, segmentPath);
				}
			}
		} catch (PathNotFoundException e) {
			log.error("PathNotFoundException in activateSegment {}" + e.getMessage());
			throw e;
		} catch (RepositoryException e) {
			log.error("RepositoryException in activateSegment {}" + e.getMessage());
			throw e;
		} catch (ReplicationException e) {
			log.error("ReplicationException in activateSegment {}" + e.getMessage());
			throw e;
		}

	}
	
	// Updating and activating group segments boost to -1 those are not present in Json
			private void updateAndActivateSegmentBoostNotInJson(ResourceResolver resourceResolver, Session session,
					List<String> jsonSegmentList) throws RepositoryException, ReplicationException {
				List<String> etcSegmenNametList = new ArrayList<>();
				Node SegmentResource = resourceResolver.getResource(SEGMENT_ROOT).adaptTo(Node.class);
				int updateBoost = Integer.parseInt("-1");
				try {
					NodeIterator subSegmentItr = SegmentResource.getNodes();
					String subSegmentNodeName = "";
					while (subSegmentItr.hasNext()) {
						Node subSegmentNode = subSegmentItr.nextNode();
						if (subSegmentNode.hasNode("jcr:content/traits/orpar")) {
							subSegmentNodeName = subSegmentNode.getName();
							etcSegmenNametList.add(subSegmentNodeName);

						}
					}
					etcSegmenNametList.removeAll(jsonSegmentList);
					System.out.println("ETC Segment Name List Size after removed... {}"+ etcSegmenNametList);
					for (String updateSegmentBoost : etcSegmenNametList) {
						if (SegmentResource.hasNode(updateSegmentBoost)) {
							Node orSegmentNode = SegmentResource.getNode(updateSegmentBoost);
							if (orSegmentNode.hasNode(JcrConstants.JCR_CONTENT)) {
								Node orSegmentJCRNode = orSegmentNode.getNode(JcrConstants.JCR_CONTENT);
								orSegmentJCRNode.setProperty("segmentBoost", updateBoost);							
							}
							String segmentPath = orSegmentNode.getPath();
							replicator.replicate(session, ReplicationActionType.ACTIVATE, segmentPath);
						}
					}
					session.save();

				} catch (RepositoryException e) {
					log.error("RepositoryException in updateAndActivateSegmentBoostNotInJson {}" + e.getMessage());
					throw e;
				} catch (ReplicationException e) {
					log.error("ReplicationException in updateAndActivateSegmentBoostNotInJson {}" + e.getMessage());
					throw e;
				} 
			}

	// Copying OR Par node to "etc/segmentation/pedemo-experiences" to create OR segments
	private void copyORParNode(ResourceResolver resourceResolver, Session session, String segmentTitle,
			JsonObject groupJsonObjValues, int boost,String segmentName) throws Exception {
		
		System.out.println(":::::::copy orpar node method:::::segmentTitle"+segmentTitle+ " boost "+boost+" Seg name "+segmentName);

		try {
			PageManager pageManager = (PageManager) resourceResolver.adaptTo(PageManager.class);
			Resource segmentTemplate = resourceResolver.getResource(OR_SEGMENT_TEMPLATE_PATH);
			String segmentPath = SEGMENT_ROOT + "/" + segmentName;
			Node checkResource = resourceResolver.getResource(SEGMENT_ROOT).adaptTo(Node.class);
			
			System.out.println("seg tempate "+segmentTemplate+ "seg path "+segmentPath);

			if (checkResource.hasNode(segmentName)) {
				Resource existSegment = resourceResolver.getResource(segmentPath);
				ModifiableValueMap segmentProperties = existSegment.getChild(JcrConstants.JCR_CONTENT)
						.adaptTo(ModifiableValueMap.class);
				segmentProperties.put("segmentBoost", boost);
				System.out.println("3");
			} else {
				Resource newSegment = pageManager.copy(segmentTemplate, segmentPath, null, false, true);
				ModifiableValueMap segmentProperties = newSegment.getChild(JcrConstants.JCR_CONTENT)
						.adaptTo(ModifiableValueMap.class);
				segmentProperties.put("segmentName", segmentName);
				segmentProperties.put("jcr:title", segmentTitle);
				segmentProperties.put("segmentBoost", boost);
				System.out.println("4");
			}
			resourceResolver.commit();
			JsonArray accountsJsonArray = groupJsonObjValues.getAsJsonArray("accounts");
			List<String> accountName = new ArrayList<>();
			List<String> accountID = new ArrayList<>();
			System.out.println("accountjson arry size "+accountsJsonArray.size());
			for (int k = 0; k < accountsJsonArray.size(); k++) {
				System.out.println("5");
				JsonObject accountJsonObjValues = accountsJsonArray.get(k).getAsJsonObject();
				accountID.add(MaskHelper.encrypt(
						UtilityHelper.removeQuotes(accountJsonObjValues.getAsJsonPrimitive("id").toString()),
						PEDemoConstants.PEDEMO_MASK_KEY));
				System.out.println("6");
				accountName.add(
						UtilityHelper.removeQuotes(accountJsonObjValues.getAsJsonPrimitive("accountName").toString()));
				System.out.println("Account ID... {}"+ accountID.get(k));
				System.out.println("Account Name... {}"+ accountName.get(k));
			}
			createPropertyWithLeftRightNode(resourceResolver, session, accountID, segmentPath);

		} catch (Exception e) {
			log.error("Exception in copyORParNode {}" + e.getMessage());
			throw e;
		}
	}

	// Creating dynamic property-value with left and right nodes and setting the
	// required properties
	private void createPropertyWithLeftRightNode(ResourceResolver resourceResolver, Session session,
			List<String> accountID, String segmentPath) throws RepositoryException {
		try {
			Node orNode = resourceResolver.getResource(segmentPath + OR_NODE_PATH).adaptTo(Node.class);
			deleteChildNodes(orNode,session);			
			
			Node leftNode;
			Node rightNode;
			for (int n = 0; n < accountID.size(); n++) {
				if (accountID.get(n) != null && accountID.get(n) != "") {
					
						orNode.addNode(PROPERTY_VALUE + (n + 1));
						Node proValue = orNode.getNode(PROPERTY_VALUE + (n + 1));
						System.out.println("accountID ... {}"+ accountID.get(n));
						proValue.setProperty("dataType", "string");
						proValue.setProperty("operator", "equal");
						proValue.setProperty("sling:resourceType",
								"cq/contexthub/components/traits/generic-comparison/variants/property-value");
						proValue.addNode(LEFT_VALUE);
						proValue.addNode(RIGHT_VALUE);
						leftNode = proValue.getNode(LEFT_VALUE);
						leftNode.setProperty(TRAIT_USER_PROFILE_ID_KEY_PROP, TRAIT_USER_PROFILE_ID_KEY_PROP_VAL);
						leftNode.setProperty("sling:resourceType",
								"cq/contexthub/components/traits/generic-comparison/type/property");
						rightNode = proValue.getNode(RIGHT_VALUE);
						rightNode.setProperty(TRAIT_USER_PROFILE_VALUE_PROP, accountID.get(n));
						rightNode.setProperty("sling:resourceType",
								"cq/contexthub/components/traits/generic-comparison/type/value");
					
					commitCounter++;

					if (commitCounter == 100) {
						session.save();
						commitCounter = 0;
					}

				}
			}
			session.save();
		} catch (RepositoryException e) {
			log.error("RepositoryException in createPropertyWithLeftRightNode {}" + e.getMessage());
			throw e;
		}
	}
	
	void deleteChildNodes(Node parentNode, Session session) throws RepositoryException {
		System.out.println("::::::::::in deleteChildNodes method. Parent node under operation is "+parentNode.getPath());
		NodeIterator parentNodeIter=parentNode.getNodes();
		
		while(parentNodeIter.hasNext()) {			
			Node childNode=parentNodeIter.nextNode();
			childNode.remove();
		}
		session.save();
		System.out.println(":::::::::::::deleteChildNodes operation done::::::");
	}
}
