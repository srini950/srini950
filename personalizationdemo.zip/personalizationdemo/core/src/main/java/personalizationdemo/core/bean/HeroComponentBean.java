package personalizationdemo.core.bean;

public class HeroComponentBean {

	private String heroTitle;
	private String buttonCTA;
	private String heroTeaser;
	private String fieldValue;
	private String staticUrlCTA;
	private String newWindow;
	private String dynamicUrlCTA;
	private String staticbtnCtaLabel;
	private String isCtaRequired;
	private String fieldType;




	public String getIsCtaRequired() {
		return isCtaRequired;
	}

	public void setIsCtaRequired(String isCtaRequired) {
		this.isCtaRequired = isCtaRequired;
	}
	
	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getHeroTitle() {
		return heroTitle;
	}

	public void setHeroTitle(String heroTitle) {
		this.heroTitle = heroTitle;
	}

	public String getButtonCTA() {
		return buttonCTA;
	}

	public void setButtonCTA(String buttonCTA) {
		this.buttonCTA = buttonCTA;
	}

	public String getHeroTeaser() {
		return heroTeaser;
	}

	public void setHeroTeaser(String heroTeaser) {
		this.heroTeaser = heroTeaser;
	}
	
	public String getStaticUrlCTA() {
		return staticUrlCTA;
	}

	public void setStaticUrlCTA(String staticUrlCTA) {
		this.staticUrlCTA = staticUrlCTA;
	}

	public String getNewWindow() {
		return newWindow;
	}

	public void setNewWindow(String newWindow) {
		this.newWindow = newWindow;
	}
	
	public String getDynamicUrlCTA() {
		return dynamicUrlCTA;
	}

	public void setDynamicUrlCTA(String dynamicUrlCTA) {
		this.dynamicUrlCTA = dynamicUrlCTA;
	}
	
	public String getStaticbtnCtaLabel() {
		return staticbtnCtaLabel;
	}

	public void setStaticbtnCtaLabel(String staticbtnCtaLabel) {
		this.staticbtnCtaLabel = staticbtnCtaLabel;
	}



	@Override
	public String toString() {
		return "HeroComponentBean [heroTitle=" + heroTitle + ", buttonCTA=" + buttonCTA + ", heroTeaser=" + heroTeaser + ", isCtaRequired=" + isCtaRequired 
				+ ", fieldValue=" + fieldValue + ", fieldType=" + fieldType + ", staticUrlCTA=" + staticUrlCTA + ", newWindow=" + newWindow + ", dynamicUrlCTA="
				+ dynamicUrlCTA + ", staticbtnCtaLabel=\" + staticbtnCtaLabel + \"]";
	}

}
