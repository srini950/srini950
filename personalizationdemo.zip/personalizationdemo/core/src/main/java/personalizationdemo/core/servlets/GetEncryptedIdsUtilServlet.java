package personalizationdemo.core.servlets;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.utils.EncodeDecodeHelper;
import personalizationdemo.core.utils.MaskHelper;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;


@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=get encrtypted id list",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "getEncryptedIds" })
public class GetEncryptedIdsUtilServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(GetEncryptedIdsUtilServlet.class);
	
	@Reference
	private ResourceResolverFactory resolverFactory;
	
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
	{
		ResourceResolver resourceResolver=null;
		Session session = null;
		try {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, PEDemoConstants.PEDEMO_SUB_SERVICE);
			 resourceResolver = resolverFactory.getServiceResourceResolver(param);
			 session = resourceResolver.adaptTo(Session.class);
			 log.debug("encrypt ids servlet:::::::::::");
			 Node keywordJsonnode = session.getNode(PEDemoConstants.ACCOUNT_JSON_PATH);
			 Asset asset = resourceResolver.getResource(keywordJsonnode.getPath()).adaptTo(Asset.class);
			 JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
			 JsonObject jsonObj = obj.getAsJsonObject();
			 JsonArray jsonArray = jsonObj.getAsJsonArray(PEDemoConstants.ACCOUNT_MAP_ATTR);			 			 
			 Map<String, String> encryptListMap = new HashMap<String, String>();
			 Map<String, String> encodeDecodeMap = new HashMap<String, String>();
			 
			 for (int i = 0; i < jsonArray.size(); i++) {
					JsonObject rec = jsonArray.get(i).getAsJsonObject();
					String key = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("id").toString());
					String encryptedValue=MaskHelper.encrypt(key, PEDemoConstants.PEDEMO_MASK_KEY);
					if (encryptedValue != null) {
						encryptListMap.put(key, encryptedValue);
					} 
					 log.debug(":::Keyt:::::::::::"+key+"::::::::::encrypted ID:::::::::::::::"+encryptedValue);
					String accountName=UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("accountname").toString());
					getEncodedNames(encodeDecodeMap,accountName);
					
			 }
			 
			 	response.setContentType("application/json");
				final PrintWriter out = response.getWriter();
				ObjectMapper mapper = new ObjectMapper();
				out.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(encryptListMap));
				out.println();
				out.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(encodeDecodeMap));
				out.flush();
			
		}catch (Exception e) {
			log.error("exception in Servlet {}", e.getMessage());
			log.debug("Exception in Servlet {}", e.getMessage());
		}finally {
			 session.logout();
			 resourceResolver.close();
		}
		
		
	}
	
	static void getEncodedNames( Map<String, String> encodeDecodeMap, String target) throws Exception {
		EncodeDecodeHelper td= new EncodeDecodeHelper();
        String encrypted=td.encrypt(target);
        String decrypted=td.decrypt(encrypted);
        
        encodeDecodeMap.put("String To Encrypt: "+ target+ ":::Encrypted String:::: "+encrypted, "::::Decrypted String:: " + decrypted);

        log.debug("String To Encrypt: "+ target);
        log.debug("Encrypted String:" + encrypted);
        log.debug("Decrypted String:" + decrypted);
		
	}
}
