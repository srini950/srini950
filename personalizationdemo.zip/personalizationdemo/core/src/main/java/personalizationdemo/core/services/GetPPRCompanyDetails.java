package personalizationdemo.core.services;

import java.util.ArrayList;
import org.apache.sling.api.resource.ResourceResolver;
import personalizationdemo.core.bean.GetPPRCompanyDetailsPOJO;

public interface GetPPRCompanyDetails {

	public ArrayList<GetPPRCompanyDetailsPOJO> getPPRCompanyDetail(ResourceResolver resolver, String userId)throws Exception;
}
