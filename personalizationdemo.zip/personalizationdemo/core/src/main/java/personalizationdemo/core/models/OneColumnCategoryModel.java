package personalizationdemo.core.models;

import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.common.ValueMapDecorator;
import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.EmptyDataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.text.Text;

import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.CategoryHelper;

public class OneColumnCategoryModel extends WCMUsePojo {
	private static final Logger logger = LoggerFactory.getLogger(OneColumnCategoryModel.class);
	ResourceResolver resolver = null;
	@Override
	public void activate() {
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class);
		try {
			logger.debug("in OneColumnCategoryModel ");
			System.out.println("in onecol category model");
					resolver = resolverInterface.getResolver();
					SlingHttpServletRequest request = getRequest();
					String path = request.getParameter("item");
					System.out.println("path is "+path);
					logger.debug("request getparam item: {}" , path);
					Node headerNode = getHeaderNodeFromPath(path, resolver);
					request.setAttribute(DataSource.class.getName(), EmptyDataSource.instance());
					if (headerNode != null) {
						Map<String, String> categoryItemsMap = CategoryHelper.getCategoryTextId(headerNode,CategoryHelper.CATEGORY_PROPERTY);
						Map<String, String> categoryItems = new HashMap<String, String>(categoryItemsMap);
						if (categoryItems != null) {
							@SuppressWarnings("unchecked")
							DataSource ds = new SimpleDataSource(
									new TransformIterator(categoryItems.keySet().iterator(), new Transformer() {
										public Object transform(Object o) {
											String categoryId = (String) o;
											ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
											vm.put("value", categoryId);
											vm.put("text", categoryItems.get(categoryId));
											return new ValueMapResource(resolver, new ResourceMetadata(), "nt:unstructured", vm);
										}
			
									}));
							request.setAttribute(DataSource.class.getName(), ds);
						}
					}
		}catch(Exception e) {
			logger.debug("Exception in  OneColumnCategoryModel {}",e.getMessage());
			logger.error("Exception in  OneColumnCategoryModel {}",e.getMessage());
		}finally {
			resolver.close();
		}
	}

	Node getHeaderNodeFromPath(String pagePath, ResourceResolver resourceResolver) {
		if (pagePath != null) {
			int level = pagePath.contains("pedemo") ? 2 : 3;
			return resourceResolver.resolve(Text.getAbsoluteParent(pagePath, level) + "/jcr:content/header")
					.adaptTo(Node.class);
		} else {
			return null;
		}

	}
}