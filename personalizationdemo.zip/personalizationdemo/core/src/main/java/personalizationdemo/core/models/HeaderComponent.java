package personalizationdemo.core.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.text.Text;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.bean.HeaderComponentBean;
import personalizationdemo.core.bean.HeaderComponentCategoryBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class HeaderComponent extends WCMUsePojo {

	HeaderComponentBean headerComponentBean = null;
	private static final Logger logger = LoggerFactory.getLogger(HeaderComponent.class);
	List<HeaderComponentCategoryBean> listCategoryItems = null;

	@Override
	public void activate() {
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class);
		ResourceResolver resourceResolver = null;
		try {
			resourceResolver = resolverInterface.getResolver();
			logger.debug("HeaderComponent activate ");
			String errorpageUrl = "/content/pedemo/en/404.html";
			String genericErrorPage = "/content/pedemo/en/general-error-page.html";
			String corpTravelPage = "https://www.google.com";
			headerComponentBean = new HeaderComponentBean();
			headerComponentBean.setCurrentPagePath(UtilityHelper
					.getSparkUrlString(getCurrentPage().getPath() + PEDemoConstants.HTML_EXTENSION, getRequest()));
			logger.debug("current page path {}", headerComponentBean.getCurrentPagePath());
			Page currentPage = getResourcePage();
			String sitename = Text.getAbsoluteParent(currentPage.getPath(), 2);
			if (sitename != null) {
				headerComponentBean.setHeaderComPath(sitename + "/jcr:content/header");
				headerComponentBean.setSiteName(Text.getAbsoluteParent(currentPage.getPath(), 2));
				Node header = resourceResolver.getResource(sitename + "/jcr:content/header").adaptTo(Node.class);

				if (header.hasProperty("errorpageUrl")) {
					errorpageUrl = header.getProperty("errorpageUrl").getString();
				}
				if (header.hasProperty("genericErrorPage")) {
					genericErrorPage = header.getProperty("genericErrorPage").getString();
				}
				if (header.hasProperty("deltacorpURL")) {
					corpTravelPage = header.getProperty("deltacorpURL").getString();
				}
				headerComponentBean.setErrorPage(errorpageUrl);
				headerComponentBean.setGenericErrorPage(genericErrorPage);
				headerComponentBean.setCorpTravelerPage(corpTravelPage);
			}

			String prop = get("prop", String.class);
			
			Node currentNode = getResource().adaptTo(Node.class);
			//ResourceResolver resourceResolver1 = getRequest().getResourceResolver();

			String hompePageLink = UtilityHelper
					.getHomePagePath(currentNode != null ? resourceResolver.map(currentNode.getPath()) : "");

			if (hompePageLink != null)
				headerComponentBean.setHomePageLink(UtilityHelper.getSparkUrlString(hompePageLink, getRequest()));
			
			if (prop != null)
				headerComponentBean.setCategoryList(getCategoryItems(prop, resourceResolver));
			
			String bookinglink = getProperties().get("bookingLink", "");
			if (bookinglink != null) {
				headerComponentBean.setBookingLink(bookinglink);
				String bookingLinkValue = "";
				if (bookinglink.equalsIgnoreCase("booking-urls")) {
					bookingLinkValue = "";
				} else if (bookinglink.equalsIgnoreCase("delta-vacations")) {
					bookingLinkValue = "https://www.google.com";
				} else {
					bookingLinkValue = "https://www.adobe.com";
				}
				headerComponentBean.setBookingLinkValue(bookingLinkValue);

			}

		} catch (Exception e) {
			logger.debug("Exception in HeaderComponent {}", e.getMessage());
			logger.error("Exception in HeaderComponent {}", e.getMessage());
		} finally {
			resourceResolver.close();
		}

	}

	public List<HeaderComponentCategoryBean> getCategoryItems(String prop, ResourceResolver resourceResolver)
			throws Exception {

		List<HeaderComponentCategoryBean> beanList = new ArrayList<HeaderComponentCategoryBean>();
		logger.debug(" in getcategory items {}", prop);
		Session session = null;
		try {
			session = resourceResolver.adaptTo(Session.class);
			Node benefiteOfferNode = session.getNode(PEDemoConstants.GENERAL_FIELDTYPE_DROPDOWN_PATH);
			Asset asset = resourceResolver.getResource(benefiteOfferNode.getPath()).adaptTo(Asset.class);
			JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
			JsonArray jsonArray = obj.getAsJsonArray();
			ArrayList<String> headerFromJson = new ArrayList<>();
			for (int j = 0; j < jsonArray.size(); j++) {
				JsonObject rec = jsonArray.get(j).getAsJsonObject();
				headerFromJson.add(UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("categoryType").toString()));
			}
			String[] itemsProps = getProperties().get(prop, String[].class);
			if (itemsProps != null) {
				for (int i = 0; i < itemsProps.length; i++) {
					ObjectMapper mapper = new ObjectMapper();
					Map<String, String> propertyMap = new HashMap<>();
					logger.debug("current val {}", itemsProps[i]);
					propertyMap = mapper.readValue(itemsProps[i], new TypeReference<Map<String, String>>() {
					});
					HeaderComponentCategoryBean bean = new HeaderComponentCategoryBean();
					String categoryPath = "";
					String categoryID = "";
					String categoryName = "";
					if (propertyMap.get("categoryPath") != null && propertyMap.get("categoryPath") != "") {
						categoryPath = propertyMap.get("categoryPath");
					}
					if (propertyMap.get("categoryID") != null && propertyMap.get("categoryID") != "") {
						categoryID = propertyMap.get("categoryID");
					}
					if (propertyMap.get("categoryName") != null && propertyMap.get("categoryName") != "") {
						categoryName = propertyMap.get("categoryName");
					}
					Boolean jsonCheck = false;					
					if (headerFromJson.indexOf(categoryID) > -1 || headerFromJson.indexOf(categoryName) > -1) {
						jsonCheck = true;
					}
					String sparkID = UtilityHelper.getPageSuffix(getRequest());
					logger.debug("sparkID {}", sparkID);
					if (jsonCheck && sparkID != null) {
						Boolean check = checkAllowInHeader(categoryPath, resourceResolver);
						logger.debug("allow to show in header {}", check);
						if (check) {
							bean.setCategoryId(
									null != propertyMap.get("categoryID") ? propertyMap.get("categoryID") : "");
							bean.setCategoryName(
									null != propertyMap.get("categoryName") ? propertyMap.get("categoryName") : "");
							bean.setCategoryLink(null != propertyMap.get("categoryPath")
									? UtilityHelper.getSparkUrlString(propertyMap.get("categoryPath"), getRequest())
									: "");
							beanList.add(bean);
						}
					} else {
						bean.setCategoryId(null != propertyMap.get("categoryID") ? propertyMap.get("categoryID") : "");
						bean.setCategoryName(
								null != propertyMap.get("categoryName") ? propertyMap.get("categoryName") : "");
						bean.setCategoryLink(null != propertyMap.get("categoryPath")
								? UtilityHelper.getSparkUrlString(propertyMap.get("categoryPath"), getRequest())
								: "");
						beanList.add(bean);
					}
				}
			}
		} catch (Exception e) {
			logger.debug("Exception logged: {}", e.getMessage());
			logger.error("Exception logged: {}", e.getMessage());
			throw e;
		} finally {
			session.logout();
		}
		return beanList;
	}

	private Boolean checkAllowInHeader(String categoryPath, ResourceResolver resourceResolver) {
		List<String> childPagesList = new ArrayList<String>();
		List<String> filteredListofPagesforTargetedUser = new ArrayList<String>();
		Session session = resourceResolver.adaptTo(Session.class);
		QueryBuilder queryBuilder = getResourceResolver().adaptTo(QueryBuilder.class);
		Map<String, String> queryMap = new HashMap<String, String>();
		Boolean checkHeader = false;
		int index = categoryPath.indexOf(".html");
		String rootPath = categoryPath.substring(0, index);
		
		try {
			String sparkID = UtilityHelper.getSparkId(getRequest());
			queryMap.put("path", rootPath);
			queryMap.put("type", "cq:Page");
			queryMap.put("property", "@jcr:content/catCategoryId");
			queryMap.put("property.operation", "exists");
			queryMap.put("orderby", "@jcr:content/jcr:created");
			queryMap.put("orderby.sort", "desc");
			queryMap.put("p.limit", "-1");
			Query query = queryBuilder.createQuery(PredicateGroup.create(queryMap), session);
			SearchResult searchResult = query.getResult();
			if (null != searchResult) {
				for (Hit hit : searchResult.getHits()) {
					childPagesList.add(hit.getPath());
				}
			}
			logger.debug("childPagesList in header {}", childPagesList);
			int count = 0;
			for (String page : childPagesList) {
				if (UtilityHelper.checkpermissiontoshowInAuthor(sparkID, page + "/jcr:content", resourceResolver,
						session, getRequest()) == false) {
					filteredListofPagesforTargetedUser.add(page);
				}
			}
			for(String path : filteredListofPagesforTargetedUser){				
				Resource resource = resourceResolver.getResource(path+"/jcr:content");
				Node jcrNode = resource.adaptTo(Node.class);
				String checkPageToAppearInCatagory = jcrNode.hasProperty("detailspageShowCategorypage") ? jcrNode.getProperty("detailspageShowCategorypage").getString() : "";
				if(checkPageToAppearInCatagory.equalsIgnoreCase("true")) {
					count++;
					break;
				}
			}
			if (count > 0) {
				checkHeader = true;
			}
		} catch (Exception e) {
			logger.debug("Exception logged: {}", e.getMessage());
			logger.error("Exception logged: {}", e.getMessage());
		}
		return checkHeader;
	}

	public HeaderComponentBean getHeaderComponentBean() {
		return this.headerComponentBean;

	}

}
