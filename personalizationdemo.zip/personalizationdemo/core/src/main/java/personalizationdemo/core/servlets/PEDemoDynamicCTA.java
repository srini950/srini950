package personalizationdemo.core.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;


@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Segment Hide and Show",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "dynamicCTA" })
public class PEDemoDynamicCTA extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(PEDemoDynamicCTA.class);
	private static String heroPath="/jcr:content/parsys/hero";

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		log.debug("in dynamicCTA do get ");
		

		try {
			ResourceResolver resourceResolver = request.getResourceResolver();
			final PrintWriter out = response.getWriter();
			String resourcePath= request.getParameter("pagePath");
			String resourceJCRPath = request.getResource().getPath();
			log.debug("resourceJCRPath : {}" ,resourceJCRPath);
			String contextID= request.getParameter("contextId");
			String fieldType="";
			String fieldValue="";
			Session session= resourceResolver.adaptTo(Session.class);
			ObjectMapper mapper = new ObjectMapper();
			Node rootNode = resourceResolver.getResource(resourcePath+heroPath).adaptTo(Node.class);
			log.debug("rooteNode {}",rootNode.getPath());
			if(rootNode.hasProperty("fieldType") && rootNode.hasProperty("fieldValue")) {
				fieldType = rootNode.getProperty("fieldType").getString().toString();	
				fieldValue = rootNode.getProperty("fieldValue").getString().toString();
				log.debug("fieldType {}",fieldType );
				log.debug("fieldValue {}",fieldValue);
			}
			
			Node node = session.getNode(PEDemoConstants.masterDynamicPath);
			Asset asset=resourceResolver.getResource(node.getPath()).adaptTo(Asset.class);
			
			JsonElement obj = new JsonParser().parse(UtilityHelper.getJsonStringFromAsset(asset));
			JsonObject jsonObj = obj.getAsJsonObject();
			JsonArray jsonArray=jsonObj.getAsJsonArray(contextID);
			ArrayList<String> pprCmplist = new ArrayList<String>();
			for(int i=0; i<jsonArray.size(); i++)
            {
			JsonObject rec = jsonArray.get(i).getAsJsonObject();
				String fieldTypeMST  = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("fieldType").toString());
				String fieldValueMST = UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("fieldName").toString());
				if(fieldTypeMST.equalsIgnoreCase(fieldType) && fieldValueMST.equalsIgnoreCase(fieldValue)){
					pprCmplist.add(UtilityHelper.removeQuotes(rec.getAsJsonPrimitive("fieldValue").toString()));
				}									
            }
			ArrayNode arrayNode = mapper.createArrayNode();
			for (int i = 0; i < pprCmplist.size(); i++) {
				ObjectNode objectNode = mapper.createObjectNode();
				objectNode.put("fieldValue",pprCmplist.get(i));
				arrayNode.add(objectNode);
			}
			out.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(arrayNode));
			out.flush();

		} catch (Exception e) {
			log.error("exception in SegmentTitleServlet {}", e.getMessage());
			log.debug("Exception in SegmentTitleServlet {}", e.getMessage());
		}

	}
}
