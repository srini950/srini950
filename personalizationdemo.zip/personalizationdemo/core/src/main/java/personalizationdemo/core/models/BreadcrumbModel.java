package personalizationdemo.core.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.cq.wcm.core.components.models.NavigationItem;
import com.day.cq.wcm.api.Page;
import personalizationdemo.core.utils.UtilityHelper;
import personalizationdemo.core.utils.PEDemoConstants;

public class BreadcrumbModel extends WCMUsePojo {
    private static final Logger logger = LoggerFactory.getLogger(BreadcrumbModel.class);
    public static final String PN_SHOW_HIDDEN = "showHidden";
    public static final String PN_HIDE_CURRENT = "hideCurrent";
    public static final String PN_START_LEVEL = "startLevel";

    private Page  currentPage;
    private boolean showHidden;
    private boolean hideCurrent;
    private int startLevel;
    private List<NavigationItem> items;
    private String homePagePath;


    @Override
    public void activate() throws Exception {
        String sparkID = UtilityHelper.getPageSuffix(getRequest());
        currentPage = getCurrentPage();
		if(sparkID !=null) {
			currentPage = getCurrentPage();
		}
		else {
			if(getRequest().getCookie("pagePath")!=null)
			{
				if(getRequest().getCookie("pagePath").getValue()!=null && getRequest().getCookie("pagePath").getValue()!=""){
					String pagePath=getRequest().getCookie("pagePath").getValue();
					currentPage = getResourceResolver().getResource(pagePath).adaptTo(Page.class);
				}
			}
		}
        homePagePath = UtilityHelper.getSparkUrlString(getCurrentStyle().get("homePagePath",PEDemoConstants.PEDEMO_CONTENT_HOME_PAGEPATH),getRequest());
        int designLevelStart =(Integer) getCurrentStyle().get("startLevel", 0).intValue();
        if(designLevelStart != 0 && designLevelStart > 3) {
            this.startLevel = designLevelStart;
        }else {
            this.startLevel = 3;
        }
        //this.startLevel = ((Integer)getProperties().get("startLevel", getCurrentStyle().get("startLevel", 3))).intValue();
        this.showHidden = ((Boolean)getProperties().get("showHidden", getCurrentStyle().get("showHidden", Boolean.valueOf(false)))).booleanValue();
        this.hideCurrent = ((Boolean)getProperties().get("hideCurrent", getCurrentStyle().get("hideCurrent", Boolean.valueOf(false)))).booleanValue();

    }

    public Collection<NavigationItem> getItems()
    {
        if (this.items == null)
        {
            this.items = new ArrayList();
            createItems();
        }
        return this.items;
    }

    private List<NavigationItem> createItems()
    {
        int currentLevel = this.currentPage.getDepth();
        addNavigationItems(currentLevel);
        return this.items;
    }

    private void addNavigationItems(int currentLevel)
    {
        while (this.startLevel < currentLevel)
        {
            Page page = this.currentPage.getAbsoluteParent(this.startLevel);
            String pagePath =UtilityHelper.getSparkUrlString(page.getPath()+".html",getRequest());
            String pageShortName = page.getProperties().get("catShortName", page.getTitle());

            if (page != null)
            {
                boolean isActivePage = page.equals(this.currentPage);
                if ((isActivePage) && (this.hideCurrent)) {
                    break;
                }
                if (checkIfNotHidden(page))
                {
                    NavigationItem navigationItem = new NavigationItemImpl(page, isActivePage,pagePath, pageShortName);
                    this.items.add(navigationItem);
                }
            }
            this.startLevel += 1;
        }
        logger.debug("items ++ {}", items);
    }

    private boolean checkIfNotHidden(Page page)
    {
        return (!page.isHideInNav()) || (this.showHidden);
    }

	public String getHomePagePath() {
		return this.homePagePath;
	}
	
	
}



