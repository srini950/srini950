package personalizationdemo.core.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import personalizationdemo.core.utils.UtilityHelper;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Get Question answer",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "getFaqPage" })
public class FaqpageGetQandA extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(FaqpageGetQandA.class);
	private static final String CONTEXTHUB_PATH = "/content/campaigns/pedemo-experiences/master";
	private static final String PEDEMO_SUB_SERVICE = "pedemoSegmentService";
	private static ValueMap childProperties;
	private static ArrayList<String> locations = new ArrayList<>();
	private static String pageName;

	@Reference
	private QueryBuilder queryBuilder;

	@Reference
	private ResourceResolverFactory resolverFactory;

	private Query query;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		log.debug("in getFaqPage do get ");

		ResourceResolver resourceResolver = null;
		Session session = null;
		int listCount = 0;
		try {

			ArrayList<String> contextHubFinalSet = new ArrayList<>();
			ArrayList<String> finalSet = new ArrayList<>();
			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, PEDEMO_SUB_SERVICE);
			resourceResolver = resolverFactory.getServiceResourceResolver(param);

			String faqPagePath = request.getParameter("faqPath");
			if(faqPagePath.equalsIgnoreCase("")) {
			  return;
			}
			String[] faqSplit  = faqPagePath.split("/");
			pageName = faqSplit[faqSplit.length-1];
			listCount = Integer.parseInt(request.getParameter("listCount"));
			session = resourceResolver.adaptTo(Session.class);

			// Quert iterate to get the faq component from faq page
			final Map<String, String> map = new HashMap<String, String>();

			map.put("path", faqPagePath + "/jcr:content");
			map.put("nodename", "expandeddrawer*");
			// Order By
			map.put("orderby", "path");

			query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult result = query.getResult();

			ArrayList<String> getTargetedContent = new ArrayList<>();

			// iterate to get only locations of targeted content
			for (final Hit hit : result.getHits()) {
				String path = hit.getPath();
				Resource resources = resourceResolver.getResource(path);
				Iterator<Resource> childResources = resources.listChildren();
				if (childResources.hasNext()) {
					// if content is targeted
					childProperties = resources.adaptTo(ValueMap.class);
					locations.add(childProperties.get("location", String.class));
				}
			}

			// iterate all result for targeted non targeted content
			for (final Hit hit : result.getHits()) {
				String path = hit.getPath();
				Resource resources = resourceResolver.getResource(path);
				Iterator<Resource> childResources = resources.listChildren();
				if (childResources.hasNext()) {

					// get content from targeted content/contexthub/pedemo-experiences
					if (getTargetedContent.isEmpty()) {
						ArrayList<String> contextHubresults = getTargetedContent(request, resourceResolver, session);

						// get default values from targeted content node if contexthub returns empty
						if (contextHubresults.isEmpty()) {
							Resource childResource = childResources.next();
							childProperties = childResource.adaptTo(ValueMap.class);
							String[] faqItemsTargeted = childProperties.get("faqItems", String[].class);
							contextHubFinalSet.addAll(Arrays.asList(faqItemsTargeted));
						} else {
							contextHubFinalSet.addAll(contextHubresults);
						}
					}
				} else {

					// if content is not targeted
					childProperties = resources.adaptTo(ValueMap.class);
					String[] faqItems = childProperties.get("faqItems", String[].class);
					contextHubFinalSet.addAll(Arrays.asList(faqItems));
				}

				// break for loop if listcount in array is greater than or equals to what user
				// requested
				if (contextHubFinalSet.size() >= listCount) {
					break;
				}

			}
			response.setContentType("application/json");
			final PrintWriter out = response.getWriter();
			ObjectMapper mapper = new ObjectMapper();
			JsonElement obj =null;
			JsonObject jsonObj =null;
			for(int i = 0; i < contextHubFinalSet.size() && i < listCount ;i++) {
				obj = new JsonParser().parse(contextHubFinalSet.get(i));
				jsonObj = obj.getAsJsonObject();
				if(jsonObj.has("question")) {
					finalSet.add(jsonObj.get("question").getAsString());
				}
			}
			out.write(mapper.writerWithDefaultPrettyPrinter()
					.writeValueAsString(finalSet));
			out.flush();

		} catch (Exception e) {
			log.error("exception in  FaqpageGetQandA servlet {}", e.getMessage());
			log.debug("Exception in  FaqpageGetQandA servlet {}", e.getMessage());
		} finally {
			if(session != null) {
				session.logout();
			}
			resourceResolver.close();
		}

	}

	private ArrayList<String> getTargetedContent(SlingHttpServletRequest request, ResourceResolver resourceResolver,
			Session session) {

		String path = null;
		ArrayList<String> contextHubHits = new ArrayList<>();
		try {

			String[] segmentPath = request.getParameterValues("segmentPath[]");
			if(segmentPath== null) {
				String sparkId = UtilityHelper.getSparkId(request);
				segmentPath=UtilityHelper.getSegmentPaths(sparkId, session, resourceResolver);
			}
			// iterate the /content/campaigns/pedemo-experiences/master to get the curresponding
			// activity for segment
			
			ArrayList<String> segmentPaths = new ArrayList<>();
			Resource resResource = resourceResolver.getResource(CONTEXTHUB_PATH);
			String jcrContent ="jcr:content";
			for (int i = 0; i < segmentPath.length; i++) {
				Iterator<Resource> childList = resResource.listChildren();
				while (childList.hasNext()) {
					Resource activityChild = childList.next();
					if (!jcrContent.equalsIgnoreCase(activityChild.getName())) {
						Iterator<Resource> childs = activityChild.listChildren();
						while (childs.hasNext()) {
							Resource resChild = childs.next();
							if (!jcrContent.equalsIgnoreCase(resChild.getName())) {
								Resource propertyResource = resChild.getChild(jcrContent);
								childProperties = propertyResource.adaptTo(ValueMap.class);
								String segment = childProperties.get("cq:segments", String.class);
								if (segment.equalsIgnoreCase(segmentPath[i])) {
									segmentPaths.add(propertyResource.getPath());
								}
							}
						}
					}
				}
			}
			
			//iterate if any segmentpaths present
			Iterator<String> segmentPathsIterator = segmentPaths.iterator();
			while (segmentPathsIterator.hasNext()) {
				path = segmentPathsIterator.next();
				final Map<String, String> maps = new HashMap<String, String>();
				maps.put("path", path.split("/jcr:content")[0]);
				maps.put("nodename", "jcr:content");
				maps.put("property", "jcr:title");
				maps.put("property.value", pageName+"(expandeddrawer)");
				maps.put("property.operation", "equals"); 
				maps.put("group.p.or", "true");
				for (int i = 0; i < locations.size(); i++) {
					maps.put("group." + (i + 1) + "_property", "location");
					maps.put("group." + (i + 1) + "_property.value", locations.get(i));
					maps.put("group." + (i + 1) + "_property.operation", "equals"); 
				}

				query = queryBuilder.createQuery(PredicateGroup.create(maps), session);
				SearchResult results = query.getResult();
				String contentPath = null;
				for (final Hit hits : results.getHits()) {
					contentPath = hits.getPath();
					Resource childResource = resourceResolver.getResource(contentPath + "/par").listChildren().next();
					childProperties = childResource.adaptTo(ValueMap.class);
					String[] faqItems = childProperties.get("faqItems", String[].class);
					contextHubHits.addAll(Arrays.asList(faqItems));
				}
				if (contentPath != null) {
					break;
				}
			}

		} catch (Exception e) {
			log.error("exception in FaqpageGetQandA servlet {}", e.getMessage());
			log.debug("Exception in  FaqpageGetQandA servlet {}", e.getMessage());
		}
		return contextHubHits;

	}

}
