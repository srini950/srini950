package personalizationdemo.core.bean;

import java.util.List;

public class CarouselComponentBean {
	
	private String ctadyanmicLink;
	private String cardTitle;
	private String carTeaser;
	private String uniqueID;
	private String staticURL;
	private String ctaBtnTxt;
	private String seconds;
	private List<CarouselComponentCardBean> cardList = null;

	public String getCtadyanmicLink() {
		return ctadyanmicLink;
	}

	public void setCtadyanmicLink(String ctadyanmicLink) {
		this.ctadyanmicLink = ctadyanmicLink;
	}

	public String getCardTitle() {
		return cardTitle;
	}

	public void setCardTitle(String cardTitle) {
		this.cardTitle = cardTitle;
	}

	public String getCarTeaser() {
		return carTeaser;
	}

	public void setCarTeaser(String carTeaser) {
		this.carTeaser = carTeaser;
	}

	public String getUniqueID() {
		return uniqueID;
	}

	public void setUniqueID(String uniqueID) {
		this.uniqueID = uniqueID;
	}

	public String getStaticURL() {
		return staticURL;
	}

	public void setStaticURL(String staticURL) {
		this.staticURL = staticURL;
	}

	public String getCtaBtnTxt() {
		return ctaBtnTxt;
	}

	public void setCtaBtnTxt(String ctaBtnTxt) {
		this.ctaBtnTxt = ctaBtnTxt;
	}

	public String getSeconds() {
		return seconds;
	}

	public void setSeconds(String seconds) {
		this.seconds = seconds;
	}

	public List<CarouselComponentCardBean> getCardList() {
		return cardList;
	}

	public void setCardList(List<CarouselComponentCardBean> cardList) {
		this.cardList = cardList;
	}

}
