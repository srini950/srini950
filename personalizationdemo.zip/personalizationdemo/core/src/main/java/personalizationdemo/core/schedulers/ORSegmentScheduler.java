package personalizationdemo.core.schedulers;

import java.time.Instant;

import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import personalizationdemo.core.services.CreateORSegmentService;

/**
 * A simple demo for cron-job like tasks that get executed regularly. It also
 * demonstrates how property values can be set. Users can set the property
 * values in /system/console/configMgr
 */
@Designate(ocd = ORSegmentScheduler.Config.class)
@Component
public class ORSegmentScheduler {

	@ObjectClassDefinition(name = "PEDEMO Segment Scheduler", description = "This configuration is to run the job to create group segments")
	public static @interface Config {

		@AttributeDefinition(name = "scheduling expresion ", description = "Cron-job expression '0 30 11 ? * MON-SUN' this is for monday to friday")
		String scheduler_expression() default "";
		
		@AttributeDefinition(name = "group segment json path", description = "Please provide json path")
		String jsonPath() default "";
		
		@AttributeDefinition(name = "segment root path", description = "Please provide segment root path")
		String segmentRootPath() default "";
		
		@AttributeDefinition(name = "OR segment template path", description = "Please provide OR segment template path")
		String orSegmentTemplatePath() default "";
	}

	@Reference
	private Scheduler scheduler;

	@Reference
	CreateORSegmentService createORSegment;

	private final Logger log = LoggerFactory.getLogger(getClass());

	private String scheduler_expression;

	@Activate
	protected void activate(final Config config) {
		scheduler_expression = config.scheduler_expression();
		String json_path = config.jsonPath();
		String segment_root_path = config.segmentRootPath();
		String or_template_path = config.orSegmentTemplatePath();
		String schedulingExpression = scheduler_expression;

		final Runnable job = new Runnable() {
			public void run() {
				log.debug("Job is running now...'{}'", Instant.now().toString());
				try {
					log.debug("Calling CreateORSegmentService");
					createORSegment.createORSegment(json_path, segment_root_path, or_template_path);
				} catch (Exception e) {
					log.error("Exception in run() of ORSegmentScheduler {}" + e.getMessage());
				}
			}
		};
		try {
			final ScheduleOptions scheduleOptions = scheduler.EXPR(schedulingExpression);
			scheduler.schedule(job, scheduleOptions);

		} catch (Exception e) {
			log.error("Exception in ORSegmentScheduler {}" + e.getMessage());
		}

	}
}
