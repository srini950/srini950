package personalizationdemo.core.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import personalizationdemo.core.bean.CategoryComponentBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class CategoryComponent extends WCMUsePojo{
	
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	List<CategoryComponentBean> categoryItems = null;
	String sparkID = "";
	String sideNavBarTitle = "";
	String viewAllPage = "";
	String viewAllOpenInNewWindow = "";
	boolean showViewAll = false;
	
	
	@Override
	public void activate(){
		String prop = get("prop", String.class);
		String sourceType = get("source", String.class);

		if("manual".equalsIgnoreCase(sourceType))
			categoryItems = populateCategorytems(prop);
		else
			categoryItems = automaticCategoryItems(sourceType);
	}
	
	public List<CategoryComponentBean> populateCategorytems(String prop){
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		sparkID = UtilityHelper.getSparkId(getRequest());
		String currentPage = "";
		
		List<CategoryComponentBean> beanList = new ArrayList<CategoryComponentBean>();
		String includeCTA="";
		String type="";
		String fieldType="";
		String fieldValue="";
		String fieldUrl="";
		int counter = 1;
		try{
			resourceResolver = resolverInterface.getResolver();
			session = resourceResolver.adaptTo(Session.class);
			if(getRequest().getPathInfo().startsWith("/content/campaigns")){				
				currentPage = getRequest().getCookie("pagePath").getValue();
				log.debug("TARGETED COMPONENT {Manual flow}:>>PAGEPATH"+currentPage);									
			}
			else{
				currentPage = getCurrentPage().getPath();
				log.debug("NON-TARGETED COMPONENT {Manual flow}:>>PAGEPATH"+currentPage);
			}
			Resource pageResource = resourceResolver.getResource(currentPage+"/jcr:content");
			Node pageNode = pageResource.adaptTo(Node.class);
			sideNavBarTitle = pageNode.hasProperty("jcr:title") ? pageNode.getProperty("jcr:title").getString() : "";
			String[] itemsProps = getProperties().get(prop, String[].class);
			if(null!=itemsProps){
				for(int i=0; i<itemsProps.length; i++){
					ObjectMapper mapper = new ObjectMapper();
					Map<String,String> propertyMap = new HashMap<String,String>();
					propertyMap = mapper.readValue(itemsProps[i], new TypeReference<Map<String,String>>() {});
					
					CategoryComponentBean categoryComponentBean = new CategoryComponentBean();
					categoryComponentBean.setShortname(null!=propertyMap.get("shortname") ? propertyMap.get("shortname") : "");
					categoryComponentBean.setPreheader(null!=propertyMap.get("preheader") ? propertyMap.get("preheader") :"");
					categoryComponentBean.setTitle(null!=propertyMap.get("title") ? propertyMap.get("title") : "");
					categoryComponentBean.setTeaser(null!=propertyMap.get("teaser") ? propertyMap.get("teaser") : "");
					categoryComponentBean.setSparkImage1(null!=propertyMap.get("sparkImage1") ? propertyMap.get("sparkImage1") : "");
					categoryComponentBean.setSparkImage2(null!=propertyMap.get("sparkImage2") ? propertyMap.get("sparkImage2") :"");
					if(propertyMap.get("includeCTA")!=null){						
						includeCTA = propertyMap.get("includeCTA");
						categoryComponentBean.setCtaButtonRequired(includeCTA);
						if(includeCTA.equalsIgnoreCase("include")) {
							categoryComponentBean.setButtonLabel(null!=propertyMap.get("buttonLabel") ? propertyMap.get("buttonLabel") : "");
							if(propertyMap.get("type")!=null) {
								type=propertyMap.get("type");
								if(type.equalsIgnoreCase("static")) {
									categoryComponentBean.setButtonType(type);
									String ctaURL = (null!=propertyMap.get("ctaUrl") ? propertyMap.get("ctaUrl") : "");
									if(null != sparkID && !"".equals(ctaURL) && ctaURL.startsWith(PEDemoConstants.PEDEMO_CONTENT_PREFIX))
									{
										if(ctaURL.contains(".html"))
											ctaURL = ctaURL + "/" + sparkID;
										else
											ctaURL = ctaURL + ".html/" + sparkID;										
										
									}
									if(!"".equals(ctaURL) && !ctaURL.startsWith(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
										if(!(ctaURL.startsWith("http") || ctaURL.startsWith("https")))
											 ctaURL = "https://" + ctaURL;
									}
									categoryComponentBean.setCtaUrl(ctaURL);
								}else {
									categoryComponentBean.setButtonType(type);
									fieldType=(null!=propertyMap.get("fieldTypeCat") ? propertyMap.get("fieldTypeCat") : "");
									fieldValue=(null!=propertyMap.get("fieldValueCat") ? propertyMap.get("fieldValueCat") : "");
									Node masterjsonnode = session.getNode(PEDemoConstants.masterDynamicPath);
									Asset asset = null;
									asset = resourceResolver.getResource(masterjsonnode.getPath()).adaptTo(Asset.class);
									fieldUrl = UtilityHelper.getFieldValueCTALink(asset, sparkID, fieldType, fieldValue);
									categoryComponentBean.setFieldType(fieldType);
									categoryComponentBean.setDynamicCTAUrl(fieldUrl);
								}
							}else {
								categoryComponentBean.setButtonType("");
							}
						}
					}else {
						categoryComponentBean.setCtaButtonRequired("");
					}							
					categoryComponentBean.setOpenInNewWindow(null != propertyMap.get("openInNewWindow") ? propertyMap.get("openInNewWindow") : "");
					if(counter % 3 == 1)
						categoryComponentBean.setImagePosition("left");
					else if(counter % 3 == 2)
						categoryComponentBean.setImagePosition("center");
					else if(counter % 3 == 0)
						categoryComponentBean.setImagePosition("right");
					beanList.add(categoryComponentBean);
					counter++;
				}
			}
			
		}catch(Exception e){
			log.debug("Exception logged in manual flow: {}",e.getMessage());
		}finally {
			session.logout();
			resourceResolver.close();
			
		}
		return beanList;
	}
	
	public List<CategoryComponentBean> automaticCategoryItems(String sourceType){		

		sparkID = UtilityHelper.getSparkId(getRequest());
		List<CategoryComponentBean> beanList = new ArrayList<CategoryComponentBean>();
		List<CategoryComponentBean> nineItemsBeanList = new ArrayList<CategoryComponentBean>();
		List<String> orderedPageList = new ArrayList<String>();
		List<String> childPagesList = new ArrayList<String>();
		List<String> nonOrderedPageList = new ArrayList<String>();
		List<String> filteredListofPagesforTargetedUser = new ArrayList<String>();
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		Map<String,String> queryMap = new HashMap<String,String>();
		String categoryID = "";
		viewAllPage = getProperties().get("viewAllPage", "");
		if(null != sparkID && !"".equals(viewAllPage) && viewAllPage.startsWith(PEDemoConstants.PEDEMO_CONTENT_PREFIX))
			viewAllPage = viewAllPage + "/" + sparkID;
		viewAllOpenInNewWindow = getProperties().get("viewAllOpenInNewWindow","");
		
		try{
			resourceResolver=resolverInterface.getResolver();
			QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
			session = resourceResolver.adaptTo(Session.class);
			Node masterjsonnode = session.getNode(PEDemoConstants.masterDynamicPath);
			Asset asset = null;
			asset = resourceResolver.getResource(masterjsonnode.getPath()).adaptTo(Asset.class);
			log.debug("Asset path for Category Component"+asset.getPath());
			log.debug("REQUEST PATH::>>"+getRequest().getPathInfo());
			
			Property property = null;
			Value[] order = null;
			String rootPagePath = "";
			
			if(getRequest().getPathInfo().startsWith("/content/campaigns")){				
				rootPagePath = getRequest().getCookie("pagePath").getValue();
				log.debug("TARGETED COMPONENT {Automatic flow}:>>PAGEPATH"+rootPagePath);									
			}
			else{
				rootPagePath = getCurrentPage().getPath();
				log.debug("NON-TARGETED COMPONENT {Automatic flow}:>>PAGEPATH"+rootPagePath);
			}
			Resource pageResource = resourceResolver.getResource(rootPagePath+"/jcr:content");
			Node pageNode = pageResource.adaptTo(Node.class);
			sideNavBarTitle = pageNode.hasProperty("jcr:title") ? pageNode.getProperty("jcr:title").getString() : "";
			categoryID = pageNode.hasProperty("catCategoryId") ? pageNode.getProperty("catCategoryId").getString() : "";
			categoryID = categoryID.replace(".html", "");
			
			if (pageNode.hasProperty("items")) {
	            property = pageNode.getProperty("items");
	        }
			if (property != null) {
	            if (property.isMultiple()) {
	            	for(int i=0 ; i < property.getValues().length ; i++)
	            		order = property.getValues();
	            } else {
	            	order = new Value[1];
	            	order[0] = property.getValue();
	            }
			}
			if(null != order){
				for(Value value : order){
					
					ObjectMapper mapper = new ObjectMapper();
					Map<String,String> propertyMap = new HashMap<String,String>();
					propertyMap = mapper.readValue(value.getString(), new TypeReference<Map<String,String>>() {});
					if(null!=propertyMap.get("categoryOrder")) {
						String detailPagePath = validatePage(propertyMap.get("categoryOrder"),resourceResolver);
						if(detailPagePath!=null) {
							orderedPageList.add(detailPagePath);
						}						
					}	
				}
			}			
			queryMap.put("path",categoryID);
			queryMap.put("type", "cq:Page");
			queryMap.put("orderby", "@jcr:content/jcr:created");
			queryMap.put("orderby.sort", "desc");
			queryMap.put("p.limit", "-1");
			Query query = queryBuilder.createQuery(PredicateGroup.create(queryMap), session);
			SearchResult searchResult = query.getResult();
			if(null != searchResult){
				for(Hit hit : searchResult.getHits()){
					childPagesList.add(hit.getPath());
				}
			}
			log.debug("Child Page List for Category Component: {}",childPagesList);			
			for(String item : childPagesList){
				if(!orderedPageList.contains(item))
					nonOrderedPageList.add(item);
			}			
			
			log.debug("Non ordered Page List for Category Component: {}",nonOrderedPageList);
			for(int index = 0; index < nonOrderedPageList.size(); index++)
				orderedPageList.add(index, nonOrderedPageList.get(index));
			log.debug("Ordered page list for Category Component: {}",orderedPageList);			
			for(String page : orderedPageList){
				if(UtilityHelper.checkpermissiontoshowInAuthor(sparkID,page+"/jcr:content",resourceResolver,session,getRequest()) == false)
					filteredListofPagesforTargetedUser.add(page);
			}
			log.debug("Final Page List for Category Component: {}",filteredListofPagesforTargetedUser);	
			int i = 1;
			for(String path : filteredListofPagesforTargetedUser){
				Resource res = resourceResolver.getResource(path+"/jcr:content");
				Node node = res.adaptTo(Node.class);
				String checkPageToAppearInAutomaticCategory = node.hasProperty("detailspageShowCategorypage") ? node.getProperty("detailspageShowCategorypage").getString() : "";
				String minimumAuthoring = node.hasProperty("dpPreHeaderCat") ? node.getProperty("dpPreHeaderCat").getString() : "";
				if(path.contains(categoryID) && ("true".equalsIgnoreCase(checkPageToAppearInAutomaticCategory)) && !"".equals(minimumAuthoring) && node.hasProperty("catCategoryId")){
					System.out.println("in if ::::::::::::::");
					CategoryComponentBean categoryComponentBean = new CategoryComponentBean();
					categoryComponentBean.setPreheader(node.hasProperty("dpPreHeaderCat") ? node.getProperty("dpPreHeaderCat").getString() : "");
					categoryComponentBean.setTitle(node.hasProperty("dpTitleCat") ? node.getProperty("dpTitleCat").getString() : "");
					categoryComponentBean.setTeaser(node.hasProperty("dpBlurbCat") ? node.getProperty("dpBlurbCat").getString() : "");
					categoryComponentBean.setSparkImage1(node.hasProperty("dpImageFirstCat") ? node.getProperty("dpImageFirstCat").getString() : "");
					categoryComponentBean.setSparkImage2(node.hasProperty("dpImageSecondCat") ? node.getProperty("dpImageSecondCat").getString() : "");
					categoryComponentBean.setCtaButtonRequired(node.hasProperty("dpCTAButtonRequiredCat") ? node.getProperty("dpCTAButtonRequiredCat").getString() : "");
					
					if(node.getProperty("dpCTAButtonRequiredCat").getString().equalsIgnoreCase("true")) {						
						categoryComponentBean.setButtonType(node.hasProperty("dpButtonCTACat") ? node.getProperty("dpButtonCTACat").getString() : "");
						categoryComponentBean.setButtonLabel(node.hasProperty("dpCTANameCat") ? node.getProperty("dpCTANameCat").getString() : "");
						String ctaURL = node.hasProperty("dpUrlCTACat") ? node.getProperty("dpUrlCTACat").getString() : "";
						if(null != sparkID && !"".equals(ctaURL) && ctaURL.startsWith(PEDemoConstants.PEDEMO_CONTENT_PREFIX)) {
							if(ctaURL.contains(".html"))
								ctaURL = ctaURL + "/" + sparkID;
							else
								ctaURL = ctaURL + ".html/" + sparkID;							
						}
						if(!"".equals(ctaURL) && !ctaURL.startsWith(PEDemoConstants.PEDEMO_CONTENT_PREFIX)){
							if(!(ctaURL.startsWith("http") || ctaURL.startsWith("https")))
								 ctaURL = "https://" + ctaURL;
						}
						categoryComponentBean.setCtaUrl(ctaURL);
						String fieldType = node.hasProperty("dpFieldTypeCat") ? node.getProperty("dpFieldTypeCat").getString() : "";
						String fieldValue = node.hasProperty("dpFieldValueCat") ? node.getProperty("dpFieldValueCat").getString() : "";						
						String dynamicButtonLink="";						
						dynamicButtonLink = UtilityHelper.getFieldValueCTALink(asset, sparkID, fieldType, fieldValue);												
						categoryComponentBean.setFieldType(fieldType);
						categoryComponentBean.setDynamicCTAUrl(null != dynamicButtonLink ? dynamicButtonLink : "");
						categoryComponentBean.setOpenInNewWindow(node.hasProperty("dpNewWindowCat") ? node.getProperty("dpNewWindowCat").getString() : "");						
					}
					categoryComponentBean.setShortname(node.hasProperty("dpShortNameCat") ? node.getProperty("dpShortNameCat").getString() : "");
					if(i % 3 == 1)
						categoryComponentBean.setImagePosition("left");
					else if(i % 3 == 2)
						categoryComponentBean.setImagePosition("center");
					else if(i % 3 == 0)
						categoryComponentBean.setImagePosition("right");
					System.out.println("66666666666666::::::::::::::");
					beanList.add(categoryComponentBean);
					i++;
				}
			}
			
			if(beanList.size() > 9){
				showViewAll = true;
				for(int count = 0; count < 9; count++)
					nineItemsBeanList.add(beanList.get(count));
			}
			else
				nineItemsBeanList.addAll(beanList);
			
			log.debug("Full List: "+beanList);			
			log.debug("Nine Items List: "+nineItemsBeanList);			
		}catch(Exception e){
			log.debug("Exception logged in automatic flow: {}",e.getMessage());
		}finally {
			session.logout();
			resourceResolver.close();
			
		}
		
		if("automatic".equalsIgnoreCase(sourceType))
			return nineItemsBeanList;
		else
			return beanList;
		
	}
	private String validatePage(String pagePath, ResourceResolver resourceResolver) {
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		Page detailPage = pageManager.getContainingPage(pagePath);
		if(detailPage!=null) {
			return detailPage.getPath();
		}
		
		return null;
		
	}
	
	public List<CategoryComponentBean> getCategoryItems() {
		return categoryItems;
	}

	public String getSideNavBarTitle() {
		return sideNavBarTitle;
	}

	public boolean isShowViewAll() {
		return showViewAll;
	}

	public String getViewAllPage() {
		return viewAllPage;
	}

	public String getViewAllOpenInNewWindow() {
		return viewAllOpenInNewWindow;
	}
}