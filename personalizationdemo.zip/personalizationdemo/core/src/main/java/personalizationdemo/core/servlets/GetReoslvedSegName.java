package personalizationdemo.core.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.xml.bind.DatatypeConverter;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import personalizationdemo.core.utils.UtilityHelper;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Resolved Segement Name",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.resourceTypes=" + "cq:Page",
		"sling.servlet.extensions=" + "json", "sling.servlet.selectors=" + "getSegName" })
public class GetReoslvedSegName extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(GetReoslvedSegName.class);
	private static final String PEDEMO_SUB_SERVICE = "pedemoSegmentService";
	private static final String SLING_RESOURCE = "sling:resourceType";
	private static final String PARSYS_RESOURCE = "wcm/foundation/components/parsys";
	private static final String TARGET_RESOURCE = "cq/personalization/components/target";
	private static final String CONTEXTHUB_PATH = "/content/campaigns/pedemo-experiences/master";
	private static String location = "";
	private static ValueMap childProperties;
	private Query query;

	@Reference
	private ResourceResolverFactory resolverFactory;
	@Reference
	private QueryBuilder queryBuilder;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		location = "";
		log.debug("in getFaqPage do get ");
		String[] segmentPath;
		segmentPath = request.getParameterValues("segmentPath[]");

		String finalSeg = "";
		String segName = "";
		Cookie rootPagePathCookie = request.getCookie("pagePath");
		ResourceResolver resourceResolver = null;
		Session session = null;
		if (rootPagePathCookie != null) {
			String rootPagePath = rootPagePathCookie.getValue();
			log.debug("Rooth page path is  {}", rootPagePath);
			try {
				Map<String, Object> param = new HashMap<String, Object>();
				param.put(ResourceResolverFactory.SUBSERVICE, PEDEMO_SUB_SERVICE);
				resourceResolver = resolverFactory.getServiceResourceResolver(param);
				session = resourceResolver.adaptTo(Session.class);
				String sparkId = UtilityHelper.getSparkId(request);
				if (segmentPath == null) {
					segmentPath=UtilityHelper.getSegmentPaths(sparkId, session, resourceResolver);
				}
				Node currentPageNode = resourceResolver.getResource(rootPagePath + "/jcr:content").adaptTo(Node.class);
				NodeIterator currentPageNodeIterator = currentPageNode.getNodes();
				while (currentPageNodeIterator.hasNext()) {
					Node firstInsideRoothNode = currentPageNodeIterator.nextNode();
					if (firstInsideRoothNode.hasProperty(SLING_RESOURCE)) {
						String firstResourceProperty = firstInsideRoothNode.getProperty(SLING_RESOURCE).getString();
						if (firstResourceProperty.equalsIgnoreCase(PARSYS_RESOURCE)) {
							NodeIterator parsysCompIterator = firstInsideRoothNode.getNodes();
							int count = 0;
							while (parsysCompIterator.hasNext()) {
								Node parsysCompNode = parsysCompIterator.nextNode();
								if (parsysCompNode.hasProperty(SLING_RESOURCE)) {
									String parsysCompProperty = parsysCompNode.getProperty(SLING_RESOURCE).getString();
									if (parsysCompProperty.equalsIgnoreCase(TARGET_RESOURCE)) {
										location = parsysCompNode.getProperty("location").getString();
										count++;
										break;
									}
								}
							}
							if (count > 0) {
								break;
							}
						} else if (firstResourceProperty.equalsIgnoreCase(TARGET_RESOURCE)) {
							location = firstInsideRoothNode.getProperty("location").getString();
							break;
						}

					}
				}
				log.debug("location {}", location);
				if (location != "" && location != null) {
					finalSeg = getCampainpath(segmentPath, resourceResolver, session);
					log.debug("finalSeg {}", finalSeg);
					if (finalSeg != "" && finalSeg != null) {
						segName = getsegName(finalSeg, resourceResolver);
						log.debug("segName {}", segName);
					} else {
						for (int j = 0; j < segmentPath.length; j++) {
							String hexCheck = segmentPath[j].substring(segmentPath[j].lastIndexOf("/") + 1);
							Pattern p = Pattern.compile("[0-9a-fA-F]+");
							Matcher m = p.matcher(hexCheck.trim());
							if (m.matches()) {
								segName = getsegName(segmentPath[j], resourceResolver);
							}
						}
						log.debug("segName in finalseg null else {}", segName);
					}
				} else {
					for (int j = 0; j < segmentPath.length; j++) {
						String hexCheck = segmentPath[j].substring(segmentPath[j].lastIndexOf("/") + 1);
						Pattern p = Pattern.compile("[0-9a-fA-F]+");
						Matcher m = p.matcher(hexCheck.trim());
						if (m.matches()) {
							segName = getsegName(segmentPath[j], resourceResolver);
						}
					}
					log.debug("segName in location null else {}", segName);
				}
				response.setContentType("application/json");
				final PrintWriter out = response.getWriter();
				ObjectMapper mapper = new ObjectMapper();
				ObjectNode rootNode = mapper.createObjectNode();
				((ObjectNode) rootNode).put("segName", segName);
				out.write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rootNode));
				out.flush();

			} catch (Exception e) {
				log.error("Error in do get {}", e.getMessage());
				log.debug("Error in do get {}", e.getMessage());
			} finally {
				session.logout();
				resourceResolver.close();
			}

		}

	}

	private String getsegName(String finalSeg, ResourceResolver resourceResolver) {
		String nameSeg = "";
		Node segNode = resourceResolver.getResource(finalSeg + "/jcr:content").adaptTo(Node.class);
		try {
			if (segNode.hasProperty("segmentName")) {
				String name = segNode.getProperty("segmentName").getString();
				Pattern p = Pattern.compile("[0-9a-fA-F]+");
				Matcher m = p.matcher(name.trim());
				if (m.matches()) {
					name = name.replaceAll("^(00)+", "");
					byte[] bytes = DatatypeConverter.parseHexBinary(name);
					nameSeg = new String(bytes, "UTF-8");
				} else {
					nameSeg = name;
				}
			}
		} catch (RepositoryException e) {
			log.error("Error in getsegName RepositoryException {}", e.getMessage());
			log.debug("Error in getsegName RepositoryException {}", e.getMessage());
		} catch (UnsupportedEncodingException e) {
			log.error("Error in getsegName UnsupportedEncodingException {}", e.getMessage());
			log.debug("Error in getsegName UnsupportedEncodingException {}", e.getMessage());
		}

		return nameSeg;
	}

	private String getCampainpath(String[] segmentPath, ResourceResolver resourceResolver, Session session) {

		String pathSeg = "";
		Resource resResource = resourceResolver.getResource(CONTEXTHUB_PATH);
		String jcrContent = "jcr:content";
		int count = 0;
		for (int i = 0; i < segmentPath.length; i++) {
			Iterator<Resource> childList = resResource.listChildren();
			while (childList.hasNext()) {
				Resource activityChild = childList.next();
				if (!jcrContent.equalsIgnoreCase(activityChild.getName())) {
					Iterator<Resource> childs = activityChild.listChildren();
					while (childs.hasNext()) {
						Resource resChild = childs.next();
						if (!jcrContent.equalsIgnoreCase(resChild.getName())) {
							Resource propertyResource = resChild.getChild(jcrContent);
							childProperties = propertyResource.adaptTo(ValueMap.class);
							String segment = childProperties.get("cq:segments", String.class);
							if (segment.equalsIgnoreCase(segmentPath[i])) {
								final Map<String, String> maps = new HashMap<String, String>();
								maps.put("path", propertyResource.getPath().split("/jcr:content")[0]);
								maps.put("nodename", "jcr:content");
								maps.put("property", "location");
								maps.put("property.value", location);
								maps.put("property.operation", "equals");
								query = queryBuilder.createQuery(PredicateGroup.create(maps), session);
								SearchResult results = query.getResult();
								String contentPath = null;
								for (final Hit hits : results.getHits()) {
									try {
										contentPath = hits.getPath();
									} catch (RepositoryException e) {
										log.error("Error in getCampainpath RepositoryException {}", e.getMessage());
										log.debug("Error in getCampainpath RepositoryException {}"+ e.getMessage());

									}
								}
								if (contentPath != null) {
									pathSeg = segmentPath[i];
									count++;
									break;
								}

							}
						}
					}
					if (count > 0) {
						break;
					}
				}
			}
			if (count > 0) {
				break;
			}
		}
		return pathSeg;

	}

}
