package personalizationdemo.core.models;

import javax.jcr.Node;
import javax.jcr.Session;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import personalizationdemo.core.bean.FeatureComponentBean;
import personalizationdemo.core.services.GetResolver;
import personalizationdemo.core.utils.PEDemoConstants;
import personalizationdemo.core.utils.UtilityHelper;

public class FeatureComponent extends WCMUsePojo {
	FeatureComponentBean featureComponentBean = null;
	boolean isConditionMet = false;

	private static final Logger logger = LoggerFactory.getLogger(FeatureComponent.class);

	@Override
	public void activate() {

		logger.debug("FeatureComponent activate");
		
		Session session =null;
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		ResourceResolver resourceResolver=null;
		
		String sparkID = "";
		String type = "";
		String dynamicPageFieldType = "";
		String dynamicPageFieldValue = "";
		String preHeader = "";
		String header = "";
		String teaser = "";
		String ctaButtonType = "";
		String buttonLabel = "";
		String ctaUrl = "";
		String fieldType = "";
		String fieldValue = "";
		String openInNewWindow = "";
		String imagePlacement = "";
		String sparkImage = "";
		String isCtaRequired = "";
		String dynamicUrlCTA = "";
		String sparkMobImage = "";
		String hideContent = "";

		try {
			featureComponentBean = new FeatureComponentBean();
			resourceResolver = resolverInterface.getResolver();
			session = resourceResolver.adaptTo(Session.class);
			sparkID = UtilityHelper.getSparkId(getRequest());
			Node masterjsonnode = session.getNode(PEDemoConstants.masterDynamicPath);
			Asset asset = null;
			asset = resourceResolver.getResource(masterjsonnode.getPath()).adaptTo(Asset.class);
			logger.debug("asset path {}", asset.getPath());

			type = getProperties().get("featureType", "");
			
			logger.debug("type of feature component", type);
			
			if (!"".equals(type) && "static".equals(type)) {
				hideContent = getProperties().get("hideContent", "");
				preHeader = getProperties().get("preHeader", "");
				header = getProperties().get("header", "");
				teaser = getProperties().get("teaser", "");
				ctaButtonType = getProperties().get("buttonCTA", "");
				buttonLabel = getProperties().get("textCTA", "");
				ctaUrl = getProperties().get("urlCTA", "");
				if (sparkID != null && ctaUrl != null && ctaUrl != "" && ctaUrl.contains(PEDemoConstants.PEDEMO_CONTENT_PREFIX)) {
					if(ctaUrl.contains(".html"))
						ctaUrl = ctaUrl + "/" + sparkID;
					else
						ctaUrl = ctaUrl + ".html/" + sparkID;					
				}
				fieldType = getProperties().get("fieldType", "");
				fieldValue = getProperties().get("fieldValue", "");
				openInNewWindow = getProperties().get("openInNewWindow", "");
				imagePlacement = getProperties().get("imagePlacement", "");
				sparkImage = getProperties().get("sparkImage", "");
				sparkMobImage = getProperties().get("sparkMobImage", "");
				isCtaRequired = getProperties().get("ctaButtonRequired", "");

				logger.debug("dialog values: Preheader " + preHeader + " header " + header + " teaser " + teaser
						+ " ctabtntype " + ctaButtonType + " btn label " + buttonLabel + " ctaUrl " + ctaUrl
						+ " fieldtype " + fieldType + " fieldValye " + fieldValue + " openInNewWindow "
						+ openInNewWindow + " imageplacement " + imagePlacement + " img " + sparkImage);
				if (null != ctaUrl && !"".equals(ctaUrl) && !ctaUrl.startsWith("/content")) {
					if (!(ctaUrl.startsWith("http") || ctaUrl.startsWith("https")))
						ctaUrl = "https://" + ctaUrl;
				}
				dynamicUrlCTA = UtilityHelper.getFieldValueCTALink(asset, sparkID, fieldType, fieldValue);
				logger.debug("dynamic url cta {}", dynamicUrlCTA);
			} else if (!"".equals(type) && "dynamic".equals(type)) {
				dynamicPageFieldType = getProperties().get("pagefieldType", "");
				dynamicPageFieldValue = getProperties().get("pagefieldValue", "");

				isConditionMet = UtilityHelper.dynamicFeatureComponentConditionCheck(sparkID, dynamicPageFieldType,
						dynamicPageFieldValue, resourceResolver, session, getRequest());

				if (isConditionMet) {
					hideContent = getProperties().get("hideContentMet", "");
					preHeader = getProperties().get("preHeaderMet", "");
					header = getProperties().get("headerMet", "");
					teaser = getProperties().get("teaserMet", "");
					ctaButtonType = getProperties().get("buttonCTAMet", "");
					buttonLabel = getProperties().get("textCTAMet", "");
					ctaUrl = getProperties().get("urlCTAMet", "");
					if (sparkID != null && ctaUrl != null && ctaUrl != "" && ctaUrl.contains(PEDemoConstants.PEDEMO_CONTENT_PREFIX)) {
						if(ctaUrl.contains(".html"))
							ctaUrl = ctaUrl + "/" + sparkID;
						else
							ctaUrl = ctaUrl + ".html/" + sparkID;
					}
					fieldType = getProperties().get("fieldTypeMet", "");
					fieldValue = getProperties().get("fieldValueMet", "");
					openInNewWindow = getProperties().get("openInNewWindowMet", "");
					imagePlacement = getProperties().get("imagePlacementMet", "");
					sparkImage = getProperties().get("sparkImageMet", "");
					sparkMobImage = getProperties().get("sparkMobImageMet", "");
					isCtaRequired = getProperties().get("ctaButtonRequiredMet", "");

					logger.debug("dialog values: Preheader " + preHeader + " header " + header + " teaser " + teaser
							+ " ctabtntype " + ctaButtonType + " btn label " + buttonLabel + " ctaUrl " + ctaUrl
							+ " fieldtype " + fieldType + " fieldValye " + fieldValue + " openInNewWindow "
							+ openInNewWindow + " imageplacement " + imagePlacement + " img " + sparkImage);
					if (null != ctaUrl && !"".equals(ctaUrl) && !ctaUrl.startsWith("/content")) {
						if (!(ctaUrl.startsWith("http") || ctaUrl.startsWith("https")))
							ctaUrl = "https://" + ctaUrl;
					}
					dynamicUrlCTA = UtilityHelper.getFieldValueCTALink(asset, sparkID, fieldType, fieldValue);
					logger.debug("dynamic url cta {}", dynamicUrlCTA);
				} else {
					hideContent = getProperties().get("hideContentNotMet", "");
					preHeader = getProperties().get("preHeaderNotMet", "");
					header = getProperties().get("headerNotMet", "");
					teaser = getProperties().get("teaserNotMet", "");
					ctaButtonType = getProperties().get("buttonCTANotMet", "");
					buttonLabel = getProperties().get("textCTANotMet", "");
					ctaUrl = getProperties().get("urlCTANotMet", "");
					if (sparkID != null && ctaUrl != null && ctaUrl != "" && ctaUrl.contains(PEDemoConstants.PEDEMO_CONTENT_PREFIX)) {
						if(ctaUrl.contains(".html"))
							ctaUrl = ctaUrl + "/" + sparkID;
						else
							ctaUrl = ctaUrl + ".html/" + sparkID;
					}
					fieldType = getProperties().get("fieldTypeNotMet", "");
					fieldValue = getProperties().get("fieldValueNotMet", "");
					openInNewWindow = getProperties().get("openInNewWindowNotMet", "");
					imagePlacement = getProperties().get("imagePlacementNotMet", "");
					sparkImage = getProperties().get("sparkImageNotMet", "");
					sparkMobImage = getProperties().get("sparkMobImageNotMet", "");
					isCtaRequired = getProperties().get("ctaButtonRequiredNotMet", "");

					logger.debug("dialog values: Preheader " + preHeader + " header " + header + " teaser " + teaser
							+ " ctabtntype " + ctaButtonType + " btn label " + buttonLabel + " ctaUrl " + ctaUrl
							+ " fieldtype " + fieldType + " fieldValye " + fieldValue + " openInNewWindow "
							+ openInNewWindow + " imageplacement " + imagePlacement + " img " + sparkImage);
					if (null != ctaUrl && !"".equals(ctaUrl) && !ctaUrl.startsWith("/content")) {
						if (!(ctaUrl.startsWith("http") || ctaUrl.startsWith("https")))
							ctaUrl = "https://" + ctaUrl;
					}
					dynamicUrlCTA = UtilityHelper.getFieldValueCTALink(asset, sparkID, fieldType, fieldValue);
					logger.debug("dynamic url cta {}", dynamicUrlCTA);
				}

			}

			featureComponentBean.setHideContent(hideContent);
			featureComponentBean.setPreHeader(preHeader);
			featureComponentBean.setHeader(header);
			featureComponentBean.setTeaser(teaser);
			featureComponentBean.setCtaUrl(ctaUrl);
			featureComponentBean.setCtaBtnType(ctaButtonType);
			featureComponentBean.setButtonLabel(buttonLabel);
			featureComponentBean.setNewWindow(openInNewWindow);
			featureComponentBean.setImagePlacement(imagePlacement);
			featureComponentBean.setSparkImage(sparkImage);
			featureComponentBean.setSparkMobImage(sparkMobImage);
			featureComponentBean.setFieldType(fieldType);
			featureComponentBean.setFieldValue(fieldValue);
			featureComponentBean.setIsCtaRequired(isCtaRequired);
			featureComponentBean.setDynamicUrlCTA(dynamicUrlCTA);

		} catch (Exception e) {
			logger.debug("Exception in FeatureComponent {}", e.getMessage());
			logger.error("Exception in FeatureComponent {}", e.getMessage());
		}
		finally {
			session.logout();
			resourceResolver.close();
		}

	}

	public FeatureComponentBean getFeatureComponentBean() {
		return this.featureComponentBean;
	}

	public boolean isConditionMet() {
		return isConditionMet;
	}

}