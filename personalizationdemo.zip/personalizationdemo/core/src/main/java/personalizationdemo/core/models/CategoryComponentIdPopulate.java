package personalizationdemo.core.models;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.common.ValueMapDecorator;
import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;

import personalizationdemo.core.services.GetResolver;

public class CategoryComponentIdPopulate extends WCMUsePojo{

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	ResourceResolver resolver=null;
	@Override
	public void activate(){
		GetResolver resolverInterface = getSlingScriptHelper().getService(GetResolver.class); 
		
		try{
			log.debug("Inside datasource of categoryid field from category component");
			
			String currentPagePath = "";
			String categoryString = "";
			log.debug("Dialog Request Path: "+getRequest().getRequestURI());
			
			resolver = resolverInterface.getResolver();
			String requestPath = getRequest().getRequestURI();
			
			if(null != requestPath && !"".equals(requestPath)){
				String[] firstSplitRequestPath = requestPath.split("/_cq_dialog.html");
				String[] secondSplitRequestPath = firstSplitRequestPath[1].split("/jcr:content");
				currentPagePath = secondSplitRequestPath[0];
			}
			log.debug("Current Page Path: "+currentPagePath);
			
			if(null != currentPagePath && !"".equals(currentPagePath)){
				String[] splitCategoryId = currentPagePath.split("/");
				int lengthsplitCategoryId = splitCategoryId.length;
				categoryString = splitCategoryId[lengthsplitCategoryId - 1];
			}
			log.debug("Category String: "+categoryString);
			if(null != categoryString && categoryString.length() > 0){
				if(categoryString.contains("-")){
					String[] categoryStringArr = categoryString.split("-");
					categoryString = categoryStringArr[0];
				}
			}
			log.debug("Category String Updated: "+categoryString);
			
			Map<String,String> categoryIdMap = new HashMap<String,String>();
			categoryIdMap.put(categoryString, categoryString.substring(0, 1).toUpperCase() + categoryString.substring(1));

			@SuppressWarnings("unchecked")
			DataSource ds = new SimpleDataSource(new TransformIterator(categoryIdMap.keySet().iterator(), new Transformer() {
				public Object transform(Object o) {
					String categoryId = (String) o;
					ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
					vm.put("value", categoryId);
					vm.put("text", categoryIdMap.get(categoryId));
					return new ValueMapResource(resolver, new ResourceMetadata(), "nt:unstructured", vm);
				}

			}));
			this.getRequest().setAttribute(DataSource.class.getName(), ds);
			
		}catch(Exception e){
			log.debug("Exception logged in --CategoryComponentIdPopulate--: "+e);
		}finally {
			resolver.close();
			
		}
	}
}
