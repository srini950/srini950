package personalizationdemo.core.services.impl;

import java.util.ArrayList;
import java.util.Iterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import personalizationdemo.core.services.GetLoggedInUser;

@Component(service=GetLoggedInUser.class)
public class GetLoggedInUserImpl implements GetLoggedInUser {
	private final Logger LOG = LoggerFactory.getLogger(GetLoggedInUserImpl.class);
	@Override
	public String getUserId(ResourceResolver resolver) {
		Session session = resolver.adaptTo(Session.class);
		String userID = session.getUserID();
		return userID;
	}

	@Override
	public String getUserName(ResourceResolver resolver)throws Exception {
		UserManager userManager = resolver.adaptTo(UserManager.class);
		Session session = resolver.adaptTo(Session.class);
		String userName = null;
		try {
			Authorizable auth = userManager.getAuthorizable(session.getUserID());
			userName = auth.getPrincipal().getName();
		} catch (Exception e) {
			LOG.error("exception in getUserName {}", e.getMessage());
			LOG.debug("Exception in getUserName {}", e.getMessage());
			throw e;
			
		}
		return userName;
	}

	@Override
	public ArrayList<String> getUserGroup(ResourceResolver resolver)throws Exception {
		UserManager userManager = resolver.adaptTo(UserManager.class);
		Session session = resolver.adaptTo(Session.class);
		ArrayList<String> userGroupInfo= new ArrayList<String>();
		try {
			Authorizable auth = userManager.getAuthorizable(session.getUserID());
			Iterator<Group> itr = auth.memberOf();			
			while(itr.hasNext()) {	
				userGroupInfo.add(itr.next().getID().toString());				
			}
		} catch (RepositoryException e) {
			LOG.error("exception in getUserGroup {}", e.getMessage());
			LOG.debug("Exception in getUserGroup {}", e.getMessage());
			throw e;
		}
		
		
		return userGroupInfo;
	}

}
