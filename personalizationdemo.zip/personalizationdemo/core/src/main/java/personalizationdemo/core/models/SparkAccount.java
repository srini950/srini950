package personalizationdemo.core.models;

public class SparkAccount {

}
