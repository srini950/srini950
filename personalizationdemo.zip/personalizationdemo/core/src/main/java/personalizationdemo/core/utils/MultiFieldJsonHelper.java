package personalizationdemo.core.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MultiFieldJsonHelper extends WCMUsePojo {
	private String[] json;
	private static final Logger LOG = LoggerFactory.getLogger(MultiFieldJsonHelper.class);
	@Override
	public void activate() throws Exception {
		String resPath = get("resPath", String.class);
		String prop = get("prop", String.class);
		if (resPath != null && prop != null) {
			Resource res = getResourceResolver().getResource(resPath);
			ValueMap vm = res.getValueMap();
			json = vm.get(prop, String[].class);
		}
	}
	public List<Map<String, String>> getValues() {
		List<Map<String, String>> results = new ArrayList<Map<String, String>>();
		if (json != null) {
			for (String value : json) {
				Map<String, String> column = parseItem(value);
				if (column != null) {
					results.add(column);
				}
			}
		}
		return results;
	}
	private Map<String, String> parseItem(String jsonStr) {
		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> columnMap = new HashMap<>();
		try {
			columnMap = mapper.readValue(jsonStr, new TypeReference<Map<String, String>>(){});
			return columnMap;
		} catch (Exception e) {
			LOG.debug("JSONException occured {}", e.getMessage());
			LOG.error("JSONException occured {}", e.getMessage());
		}
		return null;
	}
}