package personalizationdemo.core.bean;

import java.util.List;

public class FooterComponentBean {
	
	private String footerComponentPath;
	private int currentYear;
	private List<FooterComponentLinkBean> linkList = null;

	public String getFooterComponentPath() {
		return footerComponentPath;
	}

	public void setFooterComponentPath(String footerComponentPath) {
		this.footerComponentPath = footerComponentPath;
	}

	public int getCurrentYear() {
		return currentYear;
	}

	public void setCurrentYear(int currentYear) {
		this.currentYear = currentYear;
	}

	public List<FooterComponentLinkBean> getLinkList() {
		return linkList;
	}

	public void setLinkList(List<FooterComponentLinkBean> linkList) {
		this.linkList = linkList;
	}
	
}
