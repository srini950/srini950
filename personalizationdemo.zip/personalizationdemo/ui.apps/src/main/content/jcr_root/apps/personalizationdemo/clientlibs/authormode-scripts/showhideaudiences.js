(function ($, $document) {
if(CQ.shared.HTTP.getPath().indexOf('/content/pedemo/') !== -1)
{
 var users = [];
 var userGroup="";
 var jsonSegmentdata="";
 let segmentPath=[];
 var segmentList="";
 var segmentCheck;
 getUserValue();


var myvar = '<div class="">'+
'  <span class="audience-searcher-placeholder"><span class="searcher coral-DecoratedTextfield">'+
'  <coral-icon icon="search" size="XS" class="coral-DecoratedTextfield-icon coral-Icon coral-Icon--search coral-Icon--sizeXS" role="img" aria-label="search"></coral-icon>'+
'  <input type="text" class="coral-DecoratedTextfield-input coral-Textfield search-input search-input-text" placeholder="Search" aria-invalid="false">'+
'</span></span>'+
'</div></br>'+
'<ul class="list audience-picker-list-header">'+
'   <li class="header">'+
'      <div class="row fixed ">'+
'         <div class="cell middle type">Account Name</div>'+
'         <div class="cell middle name">ID</div>'+
'      </div>'+
'   </li>'+
'</ul>'+
'<ul class="list audience-picker-list1" style="max-height: 370px;overflow: auto;">'+segmentList+'</ul>';


    var sparkListdialog = new Coral.Dialog().set({
        id: 'segment-list',
        header: {
            innerHTML: 'This Segment has below Accounts'
        },
        content: {
            innerHTML: myvar
        },
        footer: {
            innerHTML: '<button is="coral-button" variant="primary" coral-close>Ok</button>'
        },
  		closable: "on"
    });
	document.body.appendChild(sparkListdialog);
	
    var duplicateItemdialog = new Coral.Dialog().set({
            id: 'duplicatesDialog',
            header: {
              innerHTML: 'Duplicate ID'
            },
            content: {
                innerHTML: '<div style="margin:30px;font-size: 18px;font-weight: 300;line-height: 3ex;">This Spark account already present in <br><span id="activity"></span></div>'
            },
            footer: {
              innerHTML: '<button is="coral-button" variant="primary" coral-close>Ok</button>'
            }
          });
        document.body.appendChild(duplicateItemdialog);
    
    var duplicatedialog = document.querySelector('#duplicatesDialog');
        duplicatedialog.on('coral-overlay:beforeclose', function(event) {
    		$('.add-experience-cancel').trigger('click');

         });

       var audienceList = document.querySelector('#segment-list');
        audienceList.on('coral-overlay:beforeclose', function(event) {
    		if(typeof segmentCheck !== 'undefined'){
                    var duplicatedialog = document.querySelector('#duplicatesDialog');
                        duplicatedialog.show();
                        $('#activity').html(segmentCheck);
            
                };

         });

$(document).on("click", ".audienceListRow", function (e) {
	var datavalue = $(this).find('input:checkbox').val();
   		segmentCheck =	checkSegments(datavalue);
        $.getJSON(datavalue+"/jcr:content.2.json").done(function(data){
            jsonSegmentdata = jQuery.parseJSON(JSON.stringify(data));

            if(jsonSegmentdata.traits.orpar !== undefined){
                	var userId="";
                    var url = '/content/pedemo.segmentList.json';
                       $.ajax({
                          url: url,
                          data:{ 'segmentPath' : datavalue },
                          success: function (result) {                                          
                                        jsonSegmentdata = jQuery.parseJSON(JSON.stringify(result));
                              			searchText = "";
                              			createAccountList(searchText);
                              			var sparkListdialog = document.querySelector('#segment-list');
                                        sparkListdialog.show();
                                        $(".search-input-text").val("");
                                        $(".audience-picker-list1").html(segmentList);
                           },
                           error: function(){
                                            console.log("error in ajax call to get segment List servlet");
                           }
                      });


            }else if(typeof segmentCheck !== 'undefined'){
                    var duplicatedialog = document.querySelector('#duplicatesDialog');
                        duplicatedialog.show();
                        $('#activity').html(segmentCheck);
            
                };
 		});
 });

    function createAccountList(searchText){
				segmentList = "";
                $.each(JSON.parse(jsonSegmentdata), function(value,key) {
                    if(searchText.trim() != "") {
                    	if((key.toLowerCase().indexOf(searchText.toLowerCase()) !== -1)||(value.toLowerCase().indexOf(searchText.toLowerCase()) !== -1)){
						segmentList += '   <li class="listItem">'+
                                        '      <div class="row fixed ">'+
                                        '         <div class="cell middle type">'+value+'</div>'+
                                        '         <div class="cell middle name ellipsis-text" title="'+value+'">'+key+'</div>'+
                                        '      </div>'+
                                        '   </li>';
                        }
                    }else{

							segmentList += '   <li class="listItem">'+
                                        '      <div class="row fixed ">'+
                                        '         <div class="cell middle type">'+value+'</div>'+
                                        '         <div class="cell middle name ellipsis-text" title="'+value+'">'+key+'</div>'+
                                        '      </div>'+
                                        '   </li>';
                    }
                    });


    }

    // check segment is not authored in contexhub activitys
    function checkSegments(selectedSegment){
        		var segmnt = selectedSegment;
        		var segmentPresent;
                           $.ajax({
                                    url: "/content/campaigns/pedemo-experiences/master.3.json",
                                    async: false,
                                    success: function (result) {                                        
                                    if (result!="" && result!=undefined) {		                                                    
                                        var selectedSegment =JSON.parse(JSON.stringify(result));
                                        var activity;
                                        $.each(result, function(key, value){
                                            if(key != "jcr:content" && key != "jcr:created" && key != "jcr:createdBy" && key != "jcr:mixinTypes" && key != "jcr:primaryType"){
                                            $.each(value, function(key, value){
                                                if(key == "jcr:content"){
                                                    $.each(value, function(key, value){
                                                        if(key == "jcr:title"){
                                                            activity = value;
                                                        }
                                                    });
                                                }
                                                if(key != "jcr:content" && key != "jcr:created" && key != "jcr:createdBy" && key != "jcr:mixinTypes" && key != "jcr:primaryType"){
                                                    $.each(value, function(key, value){
                                                        if(key == "jcr:content"){
                                                            $.each(value, function(key, value){
                                                                if(key == "cq:segments" && value.indexOf(segmnt) != -1){
                                                                    	return segmentPresent = activity;
                                                                }
                                                            });

                                                        }
                                                    })
                                                }

                                            	});
                                            }
                                        	});

                                        }
                                     },
                                    error: function(){
                                       console.log("error in ajax call to activity json");
                                     }
                    
                                  });

        return segmentPresent;
    }
    $(document).on('keyup','.search-input-text',function(e){
        var searchText = $(this).val();
        createAccountList(searchText);
        $(".audience-picker-list1").html(segmentList);
    });

    $(document).on("click",".targeting-wizard-start",function() {
       	switchFirstSegment();
        onLoad();
    });


     $(document).on("click", ".add-experience", function (e) {
			var oldList = $('#ExperienceRailContainerXT .rail-rows-container').text();
        	var listItemCheck = setInterval(function() 
                  { 
                      if(oldList != $('#ExperienceRailContainerXT .rail-rows-container').text()){
						  switchFirstSegment();
        				  onLoad();
                          oldList = $('#ExperienceRailContainerXT .rail-rows-container').text();
                          clearInterval(listItemCheck);
                      }
                  }, 1000);
        });

    $(document).on('keyup','.experience-title-input',function(e){
        if(e.which == 13){
         switchFirstSegment();
         onLoad();
        }
    });


    function getUserValue(){
	var userId="";
    var url = '/content/pedemo.pedemohideshowsegment.json';
       $.getJSON(url, function(data) {
            let accArray=[];           
            let keysArray = Object.keys(data);
            for(var i=0; i<keysArray.length; i++){
                if(data[keysArray[i]].segmentTitle != "undefined"){
                	users.push(data[keysArray[i]].segmentTitle);
                }if(data[keysArray[i]].userGroup != "undefined"){
						userGroup = data[keysArray[i]].userGroup;
                }
            }
       });
   }

    // Adding action on layer  
    $document.on('cq-layer-activated', refreshPage);  

    function refreshPage(ev) {  
        try {  
            var iframe = document.getElementById('ContentFrame');  
            var innerDoc = iframe.contentDocument || iframe.contentWindow.document;  
            if ((ev.prevLayer === "Preview" && ev.layer === "Edit") || (ev.prevLayer === "Edit" && ev.layer === "Preview")
            || (ev.prevLayer === "Preview" && ev.layer === "Targeting") || (ev.prevLayer === "Targeting" && ev.layer === "Preview")) {  
        	 	refreshContextHub();
                window.location.reload();
            } 

        } catch (e) {  
            console.log("Error occurred while refreshing the page");  
        }  
    }  

    function refreshContextHub(){
		 var corpstore = ContextHub.getStore("userprofile");
				corpstore.loadProfile("Your Company",0,false);

   }
    function switchFirstSegment(){
		var camAct=$("#CampaignSelector > input:hidden").val();
        var finalCamActurl=camAct+'/jcr:content.experiences.json';
        $.ajax({
                url: finalCamActurl,
             	async: false,
               	success: function (result) {                                          
                if (result!="" && result!=undefined) {		                                                    
               		segmentPath=Object.values(JSON.parse(result));
                 	}
                 },
            	error: function(){
                   console.log("error in ajax call to getuniqueid servlet");
                 }

              });
           }
    function onLoad(){
        var doc = $('#ExperienceRailContainerXT');
         $('#ExperienceRailContainerXT .rail-rows-container').each(function(i){
        	 var firstUserSeg=0;
        	 if(users[0] != "all"){
        		 $(this).children('.experience-row').each(function(i){
        			 var title=$(this).attr("title");
             		 var count=0;
             		 for (var j=0; j< users.length; j++){
             			 if(title.indexOf(users[j]) > -1){
             				 count=1;
                             break;
                           }
             		  }
             		 if(count==0){
             			$(this).hide();
             		 }else if(count==1 && firstUserSeg==0){
             			var finalSegpath=segmentPath[i-1];
             			CQ.TargetedContentManager.switchExperience(finalSegpath,undefined, undefined);
             			TargetingUI.MultiSiteTargeting.showExperiencesListLocalOfferMarkers();
             			firstUserSeg =1;
             			}                        
             		});
             	}
         });
    }
}else{
   $(document).on("click",".targeting-wizard-start",function() {
		var camAct=$("#BrandSelector > input:hidden").val();
       	if(camAct.indexOf("/content/campaigns/pedemo-experiences")!= -1){
			var doc = $('#ExperienceRailContainerXT');
        	$('#ExperienceRailContainerXT .rail-rows-container').each(function(i){
        		 $(this).children('.experience-row').each(function(i){
                   	$(this).hide();
             		});         
            });
       	}
    });
}

}(jQuery, jQuery(document)));
