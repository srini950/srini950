(function() {
	$(document).on("dialog-ready", function() {
	
	   if(($("#ctaButtonRequired").is(":checked"))){
	        $(".ctaButtonsGroup").show();
          	triggerHeroEvent();
          $("input[name*='ctaButtonRequired@Delete']").val('true');
     }else{
		$(".ctaButtonsGroup").hide();
         $("input[name*='ctaButtonRequired@Delete']").val('false');

     }

	});

	$(document).on("click","#ctaButtonRequired",function(){
		if ($(this).prop('checked'))
    	{
       	 	$(".ctaButtonsGroup").show();
            $("input[name*='ctaButtonRequired@Delete']").val('true');
         	triggerHeroEvent();
    	}else{
        	$(".buttonCTARadio").attr("checked",false);
        	$(".ctaButtonsGroup").hide();
            $("input[name*='ctaButtonRequired@Delete']").val('false');
    	}
	});
    $(document).on("click","#herostatic",function(){
    		$("#herofieldtype").parent().hide();
    		$("#herofieldvalue").parent().hide();
    		$("#heroctaname").parent().show();
    		$("#herourlcta").parent().show();
        $("input[name*='buttonCTA@Delete']").val('static');
	});
    $(document).on("click","#herodynamic",function(){
        	$("#heroctaname").parent().show();
    		$("#herourlcta").parent().hide();
			$("#herofieldtype").parent().show();
    		$("#herofieldvalue").parent().show();
        $("input[name*='buttonCTA@Delete']").val('dynamic');
	});

    function triggerHeroEvent(){
    	if(($("#herostatic").is(":checked"))){
        	$("#herofieldtype").parent().hide();
        	$("#herofieldvalue").parent().hide();
        	$("#heroctaname").parent().show();
        	$("#herourlcta").parent().show();
            $("input[name*='buttonCTA@Delete']").val('static');
    	}else if(($("#herodynamic").is(":checked"))){
        	$("#heroctaname").parent().show();
        	$("#herourlcta").parent().hide();
			$("#herofieldtype").parent().show();
        	$("#herofieldvalue").parent().show();
            $("input[name*='buttonCTA@Delete']").val('dynamic');
    	}else{
			$("#heroctaname").parent().hide();
        	$("#herourlcta").parent().hide();
			$("#herofieldtype").parent().hide();
        	$("#herofieldvalue").parent().hide();
    	}
    }

})();