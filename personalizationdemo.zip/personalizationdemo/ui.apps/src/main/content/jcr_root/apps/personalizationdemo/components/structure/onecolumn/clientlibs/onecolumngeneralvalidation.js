(function(document, $) {
   "use strict";

     var SHORT_NAME_SELECTOR="shortname.validation";
     var GENERAL_DROPDOWN_FIELD="dropdownField.validation";
     var foundationReg = $(window).adaptTo("foundation-registry");

	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + SHORT_NAME_SELECTOR + "']",
       validate: function(el) {     
            var error_message = "Please select the short Name";
        	var catgoryIdVal=$("[name='./catCategoryId']").val();
        	var shortNameVal=$("input[name='./catShortName']").val();
        	if(catgoryIdVal!="" && catgoryIdVal!=undefined){
        		if(shortNameVal=="" || shortNameVal== undefined){
        			 return error_message; 
    			}
   			}
       }
   });
    foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + GENERAL_DROPDOWN_FIELD + "']",
       validate: function(el) {     
            var error_message = "Please select the Page Field Type";
        	var catgoryIdVal=$("[name='./catCategoryId']").val();
        	var pagefieldType=$("[name='./pagefieldType']").val();
        	if(catgoryIdVal!="" && catgoryIdVal!=undefined){
        		if(pagefieldType=="" || pagefieldType== undefined){
        			 return error_message;
    			}
   			}
       }
   });

 })(document,Granite.$);