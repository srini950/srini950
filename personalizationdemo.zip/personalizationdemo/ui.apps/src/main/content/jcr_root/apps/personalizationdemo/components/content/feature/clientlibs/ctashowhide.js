(function() {
	$(document).on("dialog-ready", function() {
		$(".coral-FixedColumn-column").css("min-height", "40rem");
        setTimeout(function(){ 
            					if($('#dialog-overflow').is(':visible')){
                                    		$(".cq-dialog-content").removeAttr("style")
                                    }
            					if($("[name = './featureType']").val() == 'static'){
                                    	triggerFeatureEvent("");
                                        ctaButtonRequiredInitalization("");
                                    }else{
                                        pagefieldValue();
                                        ctaButtonRequiredInitalization("Met");
            							triggerFeatureEvent("Met");
                                        ctaButtonRequiredInitalization("NotMet");
           				 				triggerFeatureEvent("NotMet");
                                    }
                           }, 1000);


    var featureType = $("[name = './featureType']").closest(".coral-Select");
    featureType.on('selected.select', function(event){
		if(event.selected == 'static'){
            ctaButtonRequiredInitalization("");
        }else{
            pagefieldValue();
  			ctaButtonRequiredInitalization("Met");
        	ctaButtonRequiredInitalization("NotMet");
        }
     });

	});

    var ctaButtonRequiredInitalization = function (cond){
        var id = "#ctaButtonRequired"+cond;
             if($(id).is(":checked")){
                    $(".ctaButtonsGroup"+cond).show();
                 	initialCtabuttonSet(cond);
                  $("input[name*='ctaButtonRequired"+cond+"@Delete']").val('true');
             }else{
                $(".ctaButtonsGroup"+cond).hide();
                 $("input[name*='ctaButtonRequired"+cond+"@Delete']").val('false');
             }

    }
    $(document).on("click",".coral-Tab",function(){
        if($(this).text() == 'DYNAMIC FEATURE (Condition met)'){
			ctaButtonRequiredInitalization("Met");
            triggerFeatureEvent("Met");
        }else{
            ctaButtonRequiredInitalization("NotMet");
            triggerFeatureEvent("NotMet");
        }

    });



    $(document).on("click","#ctaButtonRequired",function(){
			ctaButtonRequiredInitalization("");
	});
    $(document).on("click","#ctaButtonRequiredMet",function(){
			ctaButtonRequiredInitalization("Met");
	});
    $(document).on("click","#ctaButtonRequiredNotMet",function(){
			ctaButtonRequiredInitalization("NotMet");
	});



    var ctabuttonRadioInternalClick = function(condition, type){
		    $("#fieldtype"+condition).parent().hide();
    		$("#fieldvalue"+condition).parent().hide();
    		$("#buttonlabel"+condition).parent().show();
    		$("#ctaurl"+condition).parent().show();
        	$("#newwindow"+condition).parent().show;
        $("input[name*='buttonCTA"+condition+"@Delete']").val('static');
    }

    var ctabuttonRadioExternalClick = function(condition){
        	$("#buttonlabel"+condition).parent().show();
    		$("#ctaurl"+condition).parent().hide();
			$("#fieldtype"+condition).parent().show();
    		$("#fieldvalue"+condition).parent().show();
        	$("#newwindow"+condition).parent().show;
        $("input[name*='buttonCTA"+condition+"@Delete']").val('dynamic');
    }

    $(document).on("click","#internal",function(){
			ctabuttonRadioInternalClick("","static");
 	});
    $(document).on("click","#external",function(){
			ctabuttonRadioExternalClick("","static");
	});
     $(document).on("click","#internalMet",function(){
			ctabuttonRadioInternalClick("Met","dynamic");
 	});
    $(document).on("click","#externalMet",function(){
			ctabuttonRadioExternalClick("Met","dynamic");
	});
    $(document).on("click","#internalNotMet",function(){
			ctabuttonRadioInternalClick("NotMet","dynamic");
 	});
    $(document).on("click","#externalNotMet",function(){
			ctabuttonRadioExternalClick("NotMet","dynamic");
	});

	function triggerFeatureEvent(condition) {
		var imgPosType = $("[name='./imagePlacement"+condition+"']");

		if (!(imgPosType == null && imgPosType == 'undefined')) {
			var imgPosTypeVal = imgPosType.val();

			var checkImgPosType = function(imgPosTypeVal) {

				if (!imgPosTypeVal == 'undefined') {
					if (imgPosTypeVal.includes("left")
							|| imgPosTypeVal.includes("right")) {
						hidewidget(".preHeader");
					} else {
						showwidget(".preHeader");
					}
				}
			}

			checkImgPosType(imgPosTypeVal);
		}


	}
    var initialCtabuttonSet = function(condition){
		if (($("#internal"+condition).is(":checked"))) {
			$("#fieldtype"+condition).parent().hide();
            $("#fieldvalue"+condition).parent().hide();
			$("#buttonlabel"+condition).parent().show();
			$("#ctaurl"+condition).parent().show();
			$("#newwindow"+condition).parent().show();
            $("input[name*='buttonCTA"+condition+"@Delete']").val('static');
		} else if (($("#external"+condition).is(":checked"))) {
			$("#ctaurl"+condition).parent().hide();
			$("#buttonlabel"+condition).parent().show();
			$("#fieldtype"+condition).parent().show();
            $("#fieldvalue"+condition).parent().show();
			$("#newwindow"+condition).parent().show();
            $("input[name*='buttonCTA"+condition+"@Delete']").val('dynamic');
		} else {
			$("#ctaurl"+condition).parent().hide();
			$("#buttonlabel"+condition).parent().hide();
			$("#newwindow"+condition).parent().hide();
			$("#fieldtype"+condition).parent().hide();
            $("#fieldvalue"+condition).parent().hide();
		}

    }
	function hidewidget(classname) {
		$(classname).parent().addClass("hide");
		if ($(classname).parents('.coral-Form-fieldwrapper--singleline').length) {
			$(classname).parents('.coral-Form-fieldwrapper--singleline')
					.addClass("hide")
		}
		;
		if ($(classname).parents('.coral-Form-fieldwrapper').length) {
			$(classname).parents('.coral-Form-fieldwrapper').addClass("hide")
		}
	}
	;

	function showwidget(classname) {
		$(classname).parent().removeClass("hide");
		if ($(classname).parents('.coral-Form-fieldwrapper--singleline').length) {
			$(classname).parents('.coral-Form-fieldwrapper--singleline')
					.removeClass("hide")
		}
		;
		if ($(classname).parents('.coral-Form-fieldwrapper').length) {
			$(classname).parents('.coral-Form-fieldwrapper')
					.removeClass("hide")
		}
	}
	;

function pagefieldValue(){
	var FIELDTYPE = "./pagefieldType", FIELDVALUE = "./pagefieldValue";
	var dynamicData=[];
        var fieldtype =$("[name='" + FIELDTYPE + "']");
        var selectedFieldValue = $("[name='" + FIELDVALUE +"']");
		var fieldtype1 = $("[name='" + FIELDTYPE +"']").closest(".coral-Select");
        var fieldvalue = new CUI.Select({
            element: $("[name='" + FIELDVALUE +"']")
        });  
        var selectFieldValue=$("[name='" + FIELDVALUE +"']").closest(".coral-Select");
        if(_.isEmpty(fieldvalue) || _.isEmpty(fieldtype)){
            return;
        }                 
        fieldvalue._selectList.children().not("[role='option']").remove();

        function fillFieldValue(selectedType, selectedValue){
            $("[name='./pagefieldValue']").siblings("ul").empty();
            $("option[name='dynamic-text-value-page']").remove();
			var fieldNameArr=[];
            $.each(dynamicData, function(i, user) {
                if(user.categoryType == selectedType){
					fieldNameArr=user.detailID;
                }
                });

                for(var j=0; j<fieldNameArr.length; j++){
                var test2 = $("[name='./pagefieldValue']")[0]; 
                $("<option>").appendTo(test2).val(fieldNameArr[j].id).attr("name","dynamic-text-value-page").html(fieldNameArr[j].id+" - "+fieldNameArr[j].desc);
                }


            fieldvalue = new CUI.Select({
                element: $("[name='" + FIELDVALUE +"']").closest(".coral-Select")
            });

			if(!_.isEmpty(selectedValue)){                 
                fieldvalue.setValue(selectedValue);
            }else{
                if($("input[name*='pagefieldType@Delete']").val() !=''){
				$("input[name*='pagefieldValue@Delete']").val(fieldNameArr[0]);
                }
            }
        }

        fieldtype1.on('selected.select', function(event){
            fillFieldValue(event.selected);
        });

         $.getJSON("/content/dam/pedemo/masterjsondata/benefits-offers.json").done(function(data){
             if(_.isEmpty(data)){
                    return;
             }
             dynamicData=data;

            var $form = fieldvalue.$element.closest("form");
            $.getJSON($form.attr("action") + ".json").done(function(data){
                if(_.isEmpty(data)){
                    return;
                }
				fillFieldValue(fieldtype.val(), data.pagefieldValue);
            })

    	});

    }



})();