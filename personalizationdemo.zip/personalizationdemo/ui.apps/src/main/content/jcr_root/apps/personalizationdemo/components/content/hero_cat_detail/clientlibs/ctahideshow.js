(function() {
$(document).on("dialog-ready", function() {

     if(($("#ctaButtonRequired").is(":checked"))){
	        $(".ctaButtonsGroup").show();
          	triggerHeroCatDetailEvent();
          $("input[name*='ctaButtonRequired@Delete']").val('true');
     }else{
		$(".ctaButtonsGroup").hide();
         $("input[name*='ctaButtonRequired@Delete']").val('false');

     }

});

$(document).on("click","#ctaButtonRequired",function(){
	if ($(this).prop('checked')) {
        $(".ctaButtonsGroup").show();
         triggerHeroCatDetailEvent();
        $("input[name*='ctaButtonRequired@Delete']").val('true');
    }else{
        $(".buttonCTARadio").attr("checked",false);
        $(".ctaButtonsGroup").hide();
        $("input[name*='ctaButtonRequired@Delete']").val('false');
    }
});

	$(document).on("click","#catstatic",function(){
    		$("#herocatfieldtype").parent().hide();
    		$("#herocatfieldvalue").parent().hide();
    		$("#catctaname").parent().show();
    		$("#urlcatcta").parent().show();
        $("input[name*='buttonCTA@Delete']").val('static');
	});
    $(document).on("click","#catdynamic",function(){
        	$("#catctaname").parent().show();
    		$("#urlcatcta").parent().hide();
			$("#herocatfieldtype").parent().show();
    		$("#herocatfieldvalue").parent().show();
        $("input[name*='buttonCTA@Delete']").val('dynamic');
	});


    function triggerHeroCatDetailEvent(){
    	if(($("#catstatic").is(":checked"))){
        	$("#herocatfieldtype").parent().hide();
        	$("#herocatfieldvalue").parent().hide();
        	$("#catctaname").parent().show();
        	$("#urlcatcta").parent().show();
            $("input[name*='buttonCTA@Delete']").val('static');
    	}else if(($("#catdynamic").is(":checked"))){
        	$("#catctaname").parent().show();
        	$("#urlcatcta").parent().hide();
			$("#herocatfieldtype").parent().show();
        	$("#herocatfieldvalue").parent().show();
            $("input[name*='buttonCTA@Delete']").val('dynamic');
    	}else{
			$("#catctaname").parent().hide();
        	$("#urlcatcta").parent().hide();
			$("#herocatfieldtype").parent().hide();
        	$("#herocatfieldvalue").parent().hide();
    	}
  	}

})();