 $(window.document).on('click', '#createDCTSegmentButton', function() {
        var $form = $('#createDCTSegmentForm');
        $form.show();
        console.log("spark cqmethod "+$form.prop('method'));
        console.log("spark cq action "+$form.prop('action'));
        console.log("spark enctype "+$form.prop('enctype'));
    });
    
    
function onClose() {
    var dctDialog = document.getElementById("createDCTSegmentForm");
    if (dctDialog.style.display === "none") {
        dctDialog.style.display = "block";
    } else {
        dctDialog.style.display = "none";
    }
}


function validateForm() {
    var segTitle = document.forms["dctForm"]["segmentTitle"].value;
    if (segTitle == "") {
       $('#error-segmentTitle').show();
        return false;
    }
    else{
		$('#error-segmentTitle').hide();
    }

    var boost=document.forms["dctForm"]["boost"].value;
	if(boost =="")
    {
        $('#error-boost').show();
        return false;
    }
	 else{
		$('#error-boost').hide();
    }
    return true;

};


    $(window.document).on('click', '#dctBtnSubmit', function(e) {
        e.preventDefault();
        var form = $('#createDCTSegmentForm');
        console.log("form action "+form.attr('action'));
         var data = {};

	if(validateForm())
    {

                     // Make sure you use the 'name' field on the inputs you want to grab. 
                   form.find( '[name]' ).each( function( i , v ){
                      var input = $( this ), // resolves to current input element.
                          name = input.attr('name'),
                          value = input.val();
                       console.log("name "+name+ " Value "+value);
                      data[name] = value;
                   });


        $.ajax({
            type: form.prop('method'),
          	url: form.prop('action'),        
            contentType: form.prop('enctype'),
            data: form.serialize(),
            cache: false
        }).done(function(xhr) {
            console.log("1");
            $('coral-dialog').hide().remove();
                   form.hide();
            var successMsg = Granite.I18n.get('New segment created successfully.');

            if (xhr && xhr.responseJSON && xhr.responseJSON.response) {
                console.log("3");
                successMsg = xhr.responseJSON.response;
            }
            var dialog = new Coral.Dialog().set({
                variant: 'success',
                header: {
                    innerHTML: Granite.I18n.get('Success')
                },
                content: {
                    innerHTML: '<p>' + successMsg + '</p>'
                },
                footer: {
                    innerHTML: '<button is="coral-button" class="coral-Button" variant="primary" coral-close size="M">' + Granite.I18n.get('Ok') + '</button>'
                }
            });

            dialog.on('coral-overlay:close', function() {
                document.location.reload();
            });

            $('body').append(dialog);
            dialog.show();
        }).fail(function(xhr) {
            $('coral-dialog').hide().remove();
            var errorMsg = Granite.I18n.get('Failed to create new segment.');

            if (xhr && xhr.responseJSON && xhr.responseJSON.response) {
                errorMsg = xhr.responseJSON.response;
            }

            var dialog = new Coral.Dialog().set({
                variant: 'error',
                header: {
                    innerHTML: Granite.I18n.get('Error')
                },
                content: {
                    innerHTML: '<p>' + errorMsg + '</p>'
                },
                footer: {
                    innerHTML: '<button is="coral-button" class="coral-Button" variant="primary" coral-close size="M">' + Granite.I18n.get('Ok') + '</button>'
                }
            });

            $('body').append(dialog);
            dialog.show();
        });
     }

  }
);
