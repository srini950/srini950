(function(document, $) {
   "use strict";

    var IMAGE_SELECTOR="selectImage.validation";
    var HEADER_SELECTOR="header.validation";

    var FIELDTYPE_SELECTOR="dropdownField1.validation";
    var BTN_CTA_SELECTOR="btncta1.validation";
    var URL_CTA_SELECTOR="urlcta1.validation";
    var RADIO_GROUP ="radiogroup1.validation";
    var foundationReg = $(window).adaptTo("foundation-registry");

    var section_visible = "";

   	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + FIELDTYPE_SELECTOR + "']",
       validate: function(el) {
		section_visible = $("[name='./featureType']").val();
        if(section_visible == "static"){ 
        var error_message = "Select input FieldType";
        var error_message_sec="ReClick on FieldType"
       	var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
        var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
               	if(ctaButtonReqVal=='true')
                    {
                        if(buttonCTAVal=='dynamic'){
                            var fieldTypeVal=$("[name*='fieldType']").val();
        					var fieldValueVal=$("[name*='fieldValue']").val()
                            if(fieldTypeVal == ''){
                                console.log("select field type if " );	
                                return error_message;        
    						}if(fieldValueVal=='' || fieldValueVal==undefined){
								return error_message_sec;
    						}

                       }

                    }
       	}
 		}
   });

    foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + IMAGE_SELECTOR + "']",
       validate: function(el) {
          var error_message = "Select image for input box";
        section_visible = $("[name='./featureType']").val();
        if(section_visible =="static"){ 

        	if($("input[name='./sparkImage']").is(":visible")){
                var imageVal=$("input[name='./sparkImage']").val();
                if (imageVal == '' || typeof imageVal == undefined){
                            return error_message;
                    }
        	}
         }
       }
   });

    foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + HEADER_SELECTOR + "']",
       validate: function(el) { 
        section_visible = $("[name='./featureType']").val();
        if(section_visible =="static"){ 
           var error_message = "Provide header field details";
        	if($("input[name='./sparkImage']").is(":visible")){
                var headerVal=$("input[name='./header']").val();
                if (headerVal == '' || typeof headerVal == undefined){
                            return error_message;
                    }
        	}
                           }
                           }
   });

    foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + RADIO_GROUP + "']",
       validate: function(el) { 
        section_visible = $("[name='./featureType']").val();
        if(section_visible =="static"){ 
           var error_message = "Select the buttonCTA";
        	var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
        	if (ctaButtonReqVal=='true'){
        	var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
        console.log("radio group btnval "+buttonCTAVal);
       			if (buttonCTAVal=='' || buttonCTAVal==undefined){
						return error_message;
    			}
        	}
                           }}
   });
       foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + BTN_CTA_SELECTOR + "']",
       validate: function(el) {  
           section_visible = $("[name='./featureType']").val();
           if(section_visible =="static"){ 
           var error_message = "Provide CTA Button Title";
           var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
           var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
       		if (ctaButtonReqVal=='true'){
           		if (buttonCTAVal!='' && buttonCTAVal!=undefined){
           			var herobuttontext=$("input[name*='textCTA']");
        			var herobtnvalue=herobuttontext.val();
           			if(!(herobtnvalue!='' && herobtnvalue!=null)){
						return error_message;
       				}
                 }
             }
                              }
       }
   });
       foundationReg.register("foundation.validation.validator", {
           selector: "[data-validation='" + URL_CTA_SELECTOR + "']",
           validate: function(el) {  
           section_visible = $("[name='./featureType']").val();
           if(section_visible =="static"){ 
               var error_message = "Provide CTA URL";
               var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
               var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
           		if (ctaButtonReqVal=='true'){
               		if (buttonCTAVal=='static'){
               			var herourlctatext=$("input[name*='urlCTA']");
            			var herourlctavalue=herourlctatext.val();
           				var externalurl = false;
           				if(herourlctavalue.indexOf("http") > -1 || herourlctavalue.indexOf("www.") >-1){
							externalurl =true;
       					}
      		   			var internalurl=herourlctavalue.startsWith("/content");
               			if((!externalurl && !internalurl )|| herourlctavalue.length >= 350){
    						return error_message;
           				}
                        
                     }
                 }
}
           }
       });


 })(document,Granite.$);