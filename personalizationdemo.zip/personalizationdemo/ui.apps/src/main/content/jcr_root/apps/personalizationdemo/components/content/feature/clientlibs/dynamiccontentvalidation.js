(function(document, $) {
    "use strict";

    var IMAGE_SELECTOR = "selectImage";
    var HEADER_SELECTOR = "header";

    var PAGEFIELDTYPE = "pagefieldtype";
    var FIELDTYPE_SELECTOR = "dropdownField";
    var BTN_CTA_SELECTOR = "btncta";
    var URL_CTA_SELECTOR = "urlcta";
    var RADIO_GROUP = "radiogroup";
    var foundationReg = $(window).adaptTo("foundation-registry");

    var section_visible = "";

    dynamicsection("Met");
    dynamicsection("NotMet");

        foundationReg.register("foundation.validation.validator", {
            selector: "[data-validation='" + PAGEFIELDTYPE + ".validation']",
            validate: function(el) {
                var error_message = "Select Dynamic Catagory";
                section_visible = $("[name='./featureType']").val();
            	var pagefieldType = $("[name='./pagefieldType']").val();
                if (section_visible == "dynamic" && (pagefieldType == "" || typeof pagefieldType == undefined)) {

                        return error_message;
                }
            }
        })



    function dynamicsection(condition) {
        foundationReg.register("foundation.validation.validator", {
            selector: "[data-validation='" + FIELDTYPE_SELECTOR + condition + ".validation']",
            validate: function(el) {
                section_visible = $("[name='./featureType']").val();
                if (section_visible == "dynamic") {
                    var error_message = "Select input FieldType";
                    var error_message_sec = "ReClick on FieldType"
                    var ctaButtonReqVal = $("input[name*='ctaButtonRequired" + condition + "@Delete']").val();
                    var buttonCTAVal = $("input[name*='buttonCTA" + condition + "@Delete']").val();
                    if (ctaButtonReqVal == 'true') {
                        if (buttonCTAVal == 'dynamic') {
                            var fieldTypeVal = $("[name*='fieldType" + condition + "']").val();
                            var fieldValueVal = $("[name*='fieldValue" + condition + "']").val();
                            console.log("test " + fieldValueVal);
                            if (fieldTypeVal == '') {
                                return error_message;
                            }

                        }

                    }
                }
            }
        });

        foundationReg.register("foundation.validation.validator", {
            selector: "[data-validation='" + IMAGE_SELECTOR + condition + ".validation']",
            validate: function(el) {
                var error_message = "Select image for input box";
                section_visible = $("[name='./featureType']").val();
                if (section_visible == "dynamic") {

                    var imageVal = $("input[name='./sparkImage" + condition + "']").val();
                    if (imageVal == '' || typeof imageVal == undefined) {
                        return error_message;
                    }
                }
            }
        });

        foundationReg.register("foundation.validation.validator", {
            selector: "[data-validation='" + HEADER_SELECTOR + condition + ".validation']",
            validate: function(el) {
                section_visible = $("[name='./featureType']").val();
                if (section_visible == "dynamic") {
                    var error_message = "Provide header field details";
                    var headerVal = $("input[name='./header" + condition + "']").val();
                    if (headerVal == '' || typeof headerVal == undefined) {
                        return error_message;
                    }
                }
            }
        });

        foundationReg.register("foundation.validation.validator", {
            selector: "[data-validation='" + RADIO_GROUP + condition + ".validation']",
            validate: function(el) {
                section_visible = $("[name='./featureType']").val();
                if (section_visible == "dynamic") {
                    var error_message = "Select the buttonCTA";
                    var ctaButtonReqVal = $("input[name*='ctaButtonRequired" + condition + "@Delete']").val();
                    if (ctaButtonReqVal == 'true') {
                        var buttonCTAVal = $("input[name*='buttonCTA" + condition + "@Delete']").val();
                        console.log("radio group btnval " + buttonCTAVal);
                        if (buttonCTAVal == '' || buttonCTAVal == undefined) {
                            return error_message;
                        }
                    }
                }
            }
        });
        foundationReg.register("foundation.validation.validator", {
            selector: "[data-validation='" + BTN_CTA_SELECTOR + condition + ".validation']",
            validate: function(el) {
                section_visible = $("[name='./featureType']").val();
                if (section_visible == "dynamic") {
                    var error_message = "Provide CTA Button Title";
                    var ctaButtonReqVal = $("input[name*='ctaButtonRequired" + condition + "@Delete']").val();
                    var buttonCTAVal = $("input[name*='buttonCTA" + condition + "@Delete']").val();
                    if (ctaButtonReqVal == 'true') {
                        if (buttonCTAVal != '' && buttonCTAVal != undefined) {
                            var herobuttontext = $("input[name*='textCTA" + condition + "']");
                            var herobtnvalue = herobuttontext.val();
                            if (!(herobtnvalue != '' && herobtnvalue != null)) {
                                return error_message;
                            }
                        }
                    }
                }
            }
        });
        foundationReg.register("foundation.validation.validator", {
            selector: "[data-validation='" + URL_CTA_SELECTOR + condition + ".validation']",
            validate: function(el) {
                section_visible = $("[name='./featureType']").val();
                if (section_visible == "dynamic") {
                    var error_message = "Provide CTA URL";
                    var ctaButtonReqVal = $("input[name*='ctaButtonRequired" + condition + "@Delete']").val();
                    var buttonCTAVal = $("input[name*='buttonCTA" + condition + "@Delete']").val();
                    if (ctaButtonReqVal == 'true') {
                        if (buttonCTAVal == 'static') {
                            var herourlctatext = $("input[name*='urlCTA" + condition + "']");
                            var herourlctavalue = herourlctatext.val();
                            var externalurl = false;
                            if (herourlctavalue.indexOf("http") > -1 || herourlctavalue.indexOf("www.") > -1) {
                                externalurl = true;
                            }
                            var internalurl = herourlctavalue.startsWith("/content");
                            if ((!externalurl && !internalurl) || herourlctavalue.length >= 350) {
                                return error_message;
                            }

                        }
                    }
                }
            }
        });
    }

})(document, Granite.$);