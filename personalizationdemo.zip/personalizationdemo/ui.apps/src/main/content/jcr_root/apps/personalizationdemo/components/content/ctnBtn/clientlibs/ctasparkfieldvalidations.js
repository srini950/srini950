(function(document, $) {
   "use strict";
    var CTA_FIELDTYPE_SELECTOR="ctadropdownField.validation";
    var CTA_TEXT_SELECTOR="ctastatictext.validation";
    var CTA_DROP_DOWN="ctadropdown.validation";
    var CTA_TEXT_SELECTOR_DYNAMIC="ctastatictextdynamic.validation";
    var CTA_URL_SELECTOR="ctastaticurl.valiodation";
    var foundationReg = $(window).adaptTo("foundation-registry");
    var fieldtype ='';
   	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CTA_FIELDTYPE_SELECTOR + "']",
       validate: function(el) {  
        var error_message = "Please input FieldType";
        var error_message_sec="Please reClick on FieldType"
        var buttonCTAVal=$("[name='./buttonCTA']").val();
        var dynamicbtntxt=$("[name='./ctaBtnTxt']").val();
		if(buttonCTAVal=='dynamic'){
         	var fieldTypeVal=$("input[name*='fieldType']").val();
   			var fieldValueVal=$("input[name*='fieldValue@Delete']").val()
     		if(fieldTypeVal == ''|| fieldTypeVal==undefined){
                return error_message;        
    		}if(fieldValueVal=='' || fieldValueVal==undefined){
				return error_message_sec;
    		}
          }
        }
   });
	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CTA_DROP_DOWN + "']",
       validate: function(el) {
	 	var buttonCTAVal=$("[name='./buttonCTA']").val();
    	var error_message = "Please Select Drop Down";
   		if(buttonCTAVal=='' || buttonCTAVal==undefined){
			return error_message;
		}
     }
   });

       foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CTA_TEXT_SELECTOR + "']",
       validate: function(el) {     
           var error_message = "Input CTA Button Title";
           var buttonCTAVal=$("[name='./buttonCTA']").val();
           console.log
           		if (buttonCTAVal=='static' ){
           			var buttontext=$("input[name*='ctaBtnTxt']");
        			var btnvalue=buttontext.val();
           			if(!(btnvalue!='' && btnvalue!=null)){
						return error_message;
       				}
                }
        }
   });

foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CTA_TEXT_SELECTOR_DYNAMIC + "']",
       validate: function(el) {     
           var error_message = "Input CTA Button Title";
           var buttonCTAVal=$("[name='./buttonCTA']").val();
             		if (buttonCTAVal=='dynamic' ){
           			var buttontext=$("#ctadynamictext");
        			var btnvalue=buttontext.val();
           			if(!(btnvalue!='' && btnvalue!=null)){
						return error_message;
       				}
                }
        }
   });

 foundationReg.register("foundation.validation.validator", {
           selector: "[data-validation='" + CTA_URL_SELECTOR + "']",
           validate: function(el) {     
               var error_message = "Input CTA URL";
				var buttonCTAVal=$("[name='./buttonCTA']").val();
                if (buttonCTAVal=='static'){
               		var urlctatext=$("input[name='./ctaStaticLink']");
            		var urlctavalue=urlctatext.val();
           			var externalurl = false;
           			if(urlctavalue.indexOf("http") > -1 || urlctavalue.indexOf("www.") >-1 ){
							externalurl =true;
       				}
      		   		var internalurl=urlctavalue.startsWith("/content");
               		if((!externalurl && !internalurl )|| urlctavalue.length >= 350){
    					return error_message;
           			}
                        
                 }
           }
       });


 })(document,Granite.$);