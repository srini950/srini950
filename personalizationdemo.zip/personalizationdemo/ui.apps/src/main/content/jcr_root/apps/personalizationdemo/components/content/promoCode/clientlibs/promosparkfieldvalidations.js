(function(document, $) {
   "use strict";
    var PROMO_FIELDTYPE_SELECTOR="promodropdownField.validation";
    var PROMO_TEXT_SELECTOR="promotext.validation";
    var PROMO_RADIO_GROUP ="promoradiogroup.validation";
    var foundationReg = $(window).adaptTo("foundation-registry");
   	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + PROMO_FIELDTYPE_SELECTOR + "']",
       validate: function(el) {  
        var error_message = "Please input FieldType";
        var error_message_sec="Please reClick on FieldType"
        var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
		if(buttonCTAVal=='dynamic'){
         	var fieldTypeVal=$("input[name*='fieldType@Delete']").val();
   			var fieldValueVal=$("input[name*='fieldValue@Delete']").val()
     		if(fieldTypeVal == ''){
                return error_message;        
    		}if(fieldValueVal=='' || fieldValueVal==undefined){
				return error_message_sec;
    		}
          }
        }
   });

    foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + PROMO_RADIO_GROUP + "']",
       validate: function(el) {     
           var error_message = "Select the buttonCTA";
        	var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
              	if (buttonCTAVal=='' || buttonCTAVal==undefined){
						return error_message;
    			}

            }
   });
       foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + PROMO_TEXT_SELECTOR + "']",
       validate: function(el) {     
           var error_message = "Input CTA Button Title";
           var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
           		if (buttonCTAVal=='static'){
           			var herobuttontext=$("input[name*='promoText']");
        			var herobtnvalue=herobuttontext.val();
           			if(!(herobtnvalue!='' && herobtnvalue!=null)){
						return error_message;
       				}
                 }
        }
   });


 })(document,Granite.$);