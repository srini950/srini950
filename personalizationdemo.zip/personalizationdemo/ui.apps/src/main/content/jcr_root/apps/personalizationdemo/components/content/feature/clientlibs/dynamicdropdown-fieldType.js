(function($, $document) {
	"use strict";

	var FIELDTYPE = "./fieldType", FIELDVALUE = "./fieldValue";
	var dynamicData = [];

	$document.on("dialog-ready", function() {
                setTimeout(function(){ 
            					if($("input[name = './featureType']").val() == 'static'){
                                        fieldTypes(FIELDTYPE,FIELDVALUE);
                                    }
                             }, 1000);
		});


     var fieldTypes = function (FIELDTYPE,FIELDVALUE){
		var fieldtype = $("[name='" + FIELDTYPE + "']");
		var fieldTypevalue = new CUI.Select({
			element : $("[name='" + FIELDTYPE + "']")
		});

		fieldTypevalue._selectList.children().not("[role='option']").remove();

		function fillFieldValue(selectedType, selectedValue) {
			var test2 = $("[name='"+FIELDTYPE+"']")[0];
			$("<option>").appendTo(test2).val("").attr("name", "dynamic-field-text").html("Select a Category");
			$.each(dynamicData, function(i, user) {
				test2 = $("[name='"+FIELDTYPE+"']")[0];
				$("<option>").appendTo(test2).val(user.fieldType).attr("name","dynamic-field-text").html(user.fieldType);
			});

			fieldTypevalue = new CUI.Select({
				element : $("[name='" + FIELDTYPE + "']").closest(".coral-Select")
			});

			if (!_.isEmpty(selectedValue)) {
				fieldTypevalue.setValue(selectedValue);
			}
		}

		$.getJSON("/content/dam/pedemo/masterjsondata/dynamicdropdown.json").done(
				function(data) {
					if (_.isEmpty(data)) {
						return;
					}
					dynamicData = data;
					var $form = fieldTypevalue.$element.closest("form");
					$.getJSON($form.attr("action") + ".json").done(
									function(data) {
										if (_.isEmpty(data)) {
											return;
										}
										var field ="fieldType";
										fillFieldValue(fieldtype.val(),
												data.field);
									});
				});


    }

})($, $(document));

