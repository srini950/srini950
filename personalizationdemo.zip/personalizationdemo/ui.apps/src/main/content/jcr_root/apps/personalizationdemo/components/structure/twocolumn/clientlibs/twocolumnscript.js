(function($, $document) {
	"use strict";

	$(document).on("click", ".coral-TabPanel-tab", function() {
		var activeTab = $(this).text();
		console.log("activeTab " + activeTab);

		if (activeTab == 'Category') {

			if (($("#showrelitemscheckbox").is(":checked"))) {
					$('#relatedItemHeaderId').parent().show();
					$("input[name*='showRelatedItems@Delete']").val('true');
			} 
			else {
				$("input[name*='showRelatedItems@Delete']").val('false');
				$('#relatedItemHeaderId').parent().hide();

			}

		}
	});

	$(document).on("click", "#showrelitemscheckbox", function() {
		if ($(this).prop('checked')) {
			$('#relatedItemHeaderId').parent().show();
			$("input[name*='showRelatedItems@Delete']").val('true');

		} else {
			$("input[name*='showRelatedItems@Delete']").val('false');
			$('#relatedItemHeaderId').parent().hide();

		}
	});

})($, $(document));
