(function(document, $) {
    "use strict";
	
    // when dialog gets injected
    $(document).on("dialog-ready", function(e) {
		// if there is already an inital value make sure the according target element becomes visible
        showHideHandler($(".cq-dialog-dropdown-showhide-multi-cta", e.target));
		showHideHandler($(".cq-dialog-dropdown-showhide-multi", e.target));


	});
	
    $(document).on("select", ".cq-dialog-dropdown-showhide-multi-cta", function(e) {
		showHideHandler($(this));
	});
    $(document).on("select", ".cq-dialog-dropdown-showhide-multi", function(e) {
		showHideHandler($(this));
	});
	
	$(document).on("click", ".cq-dialog-submit", function (e) {
        $(".coral-Form-fieldwrapper.hide input").removeAttr("value");
	});

	$(document).on("click", ".js-coral-Multifield-add", function (e) {
      var field = $(this).parent();
    var size = field.attr("data-maxlinksallowed");
    if (size) {
        var totalLinkCount = $(this).prev('ol').children('li').length;
        if (totalLinkCount <= size) {
            showHideHandler($(".cq-dialog-dropdown-showhide-multi-cta", field.target));
			showHideHandler($(".cq-dialog-dropdown-showhide-multi", field.target));
         }
    }
});


    function showHideHandler(el) {
        el.each(function(i, element) {
            if ($(element).is("coral-select")) {
                // handle Coral3 base drop-down
                Coral.commons.ready(element, function(component) {
                    showHide(component, element);
                    component.on("change", function() {
                        showHide(component, element);
					});
				});
				} else {
                // handle Coral2 based drop-down
                var component = $(element).data("select");
                if (component) {
                    showHide(component, element);
				}
			}
		})
	}
	
    function showHide(component, element) {
        // get the selector to find the target elements. its stored as data-.. attribute
        var target = $(element).data("cqDialogDropdownShowhideTarget");
        var $target = $(target);
        var elementIndex = $(element).closest('li').index();
        var value;
        if (target) {
            if (component.value) {
                value = component.value;
				} else {
                value = component.getValue();
			}
            if(target==".cta-hide-show"){
			$target.each(function(index) {
                var tarIndex = $(this).closest('li').index();
                if (elementIndex == tarIndex) {
                    $(this).closest('.coral-Form-fieldset').removeClass("hide");
                    if(value=="exclude"){
                        $(this).closest('.coral-Form-fieldset').addClass("hide");
                    }
				}
			});
            }else{
				$target.each(function(index) {
                var tarIndex = $(this).closest('li').index();
                if (elementIndex == tarIndex) {
					$(this).closest('.coral-Form-fieldwrapper').removeClass("hide");
					$(this).filter("[data-showhidetargetvalue='" + value + "']").closest('.coral-Form-fieldwrapper').addClass("hide");
                    if(value == "dynamic"){
						fieldValue($(this),tarIndex);
                    }
				}
				});
            }
          }
	}



function fieldValue(mainevent,index){
		var mainmultifield =mainevent.closest(".js-coral-Multifield-input.coral-Multifield-input")
		var FIELDTYPE = "./fieldTypeCat", FIELDVALUE = "./fieldValueCat";
		var dynamicData=[];
		var fieldtype =mainmultifield.find(("[name='" + FIELDTYPE + "']"));
		var fieldtype1 = fieldtype.closest(".coral-Select");
        var fieldvalue = new CUI.Select({
            element: mainmultifield.find(("[name='" + FIELDVALUE +"']"))
        });  

        if(_.isEmpty(fieldvalue) || _.isEmpty(fieldtype)){
            return;
        }                 
        fieldvalue._selectList.children().not("[role='option']").remove();

        fieldtype1.on('selected.select', function(event){
            fillFieldValue($(this),event.selected,"");
        });

         $.getJSON("/content/dam/pedemo/masterjsondata/dynamicdropdown.json").done(function(data){
             if(_.isEmpty(data)){
                    return;
             }
            dynamicData=data;
            var $form = fieldvalue.$element.closest("form");
            $.getJSON($form.attr("action") + ".json").done(function(data){
                if(_.isEmpty(data)){
                    return;
                }
				data= data.categoryItems;
               	data =JSON.parse(data[index]);
                 fillFieldValue(mainevent,fieldtype.val(), data.fieldValueCat);
            });

    	});


	function fillFieldValue(event ,selectedType, selectedValue){

        var fieldNameArr=[];
            $.each(dynamicData, function(i, user) {
                if(user.fieldType == selectedType){
					fieldNameArr=user.fieldName;
                }
            });

        var test2;
        if(event ==""){
		}else{
	        var multifieldItem = event.closest(".js-coral-Multifield-input.coral-Multifield-input");
            test2= multifieldItem.find("select[name='./fieldValueCat']");
            var emptytext= multifieldItem.find("[name='./fieldValueCat']");
			emptytext.siblings("ul").empty();
            test2.children("option").remove();
            for(var j=0; j<fieldNameArr.length; j++){
                var opt = $("<option>");
                opt.attr('value',(fieldNameArr[j]));
                opt.attr("name","dynamic-text-value");
                opt.html(fieldNameArr[j]);
               	test2.append(opt);
            }

            fieldvalue = new CUI.Select({
                element: emptytext.closest(".coral-Select")
            });

			if(!_.isEmpty(selectedValue)){                 
                fieldvalue.setValue(selectedValue);
            }
          }
		}
    }

	
})(document, Granite.$, $(document));