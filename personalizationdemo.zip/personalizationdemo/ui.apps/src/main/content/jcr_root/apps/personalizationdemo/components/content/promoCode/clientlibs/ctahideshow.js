(function() {
$(document).on("dialog-ready", function() {
     triggerHeroEvent();
});

    function triggerHeroEvent(){
    	if(($("#promostatic").is(":checked"))){
        	$("#promofieldtype").parent().hide();
        	$("#promofieldvalue").parent().hide();
        	$("#promotext").parent().show();
            $("#ctaStaticLink").parent().show();
            $("input[name*='buttonCTA@Delete']").val('static');
    	}else if(($("#promodynamic").is(":checked"))){
        	$("#promotext").parent().hide();
            $("#ctaStaticLink").parent().hide();
			$("#promofieldtype").parent().show();
        	$("#promofieldvalue").parent().show();
            $("input[name*='buttonCTA@Delete']").val('dynamic');
    	}else{
			$("#promotext").parent().hide();
            $("#ctaStaticLink").parent().hide();
			$("#promofieldtype").parent().hide();
        	$("#promofieldvalue").parent().hide();
    	}
		$("#promostatic").click(function(){
    		$("#promofieldtype").parent().hide();
    		$("#promofieldvalue").parent().hide();
    		$("#promotext").parent().show();
            $("#ctaStaticLink").parent().show();
			$("input[name*='buttonCTA@Delete']").val('static');
		});

		$("#promodynamic").click(function(){
        	$("#promotext").parent().hide();
			$("#promofieldtype").parent().show();
    		$("#promofieldvalue").parent().show();
            $("#ctaStaticLink").parent().hide();
            $("input[name*='buttonCTA@Delete']").val('dynamic');

		});
  	}


})();