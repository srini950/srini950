(function(document, $) {
   "use strict";

     var MULTI_NAME_SELECTOR="multiname.validation";
     var RELATED_ITEM_SELECTOR="relateditemheader.validation";
     var foundationReg = $(window).adaptTo("foundation-registry");
     
     foundationReg.register("foundation.validation.validator", {
         selector: "[data-validation='" + RELATED_ITEM_SELECTOR + "']",
         validate: function(el) {   

              var error_message = "Please input related items title";
         	 var ctaButtonReqVal=$("input[name*='showRelatedItems@Delete']").val();

  				if(ctaButtonReqVal=='true'){       			 
  					var relItemsVal=$("input[name='./relatedItemHeader']").val();
  					if(relItemsVal=="" || relItemsVal== undefined){
          			 return error_message;
  					}
              }

         }
     });

	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + MULTI_NAME_SELECTOR + "']",
       validate: function(el) {  
        
            var error_message = "Please select the short Name";
        	   var $fieldSets = $("[class='coral-Form-fieldset'][data-name='./items']");
               var record, $fields, $field, name;
                $fieldSets.each(function (i, fieldSet) {
                    $fields = $(fieldSet).find("[name]");
                    record = {};
                    $fields.each(function (j, field) {
                        $field = $(field);
                        name = $field.attr("name");
                        if (name) {
                        if (name.indexOf("./") == 0  && name.indexOf('@Delete')==-1) {
                            name = name.substring(2);
                            record[i] = $field.val();
                            console.log("i "+record[i]);
                        }
                        $field.remove();
                        }
                    });
                });
			}
   });

 })(document,Granite.$);