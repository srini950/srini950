(function ($, $document){
	"use strict";
    $(document).on("click",".coral-TabPanel-tab",function() {
       	var activeTab=$(this).text();
        console.log("activeTab "+activeTab);
        if(activeTab=='CATEGORY'){
            categoryFunction();
            oneColumnFieldValuesCat();
        }else if(activeTab=='DETAILS CARD'){
           detailsCardFunction();
           oneColumnFieldValuesDC();
        }else if(activeTab=='GENERAL'){

           	pagefieldValue();
        }

    });

// All Js for Category Tab Starts

    function categoryFunction(){
        if(($("#dpshowautocategorypage").is(":checked"))){
            $("input[name*='detailspageShowCategorypage@Delete']").val('true');
            $(".dpcategorypage").show();
			if(($("#dpctabuttonrequiredcat").is(":checked"))){
                $("input[name*='dpCTAButtonRequiredCat@Delete']").val('true');
            	$(".dpCTAButtonsGroupCat").show(); 
                if(($("#dpstaticcat").is(":checked"))){
					$("#dpfieldtypecat").parent().hide();
        			$("#dpfieldvaluecat").parent().hide();
        			$("#dpctanamecat").parent().show();
        			$("#dpurlctacat").parent().show();
                    $("input[name*='dpButtonCTACat@Delete']").val('static');
                }else if(($("#dpdynamiccat").is(":checked"))){
					$("#dpfieldtypecat").parent().show();
        			$("#dpfieldvaluecat").parent().show();
        			$("#dpctanamecat").parent().show();
        			$("#dpurlctacat").parent().hide();
                    $("input[name*='dpButtonCTACat@Delete']").val('dynamic');
                }else{
                    $("#dpfieldtypecat").parent().hide();
        			$("#dpfieldvaluecat").parent().hide();
        			$("#dpctanamecat").parent().hide();
        			$("#dpurlctacat").parent().hide();
                }
        	}else{
				$("input[name*='dpCTAButtonRequiredCat@Delete']").val('false');
             	$(".dpCTAButtonsGroupCat").hide();
        	}            
        }else{
             $(".dpcategorypage").hide();
            $("input[name*='detailspageShowCategorypage@Delete']").val('false');
        }
    }
    $(document).on("click","#dpshowautocategorypage,#dpctabuttonrequiredcat,#dpstaticcat,#dpdynamiccat",function(){
		categoryFunction();
	});

	function oneColumnFieldValuesCat(){
		var FIELDTYPECAT = "./dpFieldTypeCat", FIELDVALUECAT = "./dpFieldValueCat";
		var dynamicData=[];
        var fieldtypeCat =$("[name='" + FIELDTYPECAT + "']");
        var selectedFieldValueCat = $("[name='" + FIELDVALUECAT +"']");
		var fieldtypeCat1 = $("[name='" + FIELDTYPECAT +"']").closest(".coral-Select");
        var fieldvalueCat = new CUI.Select({
            element: $("[name='" + FIELDVALUECAT +"']")
        });  
        var selectFieldValueCat=$("[name='" + FIELDVALUECAT +"']").closest(".coral-Select");
        if(_.isEmpty(fieldvalueCat) || _.isEmpty(fieldtypeCat)){
            return;
        }                 
        fieldvalueCat._selectList.children().not("[role='option']").remove();
        function fillFieldValueCat(selectedType, selectedValue){
			var fieldNameArr=[];
           $("[name='./dpFieldValueCat']").siblings("ul").empty();
           $("option[name='dynamic-text-value-cat']").remove();
            $.each(dynamicData, function(i, user) {
                if(user.fieldType == selectedType){
					fieldNameArr=user.fieldName;
                }
                });
                for(var j=0; j<fieldNameArr.length; j++){
                var test2 = $("[name='./dpFieldValueCat']")[0]; 
               	$("<option>").appendTo(test2).val(fieldNameArr[j]).attr("name","dynamic-text-value-cat").html(fieldNameArr[j]);
                }
            fieldvalueCat = new CUI.Select({
                element: $("[name='" + FIELDVALUECAT +"']").closest(".coral-Select")
            });
			var fieldValueCatDel=$("input[name*='dpFieldValueCat@Delete']").val();
			if(!_.isEmpty(selectedValue)){                 
                fieldvalueCat.setValue(selectedValue);
            }if(!_.isEmpty(fieldValueCatDel)){
				fieldvalueCat.setValue(fieldValueCatDel);
            }
        }
        fieldtypeCat1.on('selected.select', function(event){
            fillFieldValueCat(event.selected);
        });
         $.getJSON("/content/dam/pedemo/masterjsondata/dynamicdropdown.json").done(function(data){
             if(_.isEmpty(data)){
                    return;
             }
            dynamicData=data;
            var $form = fieldvalueCat.$element.closest("form");
             console.log("apoorv "+$form.attr("action") + ".json");
            $.getJSON($form.attr("action") + ".json").done(function(data){
                if(_.isEmpty(data)){
                    return;
                }
				fillFieldValueCat(fieldtypeCat.val(), data.dpFieldValueCat);
            });
    	});
     }

 // All Js for Category Tab Ends Here

// All Js for Details Tab Starts Here

    function detailsCardFunction(){
        if(($("#dpshowautocarouseldc").is(":checked"))){
            $("input[name*='dpShowcarouselDC@Delete']").val('true');
            $(".dpdetailscard").show();
            if(($("#dpctabuttonrequireddc").is(":checked"))){
                $("input[name*='dpCTAButtonRequiredDC@Delete']").val('true');
            	$(".dpCTAButtonsGroupDC").show(); 
                if(($("#dpstaticdc").is(":checked"))){
                    $("#dpfieldtypedc").parent().hide();
        			$("#dpfieldvalueDC").parent().hide();
        			$("#dpctanamedc").parent().show();
        			$("#dpurlctadc").parent().show();
                    $("input[name*='dpButtonCTADC@Delete']").val('static');
                }else if(($("#dpdynamicdc").is(":checked"))){
					$("#dpfieldtypedc").parent().show();
        			$("#dpfieldvalueDC").parent().show();
        			$("#dpctanamedc").parent().show();
        			$("#dpurlctadc").parent().hide();
                     $("input[name*='dpButtonCTADC@Delete']").val('dynamic');
                }else{
					$("#dpfieldtypedc").parent().hide();
        			$("#dpfieldvalueDC").parent().hide();
        			$("#dpctanamedc").parent().hide();
        			$("#dpurlctadc").parent().hide();
                }
        	}else{
             	$(".dpCTAButtonsGroupDC").hide();
                $("input[name*='dpCTAButtonRequiredDC@Delete']").val('false');
        	} 
        }else{
            $("input[name*='dpShowcarouselDC@Delete']").val('false');
             $(".dpdetailscard").hide();
        }
    }
     $(document).on("click","#dpshowautocarouseldc,#dpctabuttonrequireddc,#dpstaticdc,#dpdynamicdc",function(){
		detailsCardFunction();
	});
    function oneColumnFieldValuesDC(){
		var FIELDTYPEDC = "./dpFieldTypeDC", FIELDVALUEDC = "./dpFieldValueDC";
		var dynamicData=[];
        var fieldtypeDC =$("[name='" + FIELDTYPEDC + "']");
        var selectedFieldValueDC = $("[name='" + FIELDVALUEDC +"']");
		var fieldtypeDC1 = $("[name='" + FIELDTYPEDC +"']").closest(".coral-Select");
        var fieldvalueDC = new CUI.Select({
            element: $("[name='" + FIELDVALUEDC +"']")
        });  
        var selectFieldValueDC=$("[name='" + FIELDVALUEDC +"']").closest(".coral-Select");
        if(_.isEmpty(fieldvalueDC) || _.isEmpty(fieldtypeDC)){
            return;
        }                 
        fieldvalueDC._selectList.children().not("[role='option']").remove();
        function fillFieldValueDC(selectedType, selectedValue){
			$("[name='./dpFieldValueDC']").siblings("ul").empty();
           	$("option[name='dynamic-text-value-dc']").remove();
			var fieldNameArr=[];
            $.each(dynamicData, function(i, user) {
          		if(user.fieldType == selectedType){
					fieldNameArr=user.fieldName;
                }
                });
                for(var j=0; j<fieldNameArr.length; j++){
                var test2 = $("[name='./dpFieldValueDC']")[0]; 
               	$("<option>").appendTo(test2).val(fieldNameArr[j]).attr("name","dynamic-text-value-dc").html(fieldNameArr[j]);
                }
            fieldvalueDC = new CUI.Select({
                element: $("[name='" + FIELDVALUEDC +"']").closest(".coral-Select")
            });
			var fieldValueDCDel=$("input[name*='dpFieldValueDC@Delete']").val();
			if(!_.isEmpty(selectedValue)){                 
                fieldvalueDC.setValue(selectedValue);
            }if(!_.isEmpty(fieldValueDCDel)){
				fieldvalueDC.setValue(fieldValueDCDel);
            }
        }
        fieldtypeDC1.on('selected.select', function(event){
            fillFieldValueDC(event.selected);
        });

         $.getJSON("/content/dam/pedemo/masterjsondata/dynamicdropdown.json").done(function(data){
             if(_.isEmpty(data)){
                    return;
             }
             dynamicData=data;
            var $form = fieldvalueDC.$element.closest("form");
            $.getJSON($form.attr("action") + ".json").done(function(data){
                if(_.isEmpty(data)){
                    return;
                }
				fillFieldValueDC(fieldtypeDC.val(), data.dpFieldValueDC);
            });
    	});
     }
//pagefieldType and pagefieldValue


    function pagefieldValue(){
	var FIELDTYPE = "./pagefieldType", FIELDVALUE = "./pagefieldValue";
	var dynamicData=[];
        var fieldtype =$("[name='" + FIELDTYPE + "']");
        var selectedFieldValue = $("[name='" + FIELDVALUE +"']");
		var fieldtype1 = $("[name='" + FIELDTYPE +"']").closest(".coral-Select");
        var fieldvalue = new CUI.Select({
            element: $("[name='" + FIELDVALUE +"']")
        });  
        var selectFieldValue=$("[name='" + FIELDVALUE +"']").closest(".coral-Select");
        if(_.isEmpty(fieldvalue) || _.isEmpty(fieldtype)){
            return;
        }                 
        fieldvalue._selectList.children().not("[role='option']").remove();

        function fillFieldValue(selectedType, selectedValue){
            $("[name='./pagefieldValue']").siblings("ul").empty();
            $("option[name='dynamic-text-value']").remove();
			var fieldNameArr=[];
            $.each(dynamicData, function(i, user) {
                if(user.categoryType == selectedType){
					fieldNameArr=user.detailID;
                }
                });
                for(var j=0; j<fieldNameArr.length; j++){
                var test2 = $("[name='./pagefieldValue']")[0]; 
               	$("<option>").appendTo(test2).val(fieldNameArr[j].id).attr("name","dynamic-text-value").html(fieldNameArr[j].id+" - "+fieldNameArr[j].desc);
                }


            fieldvalue = new CUI.Select({
                element: $("[name='" + FIELDVALUE +"']").closest(".coral-Select")
            });

			if(!_.isEmpty(selectedValue)){                 
                fieldvalue.setValue(selectedValue);
            }else{
                if($("input[name*='pagefieldType@Delete']").val() !=''){
				$("input[name*='pagefieldValue@Delete']").val(fieldNameArr[0]);
                }
            }
        }

        fieldtype1.on('selected.select', function(event){
            fillFieldValue(event.selected);
        });

         $.getJSON("/content/dam/pedemo/masterjsondata/benefits-offers.json").done(function(data){
             if(_.isEmpty(data)){
                    return;
             }
             dynamicData=data;
            var $form = fieldvalue.$element.closest("form");
            $.getJSON($form.attr("action") + ".json").done(function(data){
                if(_.isEmpty(data)){
                    return;
                }

				fillFieldValue(fieldtype.val(), data.pagefieldValue);
            })

    	});



    }
// All Js for Details Tab Ends Here
    
    $(window).on("load", function () {
        for(var i = $( ".coral-TabPanel-tab" ).length ; i > 0; i--){
			$( ".coral-TabPanel-tab" )[i-1].click();
        }
  });

})($, $(document));