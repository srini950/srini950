(function ($, $document) {
    "use strict";

    var FIELDTYPE = "./fieldType", FIELDVALUE = "./fieldValue";
	var dynamicData=[];

    $document.on("dialog-ready", function() {
          	setTimeout(function(){ 
                   fieldValues(FIELDTYPE,FIELDVALUE,"");
                   fieldValues("./fieldTypeMet","./fieldValueMet","Met");
                   fieldValues("./fieldTypeNotMet","./fieldValueNotMet","NotMet");
             }, 1000);
	});

    $(document).on("click",".coral-Tab",function(){
        if($(this).text() == 'DYNAMIC FEATURE (Condition met)'){
             if($("#ctaButtonRequiredMet").is(":checked")){
			 fieldValues("./fieldTypeMet","./fieldValueMet","Met");
             }
        }else{
            if($("#ctaButtonRequiredNotMet").is(":checked")){
                fieldValues("./fieldTypeNotMet","./fieldValueNotMet","NotMet");
             }
        }

    });
     var fieldValues = function (FIELDTYPE,FIELDVALUE,condition){
 		var fieldtype =$("[name='" + FIELDTYPE + "']");
        var selectedFieldValue = $("[name='" + FIELDVALUE +"']");
		var fieldtype1 = $("[name='" + FIELDTYPE +"']").closest(".coral-Select");
        var fieldvalue = new CUI.Select({
            element: $("[name='" + FIELDVALUE +"']")
        });  
        var selectFieldValue=$("[name='" + FIELDVALUE +"']").closest(".coral-Select");
        if(_.isEmpty(fieldvalue) || _.isEmpty(fieldtype)){
            return;
        }                 
        fieldvalue._selectList.children().not("[role='option']").remove();

        function fillFieldValue(selectedType, selectedValue){

           $("[name='"+FIELDVALUE+"']").siblings("ul").empty();
            var removeName= 'dynamic-text-value'+condition;
           $("option[name='"+removeName+"']").remove();
			var fieldNameArr=[];
            $.each(dynamicData, function(i, user) {
                if(user.fieldType == selectedType){
					fieldNameArr=user.fieldName;
                }
                });
                for(var j=0; j<fieldNameArr.length; j++){
                var test2 = $("[name='"+FIELDVALUE+"']")[0]; 
               	$("<option>").appendTo(test2).val(fieldNameArr[j]).attr("name","dynamic-text-value"+condition).html(fieldNameArr[j]);
                }


            fieldvalue = new CUI.Select({
                element: $("[name='" + FIELDVALUE +"']").closest(".coral-Select")
            });

			if(!_.isEmpty(selectedValue)){                 
                fieldvalue.setValue(selectedValue);
            }else{
                if($("input[name*='fieldType@Delete']").val() !=''){
				$("input[name*='fieldValue@Delete']").val(fieldNameArr[0]);
                }
            }
        }

        fieldtype1.on('selected.select', function(event){
            fillFieldValue(event.selected);
        });


         $.getJSON("/content/dam/pedemo/masterjsondata/dynamicdropdown.json").done(function(data){
             if(_.isEmpty(data)){
                    return;
             }
             dynamicData=data;
            var $form = fieldvalue.$element.closest("form");
            $.getJSON($form.attr("action") + ".json").done(function(data){
                if(_.isEmpty(data)){
                    return;
                }
                if(condition ==""){
				fillFieldValue(fieldtype.val(), data.fieldValue);
                }else if(condition =="Met"){
                  fillFieldValue(fieldtype.val(), data.fieldValueMet);
                }else if(condition =="NotMet"){
                   fillFieldValue(fieldtype.val(), data.fieldValueNotMet); 
                }
            });

    	});
}
})($, $(document));

