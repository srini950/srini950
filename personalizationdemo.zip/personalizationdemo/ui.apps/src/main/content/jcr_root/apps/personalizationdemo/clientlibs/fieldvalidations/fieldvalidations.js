(function(document, $) {
   "use strict";

    var FIELDTYPE_SELECTOR="dropdownField.validation";
    var BTN_CTA_SELECTOR="btncta.validation";
    var URL_CTA_SELECTOR="urlcta.validation";
    var RADIO_GROUP ="radiogroup.validation";
    var foundationReg = $(window).adaptTo("foundation-registry");
   	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + FIELDTYPE_SELECTOR + "']",
       validate: function(el) {  
        var error_message = "Please input FieldType";
        var error_message_sec="Please reClick on FieldType"
       	var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
        var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
               	if(ctaButtonReqVal=='true')
                    {
                        if(buttonCTAVal=='dynamic'){
                            var fieldTypeVal=$("input[name*='fieldType@Delete']").val();
        					var fieldValueVal=$("input[name*='fieldValue@Delete']").val()
        					console.log("test "+fieldValueVal);
                            if(fieldTypeVal == ''){
                                console.log("select field type if " );	
                                return error_message;        
    						}if(fieldValueVal=='' || fieldValueVal==undefined){
								return error_message_sec;
    						}

                       }

                    }
       	}
   });

    foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + RADIO_GROUP + "']",
       validate: function(el) {     
           var error_message = "Select the buttonCTA";
        	var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
        	if (ctaButtonReqVal=='true'){
        	var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
        console.log("radio group btnval "+buttonCTAVal);
       			if (buttonCTAVal=='' || buttonCTAVal==undefined){
						return error_message;
    			}
        	}
       }
   });
       foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + BTN_CTA_SELECTOR + "']",
       validate: function(el) {     
           var error_message = "Input CTA Button Title";
           var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
           var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
       		if (ctaButtonReqVal=='true'){
           		if (buttonCTAVal!='' && buttonCTAVal!=undefined){
           			var herobuttontext=$("input[name*='textCTA']");
        			var herobtnvalue=herobuttontext.val();
           			if(!(herobtnvalue!='' && herobtnvalue!=null)){
						return error_message;
       				}
                 }
             }
       }
   });
       foundationReg.register("foundation.validation.validator", {
           selector: "[data-validation='" + URL_CTA_SELECTOR + "']",
           validate: function(el) {     
               var error_message = "Input CTA URL";
               var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
               var buttonCTAVal=$("input[name*='buttonCTA@Delete']").val();
           		if (ctaButtonReqVal=='true'){
               		if (buttonCTAVal=='static'){
               			var herourlctatext=$("input[name*='urlCTA']");
            			var herourlctavalue=herourlctatext.val();
           				var externalurl = false;
           				if(herourlctavalue.indexOf("http") > -1 || herourlctavalue.indexOf("www.") >-1){
							externalurl =true;
       					}
      		   			var internalurl=herourlctavalue.startsWith("/content");
               			if((!externalurl && !internalurl )|| herourlctavalue.length >= 350){
    						return error_message;
           				}
                        
                     }
                 }
           }
       });


 })(document,Granite.$);