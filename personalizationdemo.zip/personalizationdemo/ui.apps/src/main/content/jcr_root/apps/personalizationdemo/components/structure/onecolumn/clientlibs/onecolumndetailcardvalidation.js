(function(document, $) {
   "use strict";

     var DC_TITLE_SELECTOR="dctitle.validation";
     var DC_BLUR_SELECTOR="dcblur.validation";
     var DC_RADIO_GROUP ="dcradiogroup.validation";
     var DC_BTN_TITLE_SELECTOR="dcbtntitle.validation";
     var DC_URL_CTA_SELECTOR="dcurlcta.validation";
     var DC_FIELDTYPE_SELECTOR="dcfieldtype.validation";
     var DC_FIELDVALUE_SELECTOR="dcfieldvalue.validation"
     var foundationReg = $(window).adaptTo("foundation-registry");

	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + DC_TITLE_SELECTOR + "']",
       validate: function(el) {     
           	var error_message="Please select the Carousel Title";
        	var autoPageCat=$("input[name*='dpShowcarouselDC@Delete']").val();
        	var catTitle=$("input[name='./dpCarouselTitleDC']").val();
        	if(autoPageCat=='true'){
				if(catTitle=="" || catTitle== undefined){
        			 return error_message;
    			}
   			}
       }
   });
	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + DC_BLUR_SELECTOR + "']",
       validate: function(el) {     
        	var error_message="Please select the Category Page Blurb";
        	var autoPageCat=$("input[name*='dpShowcarouselDC@Delete']").val();
        	var catBlur=$("textarea[name='./dpBlurbDC']").val();
         	if(autoPageCat=='true'){
				if(catBlur=="" || catBlur== undefined){
        			 return error_message;
    			}
   			}
       }
   });

    foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + DC_RADIO_GROUP + "']",
       validate: function(el) {     
           var error_message = "Select the buttonCTA";
           var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredDC@Delete']").val();
           var autoPageCat=$("input[name*='dpShowcarouselDC@Delete']").val();
        	if (ctaButtonReqVal=='true' && autoPageCat=='true'){
        	var buttonCTAVal=$("input[name*='dpButtonCTADC@Delete']").val();
       			if (buttonCTAVal=='' || buttonCTAVal==undefined){
						return error_message;
    			}
        	}
       }
   });
   foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + DC_BTN_TITLE_SELECTOR + "']",
       validate: function(el) {     
           var error_message = "Input CTA Button Title";
           var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredDC@Delete']").val();
           var buttonCTAVal=$("input[name*='dpButtonCTADC@Delete']").val();
       	   var autoPageCat=$("input[name*='dpShowcarouselDC@Delete']").val();
       		if (ctaButtonReqVal=='true' && autoPageCat=='true' ){
           		if (buttonCTAVal!='' && buttonCTAVal!=undefined){
           			var buttontext=$("input[name*='dpCTANameDC']");
        			var btnvalue=buttontext.val();
           			if(!(btnvalue!='' && btnvalue!=null)){
						return error_message;
       				}
                 }
             }
       }
   });
  foundationReg.register("foundation.validation.validator", {
           selector: "[data-validation='" + DC_URL_CTA_SELECTOR + "']",
           validate: function(el) {     
               var error_message = "Input CTA URL/in Correct format";
               var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredDC@Delete']").val();
               var autoPageCat=$("input[name*='dpShowcarouselDC@Delete']").val();
      		   var buttonCTAVal=$("input[name*='dpButtonCTADC@Delete']").val();
      		   var catCtaUrl =$("input[name*='dpUrlCTADC']").val();
      		   var externalurl = false;
           	   if(catCtaUrl.indexOf("http") > -1 || catCtaUrl.indexOf("www.") >-1){
							externalurl =true;
       		   }
      		   var internalurl=catCtaUrl.startsWith("/content");
      			console.log("externalurl "+externalurl +" internalurl "+internalurl);
           		if (ctaButtonReqVal=='true' && autoPageCat=='true'){
               		if (buttonCTAVal=='static'){
  					    if(!externalurl && !internalurl){
      						return error_message;
  						}
                     }
                 }
           }
  });
  foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + DC_FIELDTYPE_SELECTOR + "']",
       validate: function(el) {  
        var error_message = "Please select FieldType";
       	var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredDC@Delete']").val();
        var autoPageCat=$("input[name*='dpShowcarouselDC@Delete']").val();
        var buttonCTAVal=$("input[name*='dpButtonCTADC@Delete']").val();
        var fieldTypeVal=$("[name='./dpFieldTypeDC']").val();
            if(ctaButtonReqVal=='true' && autoPageCat=='true') {
                if(buttonCTAVal=='dynamic'){
				if(!(fieldTypeVal!="" && fieldTypeVal!=null)){
      						return error_message;
  						}
				}
			}
       	}
   });
  foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + DC_FIELDVALUE_SELECTOR + "']",
       validate: function(el) {  
        var error_message = "Please select FieldValue";
       	var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredDC@Delete']").val();
        var autoPageCat=$("input[name*='dpShowcarouselDC@Delete']").val();
        var buttonCTAVal=$("input[name*='dpButtonCTADC@Delete']").val();
        var fieldTypeVal=$("[name='./dpFieldValueDC']").val();
            if(ctaButtonReqVal=='true' && autoPageCat=='true') {
                if(buttonCTAVal=='dynamic'){
				if(!(fieldTypeVal!="" && fieldTypeVal!=null)){
      						return error_message;
  						}
				}
			}
       	}
   });

 })(document,Granite.$);