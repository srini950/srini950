(function(document, $) {
   "use strict";

     var PRE_HEADER_SELECTOR="preheadercat.validation";
     var CAT_TITLE_SELECTOR="cattitle.validation";
     var CAT_BLUR_SELECTOR="catblur.validation";
     var CAT_RADIO_GROUP ="catradiogroup.validation";
     var CAT_BTN_TITLE_SELECTOR="catbtntitle.validation";
     var CAT_URL_CTA_SELECTOR="caturlcta.validation";
     var CAT_FIELDTYPE_SELECTOR="catfieldtype.validation";
     var CAT_FIELDVALUE_SELECTOR="catfieldvalue.validation"
     var foundationReg = $(window).adaptTo("foundation-registry");


	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + PRE_HEADER_SELECTOR + "']",
       validate: function(el) {     
            var error_message = "Please select the Pre-Header";
        	var autoPageCat=$("input[name*='detailspageShowCategorypage@Delete']").val();
        	var preHeader=$("input[name='./dpPreHeaderCat']").val();
        	if(autoPageCat=='true'){
        		if(preHeader=="" || preHeader== undefined){
        			 return error_message;
    			}
   			}
       }
   });
	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CAT_TITLE_SELECTOR + "']",
       validate: function(el) {     
           	var error_message="Please select the Category Page Title";
        	var autoPageCat=$("input[name*='detailspageShowCategorypage@Delete']").val();
        	var catTitle=$("input[name='./dpTitleCat']").val();
        	if(autoPageCat=='true'){
				if(catTitle=="" || catTitle== undefined){
        			 return error_message;
    			}
   			}
       }
   });
	foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CAT_BLUR_SELECTOR + "']",
       validate: function(el) {     
        	var error_message="Please select the Category Page Blurb";
        	var autoPageCat=$("input[name*='detailspageShowCategorypage@Delete']").val();
        	var catBlur=$("textarea[name='./dpBlurbCat']").val();
         	if(autoPageCat=='true'){
				if(catBlur=="" || catBlur== undefined){
        			 return error_message;
    			}
   			}
       }
   });

    foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CAT_RADIO_GROUP + "']",
       validate: function(el) {     
           var error_message = "Select the buttonCTA";
           var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredCat@Delete']").val();
           var autoPageCat=$("input[name*='detailspageShowCategorypage@Delete']").val();
        	if (ctaButtonReqVal=='true' && autoPageCat=='true'){
        	var buttonCTAVal=$("input[name*='dpButtonCTACat@Delete']").val();
       			if (buttonCTAVal=='' || buttonCTAVal==undefined){
						return error_message;
    			}
        	}
       }
   });
   foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CAT_BTN_TITLE_SELECTOR + "']",
       validate: function(el) {     
           var error_message = "Input CTA Button Title";
           var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredCat@Delete']").val();
           var buttonCTAVal=$("input[name*='dpButtonCTACat@Delete']").val();
       	   var autoPageCat=$("input[name*='detailspageShowCategorypage@Delete']").val();
       		if (ctaButtonReqVal=='true' && autoPageCat=='true' ){
           		if (buttonCTAVal!='' && buttonCTAVal!=undefined){
           			var buttontext=$("input[name*='dpCTANameCat']");
        			var btnvalue=buttontext.val();
           			if(!(btnvalue!='' && btnvalue!=null)){
						return error_message;
       				}
                 }
             }
       }
   });
  foundationReg.register("foundation.validation.validator", {
           selector: "[data-validation='" + CAT_URL_CTA_SELECTOR + "']",
           validate: function(el) {     
               var error_message = "Input CTA URL";
               var ctaButtonReqVal=$("input[name*='ctaButtonRequired@Delete']").val();
               var autoPageCat=$("input[name*='detailspageShowCategorypage@Delete']").val();
      		   var buttonCTAVal=$("input[name*='dpButtonCTACat@Delete']").val();
      		   var catCtaUrl =$("input[name*='dpUrlCTACat']").val();
               var externalurl = false;
           	   if(catCtaUrl.indexOf("http") > -1 || catCtaUrl.indexOf("www.") >-1){
							externalurl =true;
       		   }
      		   var internalurl=catCtaUrl.startsWith("/content");
           		if (ctaButtonReqVal=='true' && autoPageCat=='true'){
               		if (buttonCTAVal=='static'){
  					    if(!externalurl && !internalurl){
      						return error_message;
  						}
                     }
                 }
           }
  });
  foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CAT_FIELDTYPE_SELECTOR + "']",
       validate: function(el) {  
        var error_message = "Please select FieldType";
       	var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredCat@Delete']").val();
        var autoPageCat=$("input[name*='detailspageShowCategorypage@Delete']").val();
        var buttonCTAVal=$("input[name*='dpButtonCTACat@Delete']").val();
        var fieldTypeVal=$("[name='./dpFieldTypeCat']").val();
      	console.log(ctaButtonReqVal + autoPageCat+ buttonCTAVal);
            if(ctaButtonReqVal=='true' && autoPageCat=='true') {
                if(buttonCTAVal=='dynamic'){
      			if((fieldTypeVal=="" || fieldTypeVal==undefined)){
      						return error_message;
  						}
				}
			}
       	}
   });
  foundationReg.register("foundation.validation.validator", {
       selector: "[data-validation='" + CAT_FIELDVALUE_SELECTOR + "']",
       validate: function(el) {  
        var error_message = "Please select FieldValue";
       	var ctaButtonReqVal=$("input[name*='dpCTAButtonRequiredCat@Delete']").val();
        var autoPageCat=$("input[name*='detailspageShowCategorypage@Delete']").val();
        var buttonCTAVal=$("input[name*='dpButtonCTACat@Delete']").val();
        var fieldTypeVal=$("[name='./dpFieldValueCat']").val();
            if(ctaButtonReqVal=='true' && autoPageCat=='true') {
                if(buttonCTAVal=='dynamic'){
				if(!(fieldTypeVal!="" && fieldTypeVal!=null)){
      						return error_message;
  						}
				}
			}
       	}
   });

 })(document,Granite.$);