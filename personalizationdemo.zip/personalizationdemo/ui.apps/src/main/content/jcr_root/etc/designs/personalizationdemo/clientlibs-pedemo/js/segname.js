function segment(delay) {
    setTimeout(function() {
        if (mode == "publish") {
            var contextSegment = ContextHub.SegmentEngine.SegmentManager.getResolvedSegments();
            var contexhubJson = JSON.parse(JSON.stringify(contextSegment.sort(function(a, b) {
                return parseFloat(b.boost) - parseFloat(a.boost);
            })));

            var resolvedPaths = contexhubJson.map(function(item) {
                return item.path;
            });
            var pedemoPath = [];
            $.each(resolvedPaths, function(i, path) {
            	console.log("resolved paths :::path::"+path);
                if (path.indexOf("pedemo") > -1) {
                	pedemoPath.push(path);
                }
            });
            $.ajax({
                url: '/content/pedemo.getSegName.json',
                data: {
                    "segmentPath": pedemoPath
                },
                async: false,
                cache: false,
                success: function(result) {
                    console.log("segment name::::"+result.segName);
                },
                error: function() {
                    console.log("error in ajax call to getSegName page json from servlet");
                }
            });
            $(document).trigger('dl-ready');
        }
    }, delay);
}


