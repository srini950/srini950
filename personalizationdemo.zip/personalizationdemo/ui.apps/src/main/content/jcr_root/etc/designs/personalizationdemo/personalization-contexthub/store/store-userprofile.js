(function($) {
	'use strict';
	var initialLoad = true;

	var defaultConfig = {
		initialValues : {
			id : '0',
			accountname : 'test'

		}
	};

	var ProfileStore = function(name, config) {
		this.config = $.extend(true, {}, defaultConfig, config);
		this.init(name, this.config);
		this.queryService(false);
	};
	ContextHub.Utils.inheritance.inherit(ProfileStore,
			ContextHub.Store.PersistedJSONPStore);

	ProfileStore.prototype.loadProfile = function(accountname, id,
			initialLoader) {
		var store = ContextHub.getStore('userprofile');
		store.setItem('accountname', accountname);
		store.setItem('id', id);
		this.pauseEventing();
		var result = $.extend(true, {}, store.userprofile);
		result = ContextHub.Utils.JSON.tree.setItem(result, 'accountname',
				accountname);
		result = ContextHub.Utils.JSON.tree.setItem(result, 'id', id);
		var displayName = result.accountname;
		result = ContextHub.Utils.JSON.tree.setItem(result, 'displayName',
				displayName);
		this.setItem('/', result);
		if (initialLoad || initialLoader) {

			if (accountname != "Your Company") {
			$.ajax({
	                     url: '/content/pedemo.exceptinListServlet.json',
	                    data:{"pedemoid" : id},
	                     async: false,
	                     success: function (result) {
	                        exceptionName=result.ExceptionValue;
	                      },
	                      error: function(){
	                                       console.log("error in ajax call to getKeword replace json from servlet");
	                      }
	                 });
				getcopstore(accountname ,id);
				if(mode == ""){
				 	 $.ajax({
	                     url: '/content/pedemo.keywordReplaceServlet.json',
	                    data:{"pedemoid" : id},
	                     async: false,
	                     success: function (result) {
	                         for (var key in result) {
	                             dynamicData=JSON.parse(result[key]);
	                             for(var i = 0 ; i< dynamicData.length; i++){
	                                 $.each(dynamicData[i], function(keydata, valuedata) {
	                                         keyReplace(keydata, valuedata);
	                                 });
	                             }
	                         }
	                      },
	                      error: function(){
	                                       console.log("error in ajax call to getKeword replace json from servlet");
	                      }
	                 });
				}
				
			}

			initialLoad = false;
		}
		this.resumeEventing();
		store.queryService(true);
	};

	ContextHub.Utils.storeCandidates.registerStoreCandidate(ProfileStore,
			'contexthub.userprofile', 0);

}(ContextHubJQ));