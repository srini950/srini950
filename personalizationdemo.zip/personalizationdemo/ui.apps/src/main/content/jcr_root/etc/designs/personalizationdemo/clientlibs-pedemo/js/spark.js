/* custom js for spark */
var corporateStore = ContextHub.getStore("userprofile");
var id = corporateStore.getItem("id");
var accountname = corporateStore.getItem("accountname");
var dynamicData = "";
var $targetedCall = true;
window.onbeforeunload = function() {
	window.scrollTo(0, 0);
	cookies();
}

// CAROUSEL
//This is needed anywhere the carousel is used
function normalizeSlideHeights() {
  $('.carousel').each(function(){
    var items = $('.carousel-item', this);
    // reset the height
    items.css('min-height', 500);
    // set the height
    var maxHeight = Math.max.apply(null, items.map(function(){return $(this).outerHeight()}).get() );
    items.css('min-height', maxHeight + 'px');
  })
}

$(window).on('load resize orientationchange', normalizeSlideHeights);
// End CAROUSEL JS

// triggers when targeted component loads in dom
window.ContextHub.eventing
		.on(
				ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.info.loadEvent,
				function() {
					$(".spark-hero").removeClass("spark-hero-img-none");
					id = corporateStore.getItem("id");
					accountname = corporateStore.getItem("accountname");
					targetedCopstore(accountname, id);
					targetedkeywordReplace();
					normalizeSlideHeights();
					if($targetedCall){
						getFaqContent(); 
						triggerFaqTab();
						segment(1000);
						$targetedCall = false;
					}
					 try{
							facebookinc();
	                    }catch(err) {
	  						console.log(err.message);
						}
				});

$(window).on('load', function() {
	// To avoid image flicker issue
    if($('body').find('div.campaign').length == 0){
    	$(".spark-hero").removeClass("spark-hero-img-none");
		getFaqContent();
		triggerFaqTab();
		segment(1000);
		 try{
				facebookinc();
         }catch(err) {
				console.log(err.message);
			}
    }
    
	id = corporateStore.getItem("id");
	accountname = corporateStore.getItem("accountname");
	getcopstore(accountname, id);
	if(typeof keywordReplaceList !== 'undefined'){
	    if(dynamicData == "" && keywordReplaceList != ""){
			keywordReplace();
	    }
	}
});

var pedemoId = window.location.pathname.split('/');
var cookieEnabled = are_cookies_enabled();
		var errorPage = cookieErrorPath + "/"+pedemoId[pedemoId.length - 1];
		if (!cookieEnabled) {
			if (!(window.location.href.indexOf(errorPage) != -1)) {
				window.location.replace(errorPage);
			}
	}

function are_cookies_enabled() {
	var cookieEnabled = (navigator.cookieEnabled) ? true : false;
	document.cookie = "testcookie";
	cookieEnabled = (document.cookie.indexOf("testcookie") != -1) ? true : false;
	return (cookieEnabled);
}

// loader fadeout function

function loderFadeout() {

	$(".loader").delay(1000).fadeOut("slow");
	$("#overlayer").delay(1000).fadeOut("slow");
	$('html, body').removeAttr('style');
}
// ------------------------------------------------------------
// Nontargeted Company Name changes
function getcopstore(corpname, comID) {

    if(exceptionName!="" && exceptionName!=undefined){
        var compName = new RegExp("#compName", "g");
        $("body").children().each(function() {
            $(this).html($(this).html().replace(compName, exceptionName));
        });
    
        $(".corporate").each(function(index, item) {
            if (comID != "0") {
                $($(".corporate")[index]).html(exceptionName);
            }
        });
    }else{
		var compName = new RegExp("#compName", "g");
        $("body").children().each(function() {
            $(this).html($(this).html().replace(compName, corpname));
        });
    
        $(".corporate").each(function(index, item) {
            if (comID != "0") {
                $($(".corporate")[index]).html(corpname);
            }
        });
    }
}
// targeted Company Name changes
function targetedCopstore(corpname, comID) {

    if(exceptionName!="" && exceptionName!=undefined){
        var compName = new RegExp("#compName", "g");
        $(".campaign .container").children().each(function() {
            $(this).html($(this).html().replace(compName, exceptionName));
        });
    
        $(".corporate").each(function(index, item) {
            if (comID != "0") {
                $($(".corporate")[index]).html(exceptionName);
            }
        });
    }else{
        var compName = new RegExp("#compName", "g");
        $(".campaign .container").children().each(function() {
            $(this).html($(this).html().replace(compName, corpname));
        });
    
        $(".corporate").each(function(index, item) {
            if (comID != "0") {
                $($(".corporate")[index]).html(corpname);
            }
        });
    }
}
// ------------------------------------------------------------
var dynamicData;
// Non targeted containt changes with this function
function keywordReplace() {
    var resultset;
    try {resultset=JSON.parse(keywordReplaceList);}
    	catch(e) {resultset=JSON.parse(JSON.stringify(keywordReplaceList));}
    for (key in resultset) {
        try {dynamicData=JSON.parse(resultset[key]);}
        catch(e) {dynamicData=JSON.parse(JSON.stringify(resultset[key]));}
        for(var i = 0 ; i< dynamicData.length; i++){
            $.each(dynamicData[i], function(keydata, valuedata) {
                keyReplace(keydata, valuedata);
            });
        }
    }

}
function keyReplace(oldKey, newKey) {
	var re = new RegExp("\\b"+oldKey+"\\b", "g");
	$("body").children().each(function() {
	          $(this).html($(this).html().replace(re, newKey));
	});
}

// targeted Keyword Replace function
function targetedkeywordReplace() {
    for(var i = 0 ; i< dynamicData.length; i++){
        $.each(dynamicData[i], function(keydata, valuedata) {
            targetedkeyReplace(keydata, valuedata);
        });
    }
}
function targetedkeyReplace(oldKey, newKey) {
	var re = new RegExp("\\b"+oldKey+"\\b", "g");
	$(".campaign .container").children().each(function() {
        $(this).html($(this).html().replace(re,newKey));
	});

}
// call faq page servlet, the FaqPage Path and ListCount will come from footer component 
// Keeping this method here as footer component getting called multiple time because of targeting event
function getFaqContent(){ 
    var contextHubcall = ContextHub.SegmentEngine.SegmentManager.getResolvedSegments();
    var contexhubJson =JSON.parse(JSON.stringify(contextHubcall.sort(function(a, b) {
        return parseFloat(b.boost) - parseFloat(a.boost);
    })));
    var resolvedPaths = contexhubJson.map(function(item) {
              return item.path;
    });
    if(typeof pedemoAccountId !== "undefined"){
        $.ajax({
            url: '/content/pedemo.getFaqPage.json',
            data:{"segmentPath" : resolvedPaths,
                  "faqPath":faqPagePath,
                  "listCount":listCount},
            async: false,
            cache: false,
            success: function (result) {
                var questions = "";	
                for (x in result) {
                    questions += '<a class="nav-link spark-text-white h4 font-weight-normal faqLinkTab" href="'+faqPagePath+'.html/'+pedemoAccountId+'"  target='+targetedFAQs+'>'+result[x]+'</a>';
                    
                };
                $('.spark-nav-footer-primary').html(questions);
            },
            error: function(){
                console.log("error in ajax call to faq page json from servlet");
            }
        });
    }
};

$(document).on("click",'.faqLinkTab',function(){
	var d = new Date();
   	d.setTime(d.getTime() + (cookieLife * 24 * 60 * 60 * 1000));
   	var expires = "expires=" + d.toUTCString();
    var question = $(this).text();
   	document.cookie = "clikedonFAQ="+question+"; " + expires + "; path=/";
})

function getFaqCookie() {
    var name = "clikedonFAQ" + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ')
            c = c.substring(1);
        if (c.indexOf(name) == 0)
            return c.substring(name.length, c.length);
    }
    return "";
}

function triggerFaqTab(){
    var question = getFaqCookie();
    if(question != ""){
            if ((window.location.href.indexOf(faqPagePath) != -1)) {
                    $(".spark-drawer-link").each(function() {
                        if($(this).text().trim() == question.trim()){

                                // Scroll
                                $('html,body').animate({
                                    scrollTop: $(this).offset().top - 100
                                }, 'slow');
                            $(this).trigger('click');
                        }
                    });
                }
        document.cookie ="clikedonFAQ=; path=/";
    }
}
