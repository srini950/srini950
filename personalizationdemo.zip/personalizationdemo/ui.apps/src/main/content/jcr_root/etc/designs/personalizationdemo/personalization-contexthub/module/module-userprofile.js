(function($) {
    'use strict';
    var defaultaccounname='';
    var defaultId;

    var ProfileRenderer = function() {
        var url = '/content/dam/pedemo/masterjsondata/accountdata.json';
        var url1 ='/content/dam/pedemo/masterjsondata/accountidname.json';
        var finalurl='';
		var userId="";
			 	 $.ajax({
                          url: '/content/pedemo.loggeduserinfo.json',
                          async: false,
                          success: function (result) {                                          
                                    if (result.UserID) {		                                                    
                                                userId=result.UserID;
                                                console.log("user id "+userId);
                                            }
                           },
                           error: function(){
                                            console.log("error in ajax call to getuniqueid servlet");
                           }
                      });

		console.log("logged in userid "+userId);
        finalurl= (userId =='all' ? url1 : url);
        userId =(userId =='all' ? 'accountmap' : userId);
        console.log("logged in userid1 " + userId);


        $.getJSON(finalurl, function(data) {
            console.log("in get json ");
            var users = [];
            let accArray=[];           
            let keysArray = Object.keys(data);
            for(var i=0; i<keysArray.length; i++){
                if(keysArray[i]==userId) accArray = (data[keysArray[i]]);

            }
            var count=0;
            $.each(accArray, function(i, user) {
                var record = {
                    title: user.accountname,
                    icon: user.icon,
                    data: {
                        id: user.id,
                        accountname: user.accountname
                    }
                };
                    users.push(record);
                if(count==0){
					defaultaccounname = user.accountname;
                    defaultId = user.id;
                    count=1;
                }
            });

            users = $.makeArray($(users).sort(function(a, b) {
                return ((a.data.accountname).toUpperCase() === (b.data.accountname).toUpperCase()) ? 0 : (((a.data.accountname).toUpperCase() < (b.data.accountname).toUpperCase()) ? -1 : 1);
            }));

            this.users = users;
        }.bind(this));
    };


 ContextHub.Utils.inheritance.inherit(ProfileRenderer, ContextHub.UI.BaseModuleRenderer);
    
    ProfileRenderer.prototype.defaultConfig = {
        icon: 'coral-Icon--user',
            title: 'Seller Accounts',
            clickable: true,
            editable: {
            key: '/userprofile'
        },
        storeMapping: {
            p: 'userprofile'
        },
        template: '<p class="contexthub-module-line1">{{i18n "Seller Name"}}</p>' +
        '<p class="contexthub-module-line2">{{p.displayName}}</p>',
            listType: 'checkmark',
         };

        ProfileRenderer.prototype.render = function(module) {
        var config = $.extend(true, {}, this.defaultConfig, module.config);
        module.config = config;
        return this.uber('render', module);
    };

    ProfileRenderer.prototype.getPopoverContent = function(module, popoverVariant) {
        var config = $.extend(true, {}, this.defaultConfig, module.config);
        if (!popoverVariant || popoverVariant === 'default') {
            var list = this.users;
			 if (list && config.skipUsers) {
                list = $.grep(list, function(user, i) {
                    return config.skipUsers.indexOf(user.data.id) === -1;
                });
            }
            if (list && config.storeMapping && config.storeMapping.p) {
                var store = ContextHub.getStore(config.storeMapping.p);
                if (store) {
                    var accountname = store.getItem('accountname');
                    if (accountname) {
                        $.each(list, function(i, user) {
                            user.selected = accountname.indexOf(user.data.accountname) === 0;
                          });
	                   }
                }
            }
            config.listType = 'checkmark';
            config.list = list;
        }
        module.config = config;
        return this.uber('getPopoverContent', module);

    };
        ProfileRenderer.prototype.onListItemClicked = function(module, position, data, event) {
        if (data.id) {
            var config = $.extend(true, {}, this.defaultConfig, module);
            if (config.storeMapping && config.storeMapping.p) {
                var store = ContextHub.getStore(config.storeMapping.p); 
                if (store) {
                    var isClientContextStore = typeof store.config.mappingConfig !== 'undefined';
                    var profile = isClientContextStore ? data.accountname : data.accountname;
                    var peDemoId;
                     $.ajax({
                          url: '/content/pedemo.encyrptedIdServlet.json',
                          data:{"pedemoid" : data.id},
                          async: false,
                          success: function (result) {
                        	  peDemoId = result.encryptedkey;
                           },
                           error: function(){
                                            console.log("error in ajax call to get pedemo id json from servlet");
                           }
                      });
                    store.loadProfile(profile,peDemoId,true);
                }
            }
        }
    };
    ContextHub.UI.ModuleRenderer('contexthub.userprofile', new ProfileRenderer());
}(ContextHubJQ));
